if(!window.cp)window.cp = function(str){return document.getElementById(str)};cp.CPProjInit = function(){if(cp && cp.model && cp.model.data) return; cp.model = {}; cp.poolResources = {}; cp.D = cp.model.data = {
pref:{
acc:1,
rkt:1,
hsr:0,
atp:false
},
si4414:{
name:'Image_3',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4414c',
tag:'container-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":520,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_SCALE","padding":{"left":10,"right":10,"top":37,"bottom":37},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"grid-area":"1 / 1 / span 1 / span 1"},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":1}',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si4422',
t:1268
}
]
,
containerType:'image',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":520,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_SCALE","padding":{"left":10,"right":10,"top":37,"bottom":37},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"grid-area":"1 / 1 / span 1 / span 1"},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":1}',
option:'INTRODUCTION_SINGLE_IMAGE_OPTION_2',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si4414c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:4414,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4414',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si4422:{
name:'Image_Group_3',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4422c',
tag:'container-image-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":false,"slide-item-buttons":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c2)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":0,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","gridGap":"10px"},"tablet":{"display":"flex","flexDirection":"column"},"mobile":{"display":"flex","flexDirection":"column"}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"2 / 1 / span 1 / span 2","marginLeft":"30px"},"tablet":{"marginLeft":"10px"},"mobile":{}}}}',
parentGroup:'si4414',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si4430',
t:15
}
,{
n:'si4442',
t:1268
}
,{
n:'si4470',
t:29
}
,{
n:'si4486',
t:29
}
,{
n:'si4502',
t:29
}
]
,
containerType:'image-single-card',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":false,"slide-item-buttons":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c2)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":0,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","gridGap":"10px"},"tablet":{"display":"flex","flexDirection":"column"},"mobile":{"display":"flex","flexDirection":"column"}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"2 / 1 / span 1 / span 2","marginLeft":"30px"},"tablet":{"marginLeft":"10px"},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si4414',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si4422c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:4422,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4422',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si4430:{
name:'1688538612544',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4430c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"imageContainerStyles":{"minWidth":"100%","maxWidth":"100%","gridArea":"1 / 2 / span 2 / span 1"},"borderRadius":"50%","overflow":"hidden","aspectRatio":"1","width":"unset","margin":"0 auto"},"tablet":{"imageContainerStyles":{}},"mobile":{"imageContainerStyles":{}}}}',
parentGroup:'si4422',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
o:100,
irw:800,
irh:800,
w:800,
h:800,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[4430]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si4430c:{
b:[0,0,800,800],
fh:false,
fw:false,
uid:4430,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'171.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'171.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'171.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/04518.jpeg',
dn:'si4430',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,801,801],
vb:[-1,-1,801,801]
},
si4442:{
name:'Image_Group_Text_9',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4442c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"paddingLeft":"30px","paddingRight":"30px","paddingTop":"5%","paddingBottom":"5%","minWidth":"50%","justifyContent":"flex-end"},"tablet":{"paddingLeft":"10px","paddingRight":"10px"},"mobile":{"marginLeft":"0px"}}}',
parentGroup:'si4422',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si4450',
t:1250
}
,{
n:'si4460',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"paddingLeft":"30px","paddingRight":"30px","paddingTop":"5%","paddingBottom":"5%","minWidth":"50%","justifyContent":"flex-end"},"tablet":{"paddingLeft":"10px","paddingRight":"10px"},"mobile":{"marginLeft":"0px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si4422',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si4442c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:4442,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4442',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si4450:{
name:'Text_70',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4450c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si4442',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"3p102","text":"Shubham Thakur","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"textDecoration:none"},{"offset":0,"length":14,"style":"fontFamily:Georgia"},{"offset":0,"length":14,"style":"borderBottomStyle:none"},{"offset":0,"length":14,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"hlnk:"},{"offset":0,"length":14,"style":"fontWeight:normal"},{"offset":0,"length":14,"style":"textShadowBlur:8px"},{"offset":0,"length":14,"style":"mobile-fontSize:32"},{"offset":0,"length":14,"style":"textShadow:none"},{"offset":0,"length":14,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"fontStyle:normal"},{"offset":0,"length":14,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":14,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"defaultTextShadow:none"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"tablet-fontSize:48"},{"offset":0,"length":14,"style":"textShadowX:0px"},{"offset":0,"length":14,"style":"fontStretch:normal"},{"offset":0,"length":14,"style":"fontType:regular"},{"offset":0,"length":14,"style":"color:#333333"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textShadowY:4px"},{"offset":0,"length":14,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":14,"style":"lineHeight:135%"},{"offset":0,"length":14,"style":"letterSpacing:0%"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textTransform:none"},{"offset":0,"length":14,"style":"desktop-fontSize:72"},{"offset":0,"length":14,"style":"textShadowOpacity:none"},{"offset":0,"length":14,"style":"overridden:true"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-8","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[4450]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si4450c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:4450,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4450',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si4460:{
name:'Text_71',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4460c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si4442',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"2u7t1","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-subheading-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"8q7j","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-6"}},{"key":"91jaq","text":"eLearning Developer ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":20,"style":"desktop-fontSize:18"},{"offset":0,"length":20,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":20,"style":"hlnkt:wp"},{"offset":0,"length":20,"style":"fontStyle:normal"},{"offset":0,"length":20,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":20,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":20,"style":"textOutlineEnable:false"},{"offset":0,"length":20,"style":"mobile-fontSize:14"},{"offset":0,"length":20,"style":"opacity:1"},{"offset":0,"length":20,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":20,"style":"hlnke:true"},{"offset":0,"length":20,"style":"backgroundColor:unset"},{"offset":0,"length":20,"style":"textShadow:none"},{"offset":0,"length":20,"style":"tablet-fontSize:16"},{"offset":0,"length":20,"style":"textShadowX:0px"},{"offset":0,"length":20,"style":"fontStretch:normal"},{"offset":0,"length":20,"style":"color:#333333"},{"offset":0,"length":20,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":20,"style":"textShadowY:4px"},{"offset":0,"length":20,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":20,"style":"lineHeight:125%"},{"offset":0,"length":20,"style":"letterSpacing:0%"},{"offset":0,"length":20,"style":"textHighlightEnable:false"},{"offset":0,"length":20,"style":"textTransform:none"},{"offset":0,"length":20,"style":"textShadowOpacity:none"},{"offset":0,"length":20,"style":"textDecoration:none"},{"offset":0,"length":20,"style":"fontType:bold"},{"offset":0,"length":20,"style":"borderBottomStyle:none"},{"offset":0,"length":19,"style":"fontWeight:bold"},{"offset":0,"length":20,"style":"textShadowEnable:false"},{"offset":0,"length":20,"style":"hlnk:"},{"offset":19,"length":1,"style":"fontWeight:normal"},{"offset":0,"length":20,"style":"textShadowBlur:8px"},{"offset":0,"length":20,"style":"fontFamily:Arial"},{"offset":0,"length":20,"style":"defaultTextShadow:none"},{"offset":0,"length":20,"style":"overridden:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}},{"key":"e5omu","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}},{"key":"74soe","text":"+91-8627856303","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"hlnkt:n"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"hlnk:https://shorturl.at/jqzNS"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-6"}},{"key":"3rm6p","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-6"}},{"key":"2n93s","text":"xshubhamthakur@gmail.com","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":24,"style":"textShadowEnable:false"},{"offset":0,"length":24,"style":"textOutlineEnable:false"},{"offset":0,"length":24,"style":"opacity:1"},{"offset":0,"length":24,"style":"hlnke:true"},{"offset":0,"length":24,"style":"backgroundColor:unset"},{"offset":0,"length":24,"style":"hlnkt:n"},{"offset":0,"length":24,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":24,"style":"hlnk:https://shorturl.at/jqzNS"},{"offset":0,"length":24,"style":"textHighlightEnable:false"},{"offset":0,"length":24,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-6"}},{"key":"9v4ek","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-6"}},{"key":"dk27n","text":"Portfolio link","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"textShadow:none"},{"offset":0,"length":14,"style":"tablet-fontSize:16"},{"offset":0,"length":14,"style":"textShadowX:0px"},{"offset":0,"length":14,"style":"fontStretch:normal"},{"offset":0,"length":14,"style":"color:#333333"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textShadowY:4px"},{"offset":0,"length":14,"style":"hlnk:https://shorturl.at/jqzNS"},{"offset":0,"length":14,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":14,"style":"lineHeight:125%"},{"offset":0,"length":14,"style":"letterSpacing:0%"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textTransform:none"},{"offset":0,"length":14,"style":"textShadowOpacity:none"},{"offset":0,"length":14,"style":"textDecoration:none"},{"offset":0,"length":14,"style":"fontType:bold"},{"offset":0,"length":14,"style":"borderBottomStyle:none"},{"offset":0,"length":14,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"fontWeight:normal"},{"offset":0,"length":14,"style":"textShadowBlur:8px"},{"offset":0,"length":14,"style":"fontFamily:Arial"},{"offset":0,"length":14,"style":"overridden:false"},{"offset":0,"length":14,"style":"defaultTextShadow:none"},{"offset":0,"length":14,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":14,"style":"desktop-fontSize:18"},{"offset":0,"length":14,"style":"fontStyle:normal"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":14,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"mobile-fontSize:14"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":14,"style":"hlnke:true"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[4460]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si4460c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:4460,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4460',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si4470:{
name:'Button_55',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4470c',
tag:'slide-item-buttons0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7r61i","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8l4el","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"41nqe","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"au2gq","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a3k7l","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOptionStyles":{}}',
parentGroup:'si4422',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[4470]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si4470c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:4470,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4470',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si4486:{
name:'Button_56',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4486c',
tag:'slide-item-buttons1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"d16ql","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ephn","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2pmm6","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"eji8t","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5unut","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOptionStyles":{}}',
parentGroup:'si4422',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[4486]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si4486c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:4486,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4486',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si4502:{
name:'Button_57',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4502c',
tag:'slide-item-buttons2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"euqm1","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a0ivs","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6kp11","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"j5sj","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"d6j6k","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOptionStyles":{}}',
parentGroup:'si4422',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[4502]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si4502c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:4502,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4502',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si4520:{
name:'Paragraph_8',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4520c',
tag:'container-paragraph',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"left":5,"right":5,"top":164,"bottom":94},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"80px"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si4528',
t:1268
}
]
,
containerType:'paragraph',
widgetProps:'{"padding":{"left":5,"right":5,"top":164,"bottom":94},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"80px"},"tablet":{},"mobile":{}}}',
option:'PARAGRAPH_ALL_SECTIONS_1_C3',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si4520c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:4520,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4520',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si4528:{
name:'Paragraph_Group_2',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4528c',
tag:'container-paragraph-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":true},"alignment":{"slide-item-heading":"CENTER","slide-item-subtitle":"CENTER","slide-item-body":"CENTER","slide-item-buttons":"LEFT"},"canBeCard":true,"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"3 / 1 / span 1 / span 2"},"tablet":{},"mobile":{}}},"shouldDesignOptionHiddenInPI":true,"padding":{"top":10,"bottom":10,"left":10,"right":10},"groupedItemsVisibility":{"slide-item-buttons":1},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingLeft":"50px","paddingRight":"50px"},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}}}',
parentGroup:'si4520',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si4536',
t:1250
}
,{
n:'si4546',
t:1250
}
,{
n:'si4556',
t:1250
}
,{
n:'si4566',
t:29
}
,{
n:'si4582',
t:29
}
,{
n:'si4598',
t:29
}
]
,
containerType:'paragraph-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":true},"alignment":{"slide-item-heading":"CENTER","slide-item-subtitle":"CENTER","slide-item-body":"CENTER","slide-item-buttons":"LEFT"},"canBeCard":true,"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"3 / 1 / span 1 / span 2"},"tablet":{},"mobile":{}}},"shouldDesignOptionHiddenInPI":true,"padding":{"top":10,"bottom":10,"left":10,"right":10},"groupedItemsVisibility":{"slide-item-buttons":1},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingLeft":"50px","paddingRight":"50px"},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si4520',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si4528c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:4528,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4528',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si4536:{
name:'Text_72',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4536c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"paddingBottom":"20px"},"tablet":{},"mobile":{}},"padding":{"top":10,"bottom":10,"left":5,"right":5},"autoFit":false}',
parentGroup:'si4528',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"3lco1","text":"About me","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[4536]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si4536c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:4536,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4536',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si4546:{
name:'Text_73',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4546c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si4528',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"5dt0t","text":"Subtitle","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[4546]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si4546c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:4546,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4546',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si4556:{
name:'Text_74',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4556c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"paddingBottom":"10px"},"tablet":{},"mobile":{}}}',
parentGroup:'si4528',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"67qs0","text":"As a eLearning Developer/Graphic Designer with 4.5 years of experience, my portfolio demonstrates expertise in Adobe Captivate, Adobe Illustrator, Adobe Photoshop, Davinci Resolve(alternative for Premiere Pro and After Effects) and Microsoft PowerPoint.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":253,"style":"textHighlightEnable:false"},{"offset":0,"length":253,"style":"textTransform:none"},{"offset":0,"length":253,"style":"textShadowOpacity:none"},{"offset":0,"length":253,"style":"overridden:true"},{"offset":0,"length":253,"style":"textDecoration:none"},{"offset":0,"length":253,"style":"lineHeight:130%"},{"offset":0,"length":253,"style":"fontFamily:Georgia"},{"offset":0,"length":253,"style":"borderBottomStyle:none"},{"offset":111,"length":142,"style":"fontWeight:bold"},{"offset":0,"length":253,"style":"desktop-fontSize:22"},{"offset":0,"length":253,"style":"textShadowEnable:false"},{"offset":0,"length":253,"style":"hlnk:"},{"offset":0,"length":111,"style":"fontWeight:normal"},{"offset":0,"length":253,"style":"backgroundColor:unset"},{"offset":0,"length":253,"style":"textShadowBlur:8px"},{"offset":0,"length":253,"style":"hlnkt:wp"},{"offset":0,"length":253,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":253,"style":"tablet-fontSize:20"},{"offset":0,"length":253,"style":"fontStyle:normal"},{"offset":0,"length":253,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":253,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":253,"style":"textOutlineEnable:false"},{"offset":0,"length":253,"style":"opacity:1"},{"offset":0,"length":253,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":253,"style":"hlnke:true"},{"offset":0,"length":253,"style":"defaultTextShadow:none"},{"offset":0,"length":253,"style":"textShadow:none"},{"offset":0,"length":253,"style":"mobile-fontSize:18"},{"offset":0,"length":253,"style":"textShadowX:0px"},{"offset":0,"length":253,"style":"fontStretch:normal"},{"offset":0,"length":253,"style":"fontType:regular"},{"offset":0,"length":253,"style":"color:#333333"},{"offset":0,"length":253,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":253,"style":"textShadowY:4px"},{"offset":0,"length":253,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":253,"style":"letterSpacing:0%"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"84rie","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"5t3ig","text":"I have a proven track record of creating visually engaging content like eLearning courses, video editing, motion graphics, illustration, photo editing, photo manipulation and interactive PPT.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":191,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":191,"style":"textShadowY:4px"},{"offset":0,"length":191,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":191,"style":"letterSpacing:0%"},{"offset":0,"length":191,"style":"textHighlightEnable:false"},{"offset":0,"length":191,"style":"textTransform:none"},{"offset":0,"length":191,"style":"textShadowOpacity:none"},{"offset":0,"length":191,"style":"overridden:true"},{"offset":0,"length":191,"style":"textDecoration:none"},{"offset":0,"length":191,"style":"lineHeight:130%"},{"offset":0,"length":191,"style":"fontFamily:Georgia"},{"offset":0,"length":191,"style":"borderBottomStyle:none"},{"offset":72,"length":119,"style":"fontWeight:bold"},{"offset":0,"length":191,"style":"desktop-fontSize:22"},{"offset":0,"length":191,"style":"textShadowEnable:false"},{"offset":0,"length":191,"style":"hlnk:"},{"offset":0,"length":72,"style":"fontWeight:normal"},{"offset":0,"length":191,"style":"backgroundColor:unset"},{"offset":0,"length":191,"style":"textShadowBlur:8px"},{"offset":0,"length":191,"style":"hlnkt:wp"},{"offset":0,"length":191,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":191,"style":"tablet-fontSize:20"},{"offset":0,"length":191,"style":"fontStyle:normal"},{"offset":0,"length":191,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":191,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":191,"style":"textOutlineEnable:false"},{"offset":0,"length":191,"style":"opacity:1"},{"offset":0,"length":191,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":191,"style":"hlnke:true"},{"offset":0,"length":191,"style":"defaultTextShadow:none"},{"offset":0,"length":191,"style":"textShadow:none"},{"offset":0,"length":191,"style":"mobile-fontSize:18"},{"offset":0,"length":191,"style":"textShadowX:0px"},{"offset":0,"length":191,"style":"fontStretch:normal"},{"offset":0,"length":191,"style":"fontType:regular"},{"offset":0,"length":191,"style":"color:#333333"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"3vkld","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"4l06a","text":"I am highly collaborative, adaptable, and skilled in designing layouts for web and mobile devices. With strong problem-solving skills and effective communication, I am confident in my ability to create highly attractive visual content for great user experience.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":261,"style":"textShadowX:0px"},{"offset":0,"length":261,"style":"fontStretch:normal"},{"offset":0,"length":261,"style":"fontType:regular"},{"offset":0,"length":261,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":261,"style":"textShadowY:4px"},{"offset":0,"length":261,"style":"letterSpacing:3%"},{"offset":0,"length":261,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":261,"style":"textHighlightEnable:false"},{"offset":0,"length":261,"style":"textTransform:none"},{"offset":0,"length":261,"style":"color:#020C1C"},{"offset":0,"length":261,"style":"textShadowOpacity:none"},{"offset":0,"length":261,"style":"textDecoration:none"},{"offset":0,"length":261,"style":"lineHeight:130%"},{"offset":0,"length":261,"style":"borderBottomStyle:none"},{"offset":0,"length":261,"style":"desktop-fontSize:22"},{"offset":0,"length":261,"style":"textShadowEnable:false"},{"offset":0,"length":261,"style":"hlnk:"},{"offset":0,"length":261,"style":"fontWeight:normal"},{"offset":0,"length":261,"style":"textShadowBlur:8px"},{"offset":0,"length":261,"style":"fontFamily:Arial"},{"offset":0,"length":261,"style":"overridden:false"},{"offset":0,"length":261,"style":"backgroundColor:unset"},{"offset":0,"length":261,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":261,"style":"hlnkt:wp"},{"offset":0,"length":261,"style":"fontStyle:normal"},{"offset":0,"length":261,"style":"tablet-fontSize:20"},{"offset":0,"length":261,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":261,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":261,"style":"textOutlineEnable:false"},{"offset":0,"length":261,"style":"opacity:1"},{"offset":0,"length":261,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":261,"style":"hlnke:true"},{"offset":0,"length":261,"style":"defaultTextShadow:none"},{"offset":0,"length":261,"style":"textShadow:none"},{"offset":0,"length":261,"style":"mobile-fontSize:18"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[4556]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si4556c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:4556,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4556',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si4566:{
name:'Button_58',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4566c',
tag:'slide-item-buttons0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"lck0","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"k0da","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3s1tq","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8ud16","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"crvbv","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si4528',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[4566]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si4566c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:4566,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4566',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si4582:{
name:'Button_59',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4582c',
tag:'slide-item-buttons1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4lof","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6l38p","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"22t1u","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"e5qqf","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"29k8","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si4528',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[4582]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si4582c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:4582,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4582',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si4598:{
name:'Button_60',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si4598c',
tag:'slide-item-buttons2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ddbqo","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9evpp","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7snj","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ak96s","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"aldl2","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si4528',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[4598]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si4598c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:4598,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si4598',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si7245:{
name:'Timeline_2',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7245c',
tag:'container-timeline-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-next-button":false,"slide-item-prev-button":false,"isDerivedFromChild":true},"autoFit":true,"alignment":{"slide-item-heading":"CENTER"},"canBeCard":false,"isForcedNavigationEnabled":true,"contentSpacing":1,"padding":{"left":4,"right":4,"top":72,"bottom":72},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{},"layoutSpacing":{"value":"F"}}',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7253',
t:1250
}
,{
n:'si7263',
t:1268
}
,{
n:'si8003',
t:1268
}
]
,
containerType:'timeline-widget',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-next-button":false,"slide-item-prev-button":false,"isDerivedFromChild":true},"autoFit":true,"alignment":{"slide-item-heading":"CENTER"},"canBeCard":false,"isForcedNavigationEnabled":true,"contentSpacing":1,"padding":{"left":4,"right":4,"top":72,"bottom":72},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{},"layoutSpacing":{"value":"F"}}',
option:'TIMELINE_WIDGET_OPTION_4',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si7245c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7245,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7245',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7253:{
name:'Text_96',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7253c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"padding":"60px 0px 50px 0px","marginBottom":"30px"},"tablet":{},"mobile":{}}}',
parentGroup:'si7245',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"6opaa","text":"Experience","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7253]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7253c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:7253,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7253',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si7263:{
name:'Timeline_Content_2',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7263c',
tag:'container-timeline-widget-content',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"numberOfChildren":3,"canBeCard":false,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"repeat(4, auto)"},"tablet":{},"mobile":{}}}',
parentGroup:'si7245',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7271',
t:1268
}
,{
n:'si7393',
t:1268
}
,{
n:'si7515',
t:1268
}
,{
n:'si7637',
t:1268
}
,{
n:'si7759',
t:1268
}
,{
n:'si7881',
t:1268
}
]
,
containerType:'timeline-widget-content',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"numberOfChildren":3,"canBeCard":false,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"repeat(4, auto)"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7245',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7263c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7263,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7263',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c7)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#ffffff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7271:{
name:'Node_7',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7271c',
tag:'container-timeline-node-0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"timeline-widget-time":true,"isDerivedFromChild":true},"isVisible":true,"canBeCard":false,"imageHeight":200}',
parentGroup:'si7263',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7279',
t:1250
}
,{
n:'si7289',
t:1268
}
,{
n:'si7321',
t:1268
}
]
,
containerType:'timeline-widget-node',
widgetProps:'{"visibilityInfo":{"timeline-widget-time":true,"isDerivedFromChild":true},"isVisible":true,"canBeCard":false,"imageHeight":200}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7263',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7271c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7271,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7271',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7279:{
name:'Text_97',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7279c',
tag:'timeline-widget-time-0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridColumn":"1","gridRow":"1","padding":"0px 0px 12px 0px"},"tablet":{"gridColumn":"1","gridRow":"1"},"mobile":{"gridColumn":"1","gridRow":"1"}}}',
parentGroup:'si7271',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"c52au","text":"2023","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-subheading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7279]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7279c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:7279,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7279',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si7289:{
name:'Graphic_Button_Container_7',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7289c',
tag:'container-graphic-button-0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridTemplateRows":"1fr","gridTemplateColumns":"1fr","gridColumn":"2","gridRow":"1","paddingBottom":"0px","transform":"rotate(0deg)"},"tablet":{"gridColumn":"2","gridRow":"1","transform":"rotate(0deg)","paddingBottom":"0px"},"mobile":{"gridColumn":"2","gridRow":"1","transform":"rotate(0deg)","paddingBottom":"0px"}}}',
parentGroup:'si7271',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7297',
t:1268
}
,{
n:'si7305',
t:29
}
]
,
containerType:'timeline-widget-graphic-button',
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridTemplateRows":"1fr","gridTemplateColumns":"1fr","gridColumn":"2","gridRow":"1","paddingBottom":"0px","transform":"rotate(0deg)"},"tablet":{"gridColumn":"2","gridRow":"1","transform":"rotate(0deg)","paddingBottom":"0px"},"mobile":{"gridColumn":"2","gridRow":"1","transform":"rotate(0deg)","paddingBottom":"0px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7271',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7289c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7289,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7289',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7297:{
name:'Timeline_Graphic_7',
type:1268,
from:1,
to:0,
rp:0,
rpa:0,
mdi:'si7297c',
tag:'container-graphic-0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"width":"6px","height":"100%","margin":"10px 0","gridRow":"1","gridColumn":"1","background":"#edeae2"},"tablet":{"width":"6px","height":"100%"},"mobile":{"width":"6px","height":"100%"}}}',
parentGroup:'si7289',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'timeline-widget-graphic',
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"width":"6px","height":"100%","margin":"10px 0","gridRow":"1","gridColumn":"1","background":"#edeae2"},"tablet":{"width":"6px","height":"100%"},"mobile":{"width":"6px","height":"100%"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7289',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7297c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7297,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7297',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7305:{
name:'Button_63',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7305c',
tag:'timeline-node-button-0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2vrrd","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4cfon","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{"all":{"width":"40px","height":"40px","opacity":"1","gridRow":"1","gridColumn":"1","zIndex":1},"tablet":{},"mobile":{}},"iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"58fh7","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"},{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"e2pkp","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"},{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3tess","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si7289',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7305]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7305c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7305,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7305',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si7321:{
name:'Node_content_7',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7321c',
tag:'container-node-content-0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"imageHeight":200,"visibilityInfo":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"padding":"20px 0px","gridRowStart":"1","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"span 4"},"tablet":{"gridRowStart":"1","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"},"mobile":{"gridRowStart":"1","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"}}}',
parentGroup:'si7271',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7329',
t:1268
}
]
,
containerType:'timeline-node-content',
widgetProps:'{"canBeCard":false,"imageHeight":200,"visibilityInfo":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"padding":"20px 0px","gridRowStart":"1","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"span 4"},"tablet":{"gridRowStart":"1","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"},"mobile":{"gridRowStart":"1","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7271',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7321c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7321,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7321',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7329:{
name:'Image_Grid_Group_7',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7329c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true},"padding":{"top":24,"bottom":24,"left":24,"right":24},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"10px","alignItems":"center"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"}}}',
parentGroup:'si7321',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7337',
t:15
}
,{
n:'si7349',
t:1268
}
,{
n:'si7377',
t:29
}
]
,
containerType:'image-grid-card',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true},"padding":{"top":24,"bottom":24,"left":24,"right":24},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"10px","alignItems":"center"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7321',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si7329c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7329,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7329',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c2)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7337:{
name:'4s_1',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7337c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"50%","width":"210px","height":"200px"},"tablet":{"width":"200px"},"mobile":{"width":"200px"}}}',
parentGroup:'si7329',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
o:100,
irw:1284,
irh:1088,
w:1284,
h:1088,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7337]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7337c:{
b:[0,0,1284,1088],
fh:false,
fw:false,
uid:7337,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/03619.png',
dn:'si7337',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1285,1089],
vb:[-1,-1,1285,1089]
},
si7349:{
name:'Image_Group_Text_10',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7349c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0}}',
parentGroup:'si7329',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7357',
t:1250
}
,{
n:'si7367',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7329',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7349c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7349,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7349',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7357:{
name:'Text_98',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7357c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"padding":"24px 0px  12px 0px","width":"350px"},"tablet":{"width":"100%"},"mobile":{"width":"100%"}}}',
parentGroup:'si7349',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"5n4of","text":"Creative director","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":17,"style":"textShadowEnable:false"},{"offset":0,"length":17,"style":"overridden:false"},{"offset":0,"length":17,"style":"hlnk:"},{"offset":0,"length":17,"style":"hlnkt:wp"},{"offset":0,"length":17,"style":"textOutlineEnable:false"},{"offset":0,"length":17,"style":"opacity:1"},{"offset":0,"length":17,"style":"hlnke:true"},{"offset":0,"length":17,"style":"backgroundColor:unset"},{"offset":0,"length":17,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":17,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-body-2"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7357]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7357c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:7357,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7357',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si7367:{
name:'Text_99',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7367c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"width":"350px"},"tablet":{"width":"100%"},"mobile":{"width":"100%"}}}',
parentGroup:'si7349',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"dv9ao","text":"• Creation of eLearning courses","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":31,"style":"defaultTextShadow:none"},{"offset":0,"length":31,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":31,"style":"desktop-fontSize:18"},{"offset":0,"length":31,"style":"fontStyle:normal"},{"offset":0,"length":31,"style":"hlnkt:wp"},{"offset":0,"length":31,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":31,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":31,"style":"textOutlineEnable:false"},{"offset":0,"length":31,"style":"opacity:1"},{"offset":0,"length":31,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":31,"style":"mobile-fontSize:16"},{"offset":0,"length":31,"style":"hlnke:true"},{"offset":0,"length":31,"style":"backgroundColor:unset"},{"offset":0,"length":31,"style":"textShadow:none"},{"offset":0,"length":31,"style":"tablet-fontSize:16"},{"offset":0,"length":31,"style":"textShadowX:0px"},{"offset":0,"length":31,"style":"fontStretch:normal"},{"offset":0,"length":31,"style":"fontType:regular"},{"offset":0,"length":31,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":31,"style":"textShadowY:4px"},{"offset":0,"length":31,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":31,"style":"lineHeight:135%"},{"offset":0,"length":31,"style":"letterSpacing:0%"},{"offset":0,"length":31,"style":"textHighlightEnable:false"},{"offset":0,"length":31,"style":"textTransform:none"},{"offset":0,"length":31,"style":"color:#020C1C"},{"offset":0,"length":31,"style":"textShadowOpacity:none"},{"offset":0,"length":31,"style":"textDecoration:none"},{"offset":0,"length":31,"style":"borderBottomStyle:none"},{"offset":0,"length":31,"style":"textShadowEnable:false"},{"offset":0,"length":31,"style":"hlnk:"},{"offset":0,"length":31,"style":"fontWeight:normal"},{"offset":0,"length":31,"style":"textShadowBlur:8px"},{"offset":0,"length":31,"style":"fontFamily:Arial"},{"offset":0,"length":31,"style":"overridden:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"6r4cm","text":"• Heading the marketing team","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":28,"style":"textShadowBlur:8px"},{"offset":0,"length":28,"style":"fontFamily:Arial"},{"offset":0,"length":28,"style":"overridden:false"},{"offset":0,"length":28,"style":"defaultTextShadow:none"},{"offset":0,"length":28,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":28,"style":"desktop-fontSize:18"},{"offset":0,"length":28,"style":"fontStyle:normal"},{"offset":0,"length":28,"style":"hlnkt:wp"},{"offset":0,"length":28,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":28,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":28,"style":"textOutlineEnable:false"},{"offset":0,"length":28,"style":"opacity:1"},{"offset":0,"length":28,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":28,"style":"mobile-fontSize:16"},{"offset":0,"length":28,"style":"hlnke:true"},{"offset":0,"length":28,"style":"backgroundColor:unset"},{"offset":0,"length":28,"style":"textShadow:none"},{"offset":0,"length":28,"style":"tablet-fontSize:16"},{"offset":0,"length":28,"style":"textShadowX:0px"},{"offset":0,"length":28,"style":"fontStretch:normal"},{"offset":0,"length":28,"style":"fontType:regular"},{"offset":0,"length":28,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":28,"style":"textShadowY:4px"},{"offset":0,"length":28,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":28,"style":"lineHeight:135%"},{"offset":0,"length":28,"style":"letterSpacing:0%"},{"offset":0,"length":28,"style":"textHighlightEnable:false"},{"offset":0,"length":28,"style":"textTransform:none"},{"offset":0,"length":28,"style":"color:#020C1C"},{"offset":0,"length":28,"style":"textShadowOpacity:none"},{"offset":0,"length":28,"style":"textDecoration:none"},{"offset":0,"length":28,"style":"borderBottomStyle:none"},{"offset":0,"length":28,"style":"textShadowEnable:false"},{"offset":0,"length":28,"style":"hlnk:"},{"offset":0,"length":28,"style":"fontWeight:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"1asi4","text":"• Managing team members and tasks deliverable","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":45,"style":"textShadowEnable:false"},{"offset":0,"length":45,"style":"hlnk:"},{"offset":0,"length":45,"style":"fontWeight:normal"},{"offset":0,"length":45,"style":"textShadowBlur:8px"},{"offset":0,"length":45,"style":"fontFamily:Arial"},{"offset":0,"length":45,"style":"overridden:false"},{"offset":0,"length":45,"style":"defaultTextShadow:none"},{"offset":0,"length":45,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":45,"style":"desktop-fontSize:18"},{"offset":0,"length":45,"style":"fontStyle:normal"},{"offset":0,"length":45,"style":"hlnkt:wp"},{"offset":0,"length":45,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":45,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":45,"style":"textOutlineEnable:false"},{"offset":0,"length":45,"style":"opacity:1"},{"offset":0,"length":45,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":45,"style":"mobile-fontSize:16"},{"offset":0,"length":45,"style":"hlnke:true"},{"offset":0,"length":45,"style":"backgroundColor:unset"},{"offset":0,"length":45,"style":"textShadow:none"},{"offset":0,"length":45,"style":"tablet-fontSize:16"},{"offset":0,"length":45,"style":"textShadowX:0px"},{"offset":0,"length":45,"style":"fontStretch:normal"},{"offset":0,"length":45,"style":"fontType:regular"},{"offset":0,"length":45,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":45,"style":"textShadowY:4px"},{"offset":0,"length":45,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":45,"style":"lineHeight:135%"},{"offset":0,"length":45,"style":"letterSpacing:0%"},{"offset":0,"length":45,"style":"textHighlightEnable:false"},{"offset":0,"length":45,"style":"textTransform:none"},{"offset":0,"length":45,"style":"color:#020C1C"},{"offset":0,"length":45,"style":"textShadowOpacity:none"},{"offset":0,"length":45,"style":"textDecoration:none"},{"offset":0,"length":45,"style":"borderBottomStyle:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"35ttq","text":"• Creating and editing videos","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":29,"style":"textShadowOpacity:none"},{"offset":0,"length":29,"style":"textDecoration:none"},{"offset":0,"length":29,"style":"borderBottomStyle:none"},{"offset":0,"length":29,"style":"textShadowEnable:false"},{"offset":0,"length":29,"style":"hlnk:"},{"offset":0,"length":29,"style":"fontWeight:normal"},{"offset":0,"length":29,"style":"textShadowBlur:8px"},{"offset":0,"length":29,"style":"fontFamily:Arial"},{"offset":0,"length":29,"style":"overridden:false"},{"offset":0,"length":29,"style":"defaultTextShadow:none"},{"offset":0,"length":29,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":29,"style":"desktop-fontSize:18"},{"offset":0,"length":29,"style":"fontStyle:normal"},{"offset":0,"length":29,"style":"hlnkt:wp"},{"offset":0,"length":29,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":29,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":29,"style":"textOutlineEnable:false"},{"offset":0,"length":29,"style":"opacity:1"},{"offset":0,"length":29,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":29,"style":"mobile-fontSize:16"},{"offset":0,"length":29,"style":"hlnke:true"},{"offset":0,"length":29,"style":"backgroundColor:unset"},{"offset":0,"length":29,"style":"textShadow:none"},{"offset":0,"length":29,"style":"tablet-fontSize:16"},{"offset":0,"length":29,"style":"textShadowX:0px"},{"offset":0,"length":29,"style":"fontStretch:normal"},{"offset":0,"length":29,"style":"fontType:regular"},{"offset":0,"length":29,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":29,"style":"textShadowY:4px"},{"offset":0,"length":29,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":29,"style":"lineHeight:135%"},{"offset":0,"length":29,"style":"letterSpacing:0%"},{"offset":0,"length":29,"style":"textHighlightEnable:false"},{"offset":0,"length":29,"style":"textTransform:none"},{"offset":0,"length":29,"style":"color:#020C1C"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"b3o7p","text":"• Creating motion graphics","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":26,"style":"textHighlightEnable:false"},{"offset":0,"length":26,"style":"textTransform:none"},{"offset":0,"length":26,"style":"color:#020C1C"},{"offset":0,"length":26,"style":"textShadowOpacity:none"},{"offset":0,"length":26,"style":"textDecoration:none"},{"offset":0,"length":26,"style":"borderBottomStyle:none"},{"offset":0,"length":26,"style":"textShadowEnable:false"},{"offset":0,"length":26,"style":"hlnk:"},{"offset":0,"length":26,"style":"fontWeight:normal"},{"offset":0,"length":26,"style":"textShadowBlur:8px"},{"offset":0,"length":26,"style":"fontFamily:Arial"},{"offset":0,"length":26,"style":"overridden:false"},{"offset":0,"length":26,"style":"defaultTextShadow:none"},{"offset":0,"length":26,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":26,"style":"desktop-fontSize:18"},{"offset":0,"length":26,"style":"fontStyle:normal"},{"offset":0,"length":26,"style":"hlnkt:wp"},{"offset":0,"length":26,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":26,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":26,"style":"textOutlineEnable:false"},{"offset":0,"length":26,"style":"opacity:1"},{"offset":0,"length":26,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":26,"style":"mobile-fontSize:16"},{"offset":0,"length":26,"style":"hlnke:true"},{"offset":0,"length":26,"style":"backgroundColor:unset"},{"offset":0,"length":26,"style":"textShadow:none"},{"offset":0,"length":26,"style":"tablet-fontSize:16"},{"offset":0,"length":26,"style":"textShadowX:0px"},{"offset":0,"length":26,"style":"fontStretch:normal"},{"offset":0,"length":26,"style":"fontType:regular"},{"offset":0,"length":26,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":26,"style":"textShadowY:4px"},{"offset":0,"length":26,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":26,"style":"lineHeight:135%"},{"offset":0,"length":26,"style":"letterSpacing:0%"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"dbtaq","text":"• Creating illustrations for campaigns","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":38,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":38,"style":"lineHeight:135%"},{"offset":0,"length":38,"style":"letterSpacing:0%"},{"offset":0,"length":38,"style":"textHighlightEnable:false"},{"offset":0,"length":38,"style":"textTransform:none"},{"offset":0,"length":38,"style":"color:#020C1C"},{"offset":0,"length":38,"style":"textShadowOpacity:none"},{"offset":0,"length":38,"style":"textDecoration:none"},{"offset":0,"length":38,"style":"borderBottomStyle:none"},{"offset":0,"length":38,"style":"textShadowEnable:false"},{"offset":0,"length":38,"style":"hlnk:"},{"offset":0,"length":38,"style":"fontWeight:normal"},{"offset":0,"length":38,"style":"textShadowBlur:8px"},{"offset":0,"length":38,"style":"fontFamily:Arial"},{"offset":0,"length":38,"style":"overridden:false"},{"offset":0,"length":38,"style":"defaultTextShadow:none"},{"offset":0,"length":38,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":38,"style":"desktop-fontSize:18"},{"offset":0,"length":38,"style":"fontStyle:normal"},{"offset":0,"length":38,"style":"hlnkt:wp"},{"offset":0,"length":38,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":38,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":38,"style":"textOutlineEnable:false"},{"offset":0,"length":38,"style":"opacity:1"},{"offset":0,"length":38,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":38,"style":"mobile-fontSize:16"},{"offset":0,"length":38,"style":"hlnke:true"},{"offset":0,"length":38,"style":"backgroundColor:unset"},{"offset":0,"length":38,"style":"textShadow:none"},{"offset":0,"length":38,"style":"tablet-fontSize:16"},{"offset":0,"length":38,"style":"textShadowX:0px"},{"offset":0,"length":38,"style":"fontStretch:normal"},{"offset":0,"length":38,"style":"fontType:regular"},{"offset":0,"length":38,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":38,"style":"textShadowY:4px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"8go4p","text":"• Editing and manipulating photos","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":33,"style":"fontType:regular"},{"offset":0,"length":33,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":33,"style":"textShadowY:4px"},{"offset":0,"length":33,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":33,"style":"lineHeight:135%"},{"offset":0,"length":33,"style":"letterSpacing:0%"},{"offset":0,"length":33,"style":"textHighlightEnable:false"},{"offset":0,"length":33,"style":"textTransform:none"},{"offset":0,"length":33,"style":"color:#020C1C"},{"offset":0,"length":33,"style":"textShadowOpacity:none"},{"offset":0,"length":33,"style":"textDecoration:none"},{"offset":0,"length":33,"style":"borderBottomStyle:none"},{"offset":0,"length":33,"style":"textShadowEnable:false"},{"offset":0,"length":33,"style":"hlnk:"},{"offset":0,"length":33,"style":"fontWeight:normal"},{"offset":0,"length":33,"style":"textShadowBlur:8px"},{"offset":0,"length":33,"style":"fontFamily:Arial"},{"offset":0,"length":33,"style":"overridden:false"},{"offset":0,"length":33,"style":"defaultTextShadow:none"},{"offset":0,"length":33,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":33,"style":"desktop-fontSize:18"},{"offset":0,"length":33,"style":"fontStyle:normal"},{"offset":0,"length":33,"style":"hlnkt:wp"},{"offset":0,"length":33,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":33,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":33,"style":"textOutlineEnable:false"},{"offset":0,"length":33,"style":"opacity:1"},{"offset":0,"length":33,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":33,"style":"mobile-fontSize:16"},{"offset":0,"length":33,"style":"hlnke:true"},{"offset":0,"length":33,"style":"backgroundColor:unset"},{"offset":0,"length":33,"style":"textShadow:none"},{"offset":0,"length":33,"style":"tablet-fontSize:16"},{"offset":0,"length":33,"style":"textShadowX:0px"},{"offset":0,"length":33,"style":"fontStretch:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"dpda9","text":"• Developing interactive presentations","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":38,"style":"tablet-fontSize:16"},{"offset":0,"length":38,"style":"textShadowX:0px"},{"offset":0,"length":38,"style":"fontStretch:normal"},{"offset":0,"length":38,"style":"fontType:regular"},{"offset":0,"length":38,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":38,"style":"textShadowY:4px"},{"offset":0,"length":38,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":38,"style":"lineHeight:135%"},{"offset":0,"length":38,"style":"letterSpacing:0%"},{"offset":0,"length":38,"style":"textHighlightEnable:false"},{"offset":0,"length":38,"style":"textTransform:none"},{"offset":0,"length":38,"style":"color:#020C1C"},{"offset":0,"length":38,"style":"textShadowOpacity:none"},{"offset":0,"length":38,"style":"textDecoration:none"},{"offset":0,"length":38,"style":"borderBottomStyle:none"},{"offset":0,"length":38,"style":"textShadowEnable:false"},{"offset":0,"length":38,"style":"hlnk:"},{"offset":0,"length":38,"style":"fontWeight:normal"},{"offset":0,"length":38,"style":"textShadowBlur:8px"},{"offset":0,"length":38,"style":"fontFamily:Arial"},{"offset":0,"length":38,"style":"overridden:false"},{"offset":0,"length":38,"style":"defaultTextShadow:none"},{"offset":0,"length":38,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":38,"style":"desktop-fontSize:18"},{"offset":0,"length":38,"style":"fontStyle:normal"},{"offset":0,"length":38,"style":"hlnkt:wp"},{"offset":0,"length":38,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":38,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":38,"style":"textOutlineEnable:false"},{"offset":0,"length":38,"style":"opacity:1"},{"offset":0,"length":38,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":38,"style":"mobile-fontSize:16"},{"offset":0,"length":38,"style":"hlnke:true"},{"offset":0,"length":38,"style":"backgroundColor:unset"},{"offset":0,"length":38,"style":"textShadow:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"19jau","text":"• Transforming user stories in designs that are easy to ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":56,"style":"hlnke:true"},{"offset":0,"length":56,"style":"backgroundColor:unset"},{"offset":0,"length":56,"style":"textShadow:none"},{"offset":0,"length":56,"style":"tablet-fontSize:16"},{"offset":0,"length":56,"style":"textShadowX:0px"},{"offset":0,"length":56,"style":"fontStretch:normal"},{"offset":0,"length":56,"style":"fontType:regular"},{"offset":0,"length":56,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":56,"style":"textShadowY:4px"},{"offset":0,"length":56,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":56,"style":"lineHeight:135%"},{"offset":0,"length":56,"style":"letterSpacing:0%"},{"offset":0,"length":56,"style":"textHighlightEnable:false"},{"offset":0,"length":56,"style":"textTransform:none"},{"offset":0,"length":56,"style":"color:#020C1C"},{"offset":0,"length":56,"style":"textShadowOpacity:none"},{"offset":0,"length":56,"style":"textDecoration:none"},{"offset":0,"length":56,"style":"borderBottomStyle:none"},{"offset":0,"length":56,"style":"textShadowEnable:false"},{"offset":0,"length":56,"style":"hlnk:"},{"offset":0,"length":56,"style":"fontWeight:normal"},{"offset":0,"length":56,"style":"textShadowBlur:8px"},{"offset":0,"length":56,"style":"fontFamily:Arial"},{"offset":0,"length":56,"style":"overridden:false"},{"offset":0,"length":56,"style":"defaultTextShadow:none"},{"offset":0,"length":56,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":56,"style":"desktop-fontSize:18"},{"offset":0,"length":56,"style":"fontStyle:normal"},{"offset":0,"length":56,"style":"hlnkt:wp"},{"offset":0,"length":56,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":56,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":56,"style":"textOutlineEnable:false"},{"offset":0,"length":56,"style":"opacity:1"},{"offset":0,"length":56,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":56,"style":"mobile-fontSize:16"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"dtsnm","text":"understand","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"mobile-fontSize:16"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"textShadow:none"},{"offset":0,"length":10,"style":"tablet-fontSize:16"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"fontType:regular"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"textShadowY:4px"},{"offset":0,"length":10,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":10,"style":"lineHeight:135%"},{"offset":0,"length":10,"style":"letterSpacing:0%"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"textTransform:none"},{"offset":0,"length":10,"style":"color:#020C1C"},{"offset":0,"length":10,"style":"textShadowOpacity:none"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"textShadowBlur:8px"},{"offset":0,"length":10,"style":"fontFamily:Arial"},{"offset":0,"length":10,"style":"overridden:false"},{"offset":0,"length":10,"style":"defaultTextShadow:none"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"desktop-fontSize:18"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"q16j","text":"• Work closely with team members across different time ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"hlnkt:wp"},{"offset":0,"length":55,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":55,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":55,"style":"mobile-fontSize:16"},{"offset":0,"length":55,"style":"hlnke:true"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"textShadow:none"},{"offset":0,"length":55,"style":"tablet-fontSize:16"},{"offset":0,"length":55,"style":"textShadowX:0px"},{"offset":0,"length":55,"style":"fontStretch:normal"},{"offset":0,"length":55,"style":"fontType:regular"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":55,"style":"textShadowY:4px"},{"offset":0,"length":55,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":55,"style":"lineHeight:135%"},{"offset":0,"length":55,"style":"letterSpacing:0%"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textTransform:none"},{"offset":0,"length":55,"style":"color:#020C1C"},{"offset":0,"length":55,"style":"textShadowOpacity:none"},{"offset":0,"length":55,"style":"textDecoration:none"},{"offset":0,"length":55,"style":"borderBottomStyle:none"},{"offset":0,"length":55,"style":"textShadowEnable:false"},{"offset":0,"length":55,"style":"hlnk:"},{"offset":0,"length":55,"style":"fontWeight:normal"},{"offset":0,"length":55,"style":"textShadowBlur:8px"},{"offset":0,"length":55,"style":"fontFamily:Arial"},{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"defaultTextShadow:none"},{"offset":0,"length":55,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":55,"style":"desktop-fontSize:18"},{"offset":0,"length":55,"style":"fontStyle:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"6h98r","text":"zones","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"overridden:false"},{"offset":0,"length":5,"style":"defaultTextShadow:none"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":5,"style":"desktop-fontSize:18"},{"offset":0,"length":5,"style":"fontStyle:normal"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":5,"style":"mobile-fontSize:16"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadow:none"},{"offset":0,"length":5,"style":"tablet-fontSize:16"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"fontStretch:normal"},{"offset":0,"length":5,"style":"fontType:regular"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"textShadowY:4px"},{"offset":0,"length":5,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":5,"style":"lineHeight:135%"},{"offset":0,"length":5,"style":"letterSpacing:0%"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textTransform:none"},{"offset":0,"length":5,"style":"color:#020C1C"},{"offset":0,"length":5,"style":"textShadowOpacity:none"},{"offset":0,"length":5,"style":"textDecoration:none"},{"offset":0,"length":5,"style":"borderBottomStyle:none"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"fontWeight:normal"},{"offset":0,"length":5,"style":"textShadowBlur:8px"},{"offset":0,"length":5,"style":"fontFamily:Arial"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7367]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7367c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:7367,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7367',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si7377:{
name:'Button_64',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7377c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01342.svg","size":"medium","position":0,"offset":0},"normal":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"b9gqa","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"selected":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9717d","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"disabled":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"d9m1p","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"hover":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"67smk","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"visited":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"818ga","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}}}',
parentGroup:'si7329',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7377]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7377c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7377,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7377',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si7393:{
name:'Node_8',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7393c',
tag:'container-timeline-node-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"timeline-widget-time":true,"isDerivedFromChild":true},"isVisible":false,"canBeCard":false,"imageHeight":200}',
parentGroup:'si7263',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7401',
t:1250
}
,{
n:'si7411',
t:1268
}
,{
n:'si7443',
t:1268
}
]
,
containerType:'timeline-widget-node',
widgetProps:'{"visibilityInfo":{"timeline-widget-time":true,"isDerivedFromChild":true},"isVisible":false,"canBeCard":false,"imageHeight":200}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7263',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7393c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7393,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7393',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7401:{
name:'Text_100',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7401c',
tag:'timeline-widget-time-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridColumn":"1","gridRow":"2","padding":"0px 0px 12px 0px"},"tablet":{"gridColumn":"1","gridRow":"2","marginRight":"20px"},"mobile":{"gridColumn":"1","gridRow":"2"}}}',
parentGroup:'si7393',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"5jlrj","text":"2019","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7401]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7401c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:7401,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7401',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si7411:{
name:'Graphic_Button_Container_8',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7411c',
tag:'container-graphic-button-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridTemplateRows":"1fr","gridTemplateColumns":"1fr","gridColumn":"2","gridRow":"2","paddingBottom":"0px","transform":"rotate(0deg)"},"tablet":{"gridColumn":"2","gridRow":"2","transform":"rotate(0deg)","paddingBottom":"0px"},"mobile":{"gridColumn":"2","gridRow":"2","transform":"rotate(0deg)","paddingBottom":"0px"}}}',
parentGroup:'si7393',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7419',
t:1268
}
,{
n:'si7427',
t:29
}
]
,
containerType:'timeline-widget-graphic-button',
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridTemplateRows":"1fr","gridTemplateColumns":"1fr","gridColumn":"2","gridRow":"2","paddingBottom":"0px","transform":"rotate(0deg)"},"tablet":{"gridColumn":"2","gridRow":"2","transform":"rotate(0deg)","paddingBottom":"0px"},"mobile":{"gridColumn":"2","gridRow":"2","transform":"rotate(0deg)","paddingBottom":"0px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7393',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7411c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7411,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7411',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7419:{
name:'Timeline_Graphic_8',
type:1268,
from:1,
to:0,
rp:0,
rpa:0,
mdi:'si7419c',
tag:'container-graphic-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"width":"6px","height":"100%","margin":"10px 0","gridRow":"1","gridColumn":"1","background":"#edeae2"},"tablet":{"width":"6px","height":"100%"},"mobile":{"width":"6px","height":"100%"}}}',
parentGroup:'si7411',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'timeline-widget-graphic',
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"width":"6px","height":"100%","margin":"10px 0","gridRow":"1","gridColumn":"1","background":"#edeae2"},"tablet":{"width":"6px","height":"100%"},"mobile":{"width":"6px","height":"100%"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7411',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7419c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7419,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7419',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7427:{
name:'Button_65',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7427c',
tag:'timeline-node-button-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"amqit","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"l7ob","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{"all":{"width":"40px","height":"40px","opacity":"1","gridRow":"1","gridColumn":"1","borderRadius":"30px","zIndex":1},"tablet":{},"mobile":{}},"iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cjojs","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"},{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"f8mt2","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"},{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"43sao","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si7411',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7427]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7427c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7427,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7427',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si7443:{
name:'Node_content_8',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7443c',
tag:'container-node-content-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"imageHeight":200,"visibilityInfo":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"padding":"20px 0px","gridRowStart":"2","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"span 4"},"tablet":{"gridRowStart":"2","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"},"mobile":{"gridRowStart":"2","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"}}}',
parentGroup:'si7393',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7451',
t:1268
}
]
,
containerType:'timeline-node-content',
widgetProps:'{"canBeCard":false,"imageHeight":200,"visibilityInfo":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"padding":"20px 0px","gridRowStart":"2","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"span 4"},"tablet":{"gridRowStart":"2","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"},"mobile":{"gridRowStart":"2","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7393',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7443c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7443,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7443',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7451:{
name:'Image_Grid_Group_8',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7451c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true},"padding":{"top":24,"bottom":24,"left":24,"right":24},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"10px","alignItems":"center"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"}}}',
parentGroup:'si7443',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7459',
t:15
}
,{
n:'si7471',
t:1268
}
,{
n:'si7499',
t:29
}
]
,
containerType:'image-grid-card',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true},"padding":{"top":24,"bottom":24,"left":24,"right":24},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"10px","alignItems":"center"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7443',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si7451c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7451,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7451',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c2)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7459:{
name:'300518517_479238890880702_6084045686714686030_n_2',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7459c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"50%","width":"210px","height":"200px"},"tablet":{"width":"200px"},"mobile":{"width":"200px"}}}',
parentGroup:'si7451',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
o:100,
irw:1638,
irh:1638,
w:1638,
h:1638,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7459]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7459c:{
b:[0,0,1638,1638],
fh:false,
fw:false,
uid:7459,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/03621.jpg',
dn:'si7459',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1639,1639],
vb:[-1,-1,1639,1639]
},
si7471:{
name:'Image_Group_Text_11',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7471c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0}}',
parentGroup:'si7451',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7479',
t:1250
}
,{
n:'si7489',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7451',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7471c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7471,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7471',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7479:{
name:'Text_101',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7479c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"padding":"24px 0px  12px 0px","width":"350px"},"tablet":{"width":"100%"},"mobile":{"width":"100%"}}}',
parentGroup:'si7471',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"91qkq","text":"Graphic Designer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":16,"style":"textOutlineEnable:false"},{"offset":0,"length":16,"style":"opacity:1"},{"offset":0,"length":16,"style":"hlnke:true"},{"offset":0,"length":16,"style":"backgroundColor:unset"},{"offset":0,"length":16,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":16,"style":"textHighlightEnable:false"},{"offset":0,"length":16,"style":"textShadowEnable:false"},{"offset":0,"length":16,"style":"overridden:false"},{"offset":0,"length":16,"style":"hlnk:"},{"offset":0,"length":16,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7479]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7479c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:7479,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7479',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si7489:{
name:'Text_102',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7489c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"width":"350px"},"tablet":{"width":"100%"},"mobile":{"width":"100%"}}}',
parentGroup:'si7471',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"7l0f0","text":"• Marketing Team member","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":23,"style":"textDecoration:none"},{"offset":0,"length":23,"style":"borderBottomStyle:none"},{"offset":0,"length":23,"style":"textShadowEnable:false"},{"offset":0,"length":23,"style":"hlnk:"},{"offset":0,"length":23,"style":"fontWeight:normal"},{"offset":0,"length":23,"style":"textShadowBlur:8px"},{"offset":0,"length":23,"style":"fontFamily:Arial"},{"offset":0,"length":23,"style":"overridden:false"},{"offset":0,"length":23,"style":"defaultTextShadow:none"},{"offset":0,"length":23,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":23,"style":"desktop-fontSize:18"},{"offset":0,"length":23,"style":"fontStyle:normal"},{"offset":0,"length":23,"style":"hlnkt:wp"},{"offset":0,"length":23,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":23,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":23,"style":"textOutlineEnable:false"},{"offset":0,"length":23,"style":"opacity:1"},{"offset":0,"length":23,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":23,"style":"mobile-fontSize:16"},{"offset":0,"length":23,"style":"hlnke:true"},{"offset":0,"length":23,"style":"backgroundColor:unset"},{"offset":0,"length":23,"style":"textShadow:none"},{"offset":0,"length":23,"style":"tablet-fontSize:16"},{"offset":0,"length":23,"style":"textShadowX:0px"},{"offset":0,"length":23,"style":"fontStretch:normal"},{"offset":0,"length":23,"style":"fontType:regular"},{"offset":0,"length":23,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":23,"style":"textShadowY:4px"},{"offset":0,"length":23,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":23,"style":"lineHeight:135%"},{"offset":0,"length":23,"style":"letterSpacing:0%"},{"offset":0,"length":23,"style":"textHighlightEnable:false"},{"offset":0,"length":23,"style":"textTransform:none"},{"offset":0,"length":23,"style":"color:#020C1C"},{"offset":0,"length":23,"style":"textShadowOpacity:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"btmu0","text":"• Created illustrations for company posters and videos ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"textTransform:none"},{"offset":0,"length":55,"style":"color:#020C1C"},{"offset":0,"length":55,"style":"textShadowOpacity:none"},{"offset":0,"length":55,"style":"textDecoration:none"},{"offset":0,"length":55,"style":"borderBottomStyle:none"},{"offset":0,"length":55,"style":"textShadowEnable:false"},{"offset":0,"length":55,"style":"hlnk:"},{"offset":0,"length":55,"style":"fontWeight:normal"},{"offset":0,"length":55,"style":"textShadowBlur:8px"},{"offset":0,"length":55,"style":"fontFamily:Arial"},{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"defaultTextShadow:none"},{"offset":0,"length":55,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":55,"style":"desktop-fontSize:18"},{"offset":0,"length":55,"style":"fontStyle:normal"},{"offset":0,"length":55,"style":"hlnkt:wp"},{"offset":0,"length":55,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":55,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":55,"style":"mobile-fontSize:16"},{"offset":0,"length":55,"style":"hlnke:true"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"textShadow:none"},{"offset":0,"length":55,"style":"tablet-fontSize:16"},{"offset":0,"length":55,"style":"textShadowX:0px"},{"offset":0,"length":55,"style":"fontStretch:normal"},{"offset":0,"length":55,"style":"fontType:regular"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":55,"style":"textShadowY:4px"},{"offset":0,"length":55,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":55,"style":"lineHeight:135%"},{"offset":0,"length":55,"style":"letterSpacing:0%"},{"offset":0,"length":55,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"3vevo","text":"for digital and print use for communicating messages ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":53,"style":"lineHeight:135%"},{"offset":0,"length":53,"style":"letterSpacing:0%"},{"offset":0,"length":53,"style":"textHighlightEnable:false"},{"offset":0,"length":53,"style":"textTransform:none"},{"offset":0,"length":53,"style":"color:#020C1C"},{"offset":0,"length":53,"style":"textShadowOpacity:none"},{"offset":0,"length":53,"style":"textDecoration:none"},{"offset":0,"length":53,"style":"borderBottomStyle:none"},{"offset":0,"length":53,"style":"textShadowEnable:false"},{"offset":0,"length":53,"style":"hlnk:"},{"offset":0,"length":53,"style":"fontWeight:normal"},{"offset":0,"length":53,"style":"textShadowBlur:8px"},{"offset":0,"length":53,"style":"fontFamily:Arial"},{"offset":0,"length":53,"style":"overridden:false"},{"offset":0,"length":53,"style":"defaultTextShadow:none"},{"offset":0,"length":53,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":53,"style":"desktop-fontSize:18"},{"offset":0,"length":53,"style":"fontStyle:normal"},{"offset":0,"length":53,"style":"hlnkt:wp"},{"offset":0,"length":53,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":53,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":53,"style":"textOutlineEnable:false"},{"offset":0,"length":53,"style":"opacity:1"},{"offset":0,"length":53,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":53,"style":"mobile-fontSize:16"},{"offset":0,"length":53,"style":"hlnke:true"},{"offset":0,"length":53,"style":"backgroundColor:unset"},{"offset":0,"length":53,"style":"textShadow:none"},{"offset":0,"length":53,"style":"tablet-fontSize:16"},{"offset":0,"length":53,"style":"textShadowX:0px"},{"offset":0,"length":53,"style":"fontStretch:normal"},{"offset":0,"length":53,"style":"fontType:regular"},{"offset":0,"length":53,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":53,"style":"textShadowY:4px"},{"offset":0,"length":53,"style":"textShadowColor:#F1EEE61F"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"7nevp","text":"and social media posts","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":22,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":22,"style":"textShadowY:4px"},{"offset":0,"length":22,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":22,"style":"lineHeight:135%"},{"offset":0,"length":22,"style":"letterSpacing:0%"},{"offset":0,"length":22,"style":"textHighlightEnable:false"},{"offset":0,"length":22,"style":"textTransform:none"},{"offset":0,"length":22,"style":"color:#020C1C"},{"offset":0,"length":22,"style":"textShadowOpacity:none"},{"offset":0,"length":22,"style":"textDecoration:none"},{"offset":0,"length":22,"style":"borderBottomStyle:none"},{"offset":0,"length":22,"style":"textShadowEnable:false"},{"offset":0,"length":22,"style":"hlnk:"},{"offset":0,"length":22,"style":"fontWeight:normal"},{"offset":0,"length":22,"style":"textShadowBlur:8px"},{"offset":0,"length":22,"style":"fontFamily:Arial"},{"offset":0,"length":22,"style":"overridden:false"},{"offset":0,"length":22,"style":"defaultTextShadow:none"},{"offset":0,"length":22,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":22,"style":"desktop-fontSize:18"},{"offset":0,"length":22,"style":"fontStyle:normal"},{"offset":0,"length":22,"style":"hlnkt:wp"},{"offset":0,"length":22,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":22,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":22,"style":"textOutlineEnable:false"},{"offset":0,"length":22,"style":"opacity:1"},{"offset":0,"length":22,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":22,"style":"mobile-fontSize:16"},{"offset":0,"length":22,"style":"hlnke:true"},{"offset":0,"length":22,"style":"backgroundColor:unset"},{"offset":0,"length":22,"style":"textShadow:none"},{"offset":0,"length":22,"style":"tablet-fontSize:16"},{"offset":0,"length":22,"style":"textShadowX:0px"},{"offset":0,"length":22,"style":"fontStretch:normal"},{"offset":0,"length":22,"style":"fontType:regular"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"farnr","text":"• Designed layout designs for trainings","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":39,"style":"textShadowX:0px"},{"offset":0,"length":39,"style":"fontStretch:normal"},{"offset":0,"length":39,"style":"fontType:regular"},{"offset":0,"length":39,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":39,"style":"textShadowY:4px"},{"offset":0,"length":39,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":39,"style":"lineHeight:135%"},{"offset":0,"length":39,"style":"letterSpacing:0%"},{"offset":0,"length":39,"style":"textHighlightEnable:false"},{"offset":0,"length":39,"style":"textTransform:none"},{"offset":0,"length":39,"style":"color:#020C1C"},{"offset":0,"length":39,"style":"textShadowOpacity:none"},{"offset":0,"length":39,"style":"textDecoration:none"},{"offset":0,"length":39,"style":"borderBottomStyle:none"},{"offset":0,"length":39,"style":"textShadowEnable:false"},{"offset":0,"length":39,"style":"hlnk:"},{"offset":0,"length":39,"style":"fontWeight:normal"},{"offset":0,"length":39,"style":"textShadowBlur:8px"},{"offset":0,"length":39,"style":"fontFamily:Arial"},{"offset":0,"length":39,"style":"overridden:false"},{"offset":0,"length":39,"style":"defaultTextShadow:none"},{"offset":0,"length":39,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":39,"style":"desktop-fontSize:18"},{"offset":0,"length":39,"style":"fontStyle:normal"},{"offset":0,"length":39,"style":"hlnkt:wp"},{"offset":0,"length":39,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":39,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":39,"style":"textOutlineEnable:false"},{"offset":0,"length":39,"style":"opacity:1"},{"offset":0,"length":39,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":39,"style":"mobile-fontSize:16"},{"offset":0,"length":39,"style":"hlnke:true"},{"offset":0,"length":39,"style":"backgroundColor:unset"},{"offset":0,"length":39,"style":"textShadow:none"},{"offset":0,"length":39,"style":"tablet-fontSize:16"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"7gnnj","text":"• Developed interactive PPT for marketing","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":41,"style":"backgroundColor:unset"},{"offset":0,"length":41,"style":"textShadow:none"},{"offset":0,"length":41,"style":"tablet-fontSize:16"},{"offset":0,"length":41,"style":"textShadowX:0px"},{"offset":0,"length":41,"style":"fontStretch:normal"},{"offset":0,"length":41,"style":"fontType:regular"},{"offset":0,"length":41,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":41,"style":"textShadowY:4px"},{"offset":0,"length":41,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":41,"style":"lineHeight:135%"},{"offset":0,"length":41,"style":"letterSpacing:0%"},{"offset":0,"length":41,"style":"textHighlightEnable:false"},{"offset":0,"length":41,"style":"textTransform:none"},{"offset":0,"length":41,"style":"color:#020C1C"},{"offset":0,"length":41,"style":"textShadowOpacity:none"},{"offset":0,"length":41,"style":"textDecoration:none"},{"offset":0,"length":41,"style":"borderBottomStyle:none"},{"offset":0,"length":41,"style":"textShadowEnable:false"},{"offset":0,"length":41,"style":"hlnk:"},{"offset":0,"length":41,"style":"fontWeight:normal"},{"offset":0,"length":41,"style":"textShadowBlur:8px"},{"offset":0,"length":41,"style":"fontFamily:Arial"},{"offset":0,"length":41,"style":"overridden:false"},{"offset":0,"length":41,"style":"defaultTextShadow:none"},{"offset":0,"length":41,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":41,"style":"desktop-fontSize:18"},{"offset":0,"length":41,"style":"fontStyle:normal"},{"offset":0,"length":41,"style":"hlnkt:wp"},{"offset":0,"length":41,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":41,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":41,"style":"textOutlineEnable:false"},{"offset":0,"length":41,"style":"opacity:1"},{"offset":0,"length":41,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":41,"style":"mobile-fontSize:16"},{"offset":0,"length":41,"style":"hlnke:true"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7489]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7489c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:7489,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7489',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si7499:{
name:'Button_66',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7499c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01342.svg","size":"medium","position":0,"offset":0},"normal":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dj77o","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"selected":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6cfsr","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"disabled":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5rht3","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"hover":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dgstl","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"visited":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"95p6m","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}}}',
parentGroup:'si7451',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7499]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7499c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7499,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7499',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si7515:{
name:'Node_9',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7515c',
tag:'container-timeline-node-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"timeline-widget-time":true,"isDerivedFromChild":true},"isVisible":false,"canBeCard":false,"imageHeight":200}',
parentGroup:'si7263',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7523',
t:1250
}
,{
n:'si7533',
t:1268
}
,{
n:'si7565',
t:1268
}
]
,
containerType:'timeline-widget-node',
widgetProps:'{"visibilityInfo":{"timeline-widget-time":true,"isDerivedFromChild":true},"isVisible":false,"canBeCard":false,"imageHeight":200}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7263',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7515c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7515,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7515',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7523:{
name:'Text_103',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7523c',
tag:'timeline-widget-time-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridColumn":"1","gridRow":"3","padding":"0px 0px 12px 0px"},"tablet":{"gridColumn":"1","gridRow":"3","marginRight":"20px"},"mobile":{"gridColumn":"1","gridRow":"3"}}}',
parentGroup:'si7515',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"mn7","text":"2015","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-subheading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7523]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7523c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:7523,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7523',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si7533:{
name:'Graphic_Button_Container_9',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7533c',
tag:'container-graphic-button-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridTemplateRows":"1fr","gridTemplateColumns":"1fr","gridColumn":"2","gridRow":"3","paddingBottom":"0px","transform":"rotate(0deg)"},"tablet":{"gridColumn":"2","gridRow":"3","transform":"rotate(0deg)","paddingBottom":"0px"},"mobile":{"gridColumn":"2","gridRow":"3","transform":"rotate(0deg)","paddingBottom":"0px"}}}',
parentGroup:'si7515',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7541',
t:1268
}
,{
n:'si7549',
t:29
}
]
,
containerType:'timeline-widget-graphic-button',
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridTemplateRows":"1fr","gridTemplateColumns":"1fr","gridColumn":"2","gridRow":"3","paddingBottom":"0px","transform":"rotate(0deg)"},"tablet":{"gridColumn":"2","gridRow":"3","transform":"rotate(0deg)","paddingBottom":"0px"},"mobile":{"gridColumn":"2","gridRow":"3","transform":"rotate(0deg)","paddingBottom":"0px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7515',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7533c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7533,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7533',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7541:{
name:'Timeline_Graphic_9',
type:1268,
from:1,
to:0,
rp:0,
rpa:0,
mdi:'si7541c',
tag:'container-graphic-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"width":"6px","height":"100%","margin":"10px 0","gridRow":"1","gridColumn":"1","background":"#edeae2"},"tablet":{"width":"6px","height":"100%"},"mobile":{"width":"6px","height":"100%"}}}',
parentGroup:'si7533',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'timeline-widget-graphic',
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"width":"6px","height":"100%","margin":"10px 0","gridRow":"1","gridColumn":"1","background":"#edeae2"},"tablet":{"width":"6px","height":"100%"},"mobile":{"width":"6px","height":"100%"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7533',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7541c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7541,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7541',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7549:{
name:'Button_67',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7549c',
tag:'timeline-node-button-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"algan","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"219li","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{"all":{"width":"40px","height":"40px","opacity":"1","gridRow":"1","gridColumn":"1","borderRadius":"30px","zIndex":1},"tablet":{},"mobile":{}},"iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a03rm","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"},{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cqald","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"},{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9fh31","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si7533',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7549]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7549c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7549,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7549',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si7565:{
name:'Node_content_9',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7565c',
tag:'container-node-content-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"imageHeight":200,"visibilityInfo":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"padding":"20px 0px","gridRowStart":"3","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"span 4"},"tablet":{"gridRowStart":"3","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"},"mobile":{"gridRowStart":"3","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"}}}',
parentGroup:'si7515',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7573',
t:1268
}
]
,
containerType:'timeline-node-content',
widgetProps:'{"canBeCard":false,"imageHeight":200,"visibilityInfo":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"padding":"20px 0px","gridRowStart":"3","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"span 4"},"tablet":{"gridRowStart":"3","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"},"mobile":{"gridRowStart":"3","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7515',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7565c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7565,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7565',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7573:{
name:'Image_Grid_Group_9',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7573c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true},"padding":{"top":24,"bottom":24,"left":24,"right":24},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"10px","alignItems":"center"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"}}}',
parentGroup:'si7565',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7581',
t:15
}
,{
n:'si7593',
t:1268
}
,{
n:'si7621',
t:29
}
]
,
containerType:'image-grid-card',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true},"padding":{"top":24,"bottom":24,"left":24,"right":24},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"10px","alignItems":"center"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7565',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si7573c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7573,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7573',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c2)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7581:{
name:'300518517_479238890880702_6084045686714686030_n_3',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7581c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"50%","width":"210px","height":"200px"},"tablet":{"width":"200px"},"mobile":{"width":"200px"}}}',
parentGroup:'si7573',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
o:100,
irw:1638,
irh:1638,
w:1638,
h:1638,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7581]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7581c:{
b:[0,0,1638,1638],
fh:false,
fw:false,
uid:7581,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/03621.jpg',
dn:'si7581',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1639,1639],
vb:[-1,-1,1639,1639]
},
si7593:{
name:'Image_Group_Text_12',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7593c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0}}',
parentGroup:'si7573',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7601',
t:1250
}
,{
n:'si7611',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7573',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7593c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7593,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7593',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7601:{
name:'Text_104',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7601c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"padding":"24px 0px  12px 0px","width":"350px"},"tablet":{"width":"100%"},"mobile":{"width":"100%"}}}',
parentGroup:'si7593',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"euudf","text":"Quality Engineer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":16,"style":"hlnk:"},{"offset":0,"length":16,"style":"hlnkt:wp"},{"offset":0,"length":16,"style":"textOutlineEnable:false"},{"offset":0,"length":16,"style":"opacity:1"},{"offset":0,"length":16,"style":"hlnke:true"},{"offset":0,"length":16,"style":"backgroundColor:unset"},{"offset":0,"length":16,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":16,"style":"textHighlightEnable:false"},{"offset":0,"length":16,"style":"textShadowEnable:false"},{"offset":0,"length":16,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7601]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7601c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:7601,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7601',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si7611:{
name:'Text_105',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7611c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"width":"350px"},"tablet":{"width":"100%"},"mobile":{"width":"100%"}}}',
parentGroup:'si7593',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"ce4lt","text":"• Quality Assurance (QA) Specialist","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":35,"style":"hlnkt:wp"},{"offset":0,"length":35,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":35,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":35,"style":"textOutlineEnable:false"},{"offset":0,"length":35,"style":"opacity:1"},{"offset":0,"length":35,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":35,"style":"mobile-fontSize:16"},{"offset":0,"length":35,"style":"hlnke:true"},{"offset":0,"length":35,"style":"backgroundColor:unset"},{"offset":0,"length":35,"style":"textShadow:none"},{"offset":0,"length":35,"style":"tablet-fontSize:16"},{"offset":0,"length":35,"style":"textShadowX:0px"},{"offset":0,"length":35,"style":"fontStretch:normal"},{"offset":0,"length":35,"style":"fontType:regular"},{"offset":0,"length":35,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":35,"style":"textShadowY:4px"},{"offset":0,"length":35,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":35,"style":"lineHeight:135%"},{"offset":0,"length":35,"style":"letterSpacing:0%"},{"offset":0,"length":35,"style":"textHighlightEnable:false"},{"offset":0,"length":35,"style":"textTransform:none"},{"offset":0,"length":35,"style":"color:#020C1C"},{"offset":0,"length":35,"style":"textShadowOpacity:none"},{"offset":0,"length":35,"style":"textDecoration:none"},{"offset":0,"length":35,"style":"borderBottomStyle:none"},{"offset":0,"length":35,"style":"textShadowEnable:false"},{"offset":0,"length":35,"style":"hlnk:"},{"offset":0,"length":35,"style":"fontWeight:normal"},{"offset":0,"length":35,"style":"textShadowBlur:8px"},{"offset":0,"length":35,"style":"fontFamily:Arial"},{"offset":0,"length":35,"style":"overridden:false"},{"offset":0,"length":35,"style":"defaultTextShadow:none"},{"offset":0,"length":35,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":35,"style":"desktop-fontSize:18"},{"offset":0,"length":35,"style":"fontStyle:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"2gjf8","text":"• Responsible for the incoming raw material quality ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":52,"style":"overridden:false"},{"offset":0,"length":52,"style":"defaultTextShadow:none"},{"offset":0,"length":52,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":52,"style":"desktop-fontSize:18"},{"offset":0,"length":52,"style":"fontStyle:normal"},{"offset":0,"length":52,"style":"hlnkt:wp"},{"offset":0,"length":52,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":52,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":52,"style":"textOutlineEnable:false"},{"offset":0,"length":52,"style":"opacity:1"},{"offset":0,"length":52,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":52,"style":"mobile-fontSize:16"},{"offset":0,"length":52,"style":"hlnke:true"},{"offset":0,"length":52,"style":"backgroundColor:unset"},{"offset":0,"length":52,"style":"textShadow:none"},{"offset":0,"length":52,"style":"tablet-fontSize:16"},{"offset":0,"length":52,"style":"textShadowX:0px"},{"offset":0,"length":52,"style":"fontStretch:normal"},{"offset":0,"length":52,"style":"fontType:regular"},{"offset":0,"length":52,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":52,"style":"textShadowY:4px"},{"offset":0,"length":52,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":52,"style":"lineHeight:135%"},{"offset":0,"length":52,"style":"letterSpacing:0%"},{"offset":0,"length":52,"style":"textHighlightEnable:false"},{"offset":0,"length":52,"style":"textTransform:none"},{"offset":0,"length":52,"style":"color:#020C1C"},{"offset":0,"length":52,"style":"textShadowOpacity:none"},{"offset":0,"length":52,"style":"textDecoration:none"},{"offset":0,"length":52,"style":"borderBottomStyle:none"},{"offset":0,"length":52,"style":"textShadowEnable:false"},{"offset":0,"length":52,"style":"hlnk:"},{"offset":0,"length":52,"style":"fontWeight:normal"},{"offset":0,"length":52,"style":"textShadowBlur:8px"},{"offset":0,"length":52,"style":"fontFamily:Arial"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"4jl92","text":"that is used for manufacturing the products in the ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":51,"style":"fontWeight:normal"},{"offset":0,"length":51,"style":"textShadowBlur:8px"},{"offset":0,"length":51,"style":"fontFamily:Arial"},{"offset":0,"length":51,"style":"overridden:false"},{"offset":0,"length":51,"style":"defaultTextShadow:none"},{"offset":0,"length":51,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":51,"style":"desktop-fontSize:18"},{"offset":0,"length":51,"style":"fontStyle:normal"},{"offset":0,"length":51,"style":"hlnkt:wp"},{"offset":0,"length":51,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":51,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":51,"style":"textOutlineEnable:false"},{"offset":0,"length":51,"style":"opacity:1"},{"offset":0,"length":51,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":51,"style":"mobile-fontSize:16"},{"offset":0,"length":51,"style":"hlnke:true"},{"offset":0,"length":51,"style":"backgroundColor:unset"},{"offset":0,"length":51,"style":"textShadow:none"},{"offset":0,"length":51,"style":"tablet-fontSize:16"},{"offset":0,"length":51,"style":"textShadowX:0px"},{"offset":0,"length":51,"style":"fontStretch:normal"},{"offset":0,"length":51,"style":"fontType:regular"},{"offset":0,"length":51,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":51,"style":"textShadowY:4px"},{"offset":0,"length":51,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":51,"style":"lineHeight:135%"},{"offset":0,"length":51,"style":"letterSpacing:0%"},{"offset":0,"length":51,"style":"textHighlightEnable:false"},{"offset":0,"length":51,"style":"textTransform:none"},{"offset":0,"length":51,"style":"color:#020C1C"},{"offset":0,"length":51,"style":"textShadowOpacity:none"},{"offset":0,"length":51,"style":"textDecoration:none"},{"offset":0,"length":51,"style":"borderBottomStyle:none"},{"offset":0,"length":51,"style":"textShadowEnable:false"},{"offset":0,"length":51,"style":"hlnk:"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"84bg9","text":"company","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":7,"style":"borderBottomStyle:none"},{"offset":0,"length":7,"style":"textShadowEnable:false"},{"offset":0,"length":7,"style":"hlnk:"},{"offset":0,"length":7,"style":"fontWeight:normal"},{"offset":0,"length":7,"style":"textShadowBlur:8px"},{"offset":0,"length":7,"style":"fontFamily:Arial"},{"offset":0,"length":7,"style":"overridden:false"},{"offset":0,"length":7,"style":"defaultTextShadow:none"},{"offset":0,"length":7,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":7,"style":"desktop-fontSize:18"},{"offset":0,"length":7,"style":"fontStyle:normal"},{"offset":0,"length":7,"style":"hlnkt:wp"},{"offset":0,"length":7,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":7,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":7,"style":"textOutlineEnable:false"},{"offset":0,"length":7,"style":"opacity:1"},{"offset":0,"length":7,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":7,"style":"mobile-fontSize:16"},{"offset":0,"length":7,"style":"hlnke:true"},{"offset":0,"length":7,"style":"backgroundColor:unset"},{"offset":0,"length":7,"style":"textShadow:none"},{"offset":0,"length":7,"style":"tablet-fontSize:16"},{"offset":0,"length":7,"style":"textShadowX:0px"},{"offset":0,"length":7,"style":"fontStretch:normal"},{"offset":0,"length":7,"style":"fontType:regular"},{"offset":0,"length":7,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":7,"style":"textShadowY:4px"},{"offset":0,"length":7,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":7,"style":"lineHeight:135%"},{"offset":0,"length":7,"style":"letterSpacing:0%"},{"offset":0,"length":7,"style":"textHighlightEnable:false"},{"offset":0,"length":7,"style":"textTransform:none"},{"offset":0,"length":7,"style":"color:#020C1C"},{"offset":0,"length":7,"style":"textShadowOpacity:none"},{"offset":0,"length":7,"style":"textDecoration:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"8iiee","text":"• Ensured that the raw material meets the quality ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":50,"style":"color:#020C1C"},{"offset":0,"length":50,"style":"textShadowOpacity:none"},{"offset":0,"length":50,"style":"textDecoration:none"},{"offset":0,"length":50,"style":"borderBottomStyle:none"},{"offset":0,"length":50,"style":"textShadowEnable:false"},{"offset":0,"length":50,"style":"hlnk:"},{"offset":0,"length":50,"style":"fontWeight:normal"},{"offset":0,"length":50,"style":"textShadowBlur:8px"},{"offset":0,"length":50,"style":"fontFamily:Arial"},{"offset":0,"length":50,"style":"overridden:false"},{"offset":0,"length":50,"style":"defaultTextShadow:none"},{"offset":0,"length":50,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":50,"style":"desktop-fontSize:18"},{"offset":0,"length":50,"style":"fontStyle:normal"},{"offset":0,"length":50,"style":"hlnkt:wp"},{"offset":0,"length":50,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":50,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":50,"style":"textOutlineEnable:false"},{"offset":0,"length":50,"style":"opacity:1"},{"offset":0,"length":50,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":50,"style":"mobile-fontSize:16"},{"offset":0,"length":50,"style":"hlnke:true"},{"offset":0,"length":50,"style":"backgroundColor:unset"},{"offset":0,"length":50,"style":"textShadow:none"},{"offset":0,"length":50,"style":"tablet-fontSize:16"},{"offset":0,"length":50,"style":"textShadowX:0px"},{"offset":0,"length":50,"style":"fontStretch:normal"},{"offset":0,"length":50,"style":"fontType:regular"},{"offset":0,"length":50,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":50,"style":"textShadowY:4px"},{"offset":0,"length":50,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":50,"style":"lineHeight:135%"},{"offset":0,"length":50,"style":"letterSpacing:0%"},{"offset":0,"length":50,"style":"textHighlightEnable:false"},{"offset":0,"length":50,"style":"textTransform:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"6gvs","text":"standards set by the company","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":28,"style":"letterSpacing:0%"},{"offset":0,"length":28,"style":"textHighlightEnable:false"},{"offset":0,"length":28,"style":"textTransform:none"},{"offset":0,"length":28,"style":"color:#020C1C"},{"offset":0,"length":28,"style":"textShadowOpacity:none"},{"offset":0,"length":28,"style":"textDecoration:none"},{"offset":0,"length":28,"style":"borderBottomStyle:none"},{"offset":0,"length":28,"style":"textShadowEnable:false"},{"offset":0,"length":28,"style":"hlnk:"},{"offset":0,"length":28,"style":"fontWeight:normal"},{"offset":0,"length":28,"style":"textShadowBlur:8px"},{"offset":0,"length":28,"style":"fontFamily:Arial"},{"offset":0,"length":28,"style":"overridden:false"},{"offset":0,"length":28,"style":"defaultTextShadow:none"},{"offset":0,"length":28,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":28,"style":"desktop-fontSize:18"},{"offset":0,"length":28,"style":"fontStyle:normal"},{"offset":0,"length":28,"style":"hlnkt:wp"},{"offset":0,"length":28,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":28,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":28,"style":"textOutlineEnable:false"},{"offset":0,"length":28,"style":"opacity:1"},{"offset":0,"length":28,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":28,"style":"mobile-fontSize:16"},{"offset":0,"length":28,"style":"hlnke:true"},{"offset":0,"length":28,"style":"backgroundColor:unset"},{"offset":0,"length":28,"style":"textShadow:none"},{"offset":0,"length":28,"style":"tablet-fontSize:16"},{"offset":0,"length":28,"style":"textShadowX:0px"},{"offset":0,"length":28,"style":"fontStretch:normal"},{"offset":0,"length":28,"style":"fontType:regular"},{"offset":0,"length":28,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":28,"style":"textShadowY:4px"},{"offset":0,"length":28,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":28,"style":"lineHeight:135%"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"enpki","text":"• Collaborated with suppliers to ensure quality ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":48,"style":"textShadowY:4px"},{"offset":0,"length":48,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":48,"style":"lineHeight:135%"},{"offset":0,"length":48,"style":"letterSpacing:0%"},{"offset":0,"length":48,"style":"textHighlightEnable:false"},{"offset":0,"length":48,"style":"textTransform:none"},{"offset":0,"length":48,"style":"color:#020C1C"},{"offset":0,"length":48,"style":"textShadowOpacity:none"},{"offset":0,"length":48,"style":"textDecoration:none"},{"offset":0,"length":48,"style":"borderBottomStyle:none"},{"offset":0,"length":48,"style":"textShadowEnable:false"},{"offset":0,"length":48,"style":"hlnk:"},{"offset":0,"length":48,"style":"fontWeight:normal"},{"offset":0,"length":48,"style":"textShadowBlur:8px"},{"offset":0,"length":48,"style":"fontFamily:Arial"},{"offset":0,"length":48,"style":"overridden:false"},{"offset":0,"length":48,"style":"defaultTextShadow:none"},{"offset":0,"length":48,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":48,"style":"desktop-fontSize:18"},{"offset":0,"length":48,"style":"fontStyle:normal"},{"offset":0,"length":48,"style":"hlnkt:wp"},{"offset":0,"length":48,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":48,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":48,"style":"textOutlineEnable:false"},{"offset":0,"length":48,"style":"opacity:1"},{"offset":0,"length":48,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":48,"style":"mobile-fontSize:16"},{"offset":0,"length":48,"style":"hlnke:true"},{"offset":0,"length":48,"style":"backgroundColor:unset"},{"offset":0,"length":48,"style":"textShadow:none"},{"offset":0,"length":48,"style":"tablet-fontSize:16"},{"offset":0,"length":48,"style":"textShadowX:0px"},{"offset":0,"length":48,"style":"fontStretch:normal"},{"offset":0,"length":48,"style":"fontType:regular"},{"offset":0,"length":48,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"2rdft","text":"standards were met","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":18,"style":"fontStretch:normal"},{"offset":0,"length":18,"style":"fontType:regular"},{"offset":0,"length":18,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":18,"style":"textShadowY:4px"},{"offset":0,"length":18,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":18,"style":"lineHeight:135%"},{"offset":0,"length":18,"style":"letterSpacing:0%"},{"offset":0,"length":18,"style":"textHighlightEnable:false"},{"offset":0,"length":18,"style":"textTransform:none"},{"offset":0,"length":18,"style":"color:#020C1C"},{"offset":0,"length":18,"style":"textShadowOpacity:none"},{"offset":0,"length":18,"style":"textDecoration:none"},{"offset":0,"length":18,"style":"borderBottomStyle:none"},{"offset":0,"length":18,"style":"textShadowEnable:false"},{"offset":0,"length":18,"style":"hlnk:"},{"offset":0,"length":18,"style":"fontWeight:normal"},{"offset":0,"length":18,"style":"textShadowBlur:8px"},{"offset":0,"length":18,"style":"fontFamily:Arial"},{"offset":0,"length":18,"style":"overridden:false"},{"offset":0,"length":18,"style":"defaultTextShadow:none"},{"offset":0,"length":18,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":18,"style":"desktop-fontSize:18"},{"offset":0,"length":18,"style":"fontStyle:normal"},{"offset":0,"length":18,"style":"hlnkt:wp"},{"offset":0,"length":18,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":18,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":18,"style":"textOutlineEnable:false"},{"offset":0,"length":18,"style":"opacity:1"},{"offset":0,"length":18,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":18,"style":"mobile-fontSize:16"},{"offset":0,"length":18,"style":"hlnke:true"},{"offset":0,"length":18,"style":"backgroundColor:unset"},{"offset":0,"length":18,"style":"textShadow:none"},{"offset":0,"length":18,"style":"tablet-fontSize:16"},{"offset":0,"length":18,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7611]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7611c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:7611,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7611',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si7621:{
name:'Button_68',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7621c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01342.svg","size":"medium","position":0,"offset":0},"normal":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2dv8c","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"selected":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4fndl","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"disabled":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bo97l","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"hover":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dbbh2","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"visited":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9ile1","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}}}',
parentGroup:'si7573',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7621]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7621c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7621,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7621',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si7637:{
name:'Node_10',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7637c',
tag:'container-timeline-node-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"timeline-widget-time":true,"isDerivedFromChild":true},"isVisible":false,"canBeCard":false,"imageHeight":200}',
parentGroup:'si7263',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7645',
t:1250
}
,{
n:'si7655',
t:1268
}
,{
n:'si7687',
t:1268
}
]
,
containerType:'timeline-widget-node',
widgetProps:'{"visibilityInfo":{"timeline-widget-time":true,"isDerivedFromChild":true},"isVisible":false,"canBeCard":false,"imageHeight":200}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7263',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7637c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7637,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7637',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7645:{
name:'Text_106',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7645c',
tag:'timeline-widget-time-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridColumn":"1","gridRow":"4","padding":"0px 0px 12px 0px"},"tablet":{"gridColumn":"1","gridRow":"4","marginRight":"20px"},"mobile":{"gridColumn":"1","gridRow":"4"}}}',
parentGroup:'si7637',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"fsjdu","text":"2003","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7645]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7645c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7645,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7645',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7655:{
name:'Graphic_Button_Container_10',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7655c',
tag:'container-graphic-button-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridTemplateRows":"1fr","gridTemplateColumns":"1fr","gridColumn":"2","gridRow":"4","paddingBottom":"0px","transform":"rotate(0deg)"},"tablet":{"gridColumn":"2","gridRow":"4","transform":"rotate(0deg)","paddingBottom":"0px"},"mobile":{"gridColumn":"2","gridRow":"4","transform":"rotate(0deg)","paddingBottom":"0px"}}}',
parentGroup:'si7637',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7663',
t:1268
}
,{
n:'si7671',
t:29
}
]
,
containerType:'timeline-widget-graphic-button',
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridTemplateRows":"1fr","gridTemplateColumns":"1fr","gridColumn":"2","gridRow":"4","paddingBottom":"0px","transform":"rotate(0deg)"},"tablet":{"gridColumn":"2","gridRow":"4","transform":"rotate(0deg)","paddingBottom":"0px"},"mobile":{"gridColumn":"2","gridRow":"4","transform":"rotate(0deg)","paddingBottom":"0px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7637',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7655c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7655,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7655',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7663:{
name:'Timeline_Graphic_10',
type:1268,
from:1,
to:0,
rp:0,
rpa:0,
mdi:'si7663c',
tag:'container-graphic-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"width":"6px","height":"100%","margin":"10px 0","gridRow":"1","gridColumn":"1","background":"#edeae2"},"tablet":{"width":"6px","height":"100%"},"mobile":{"width":"6px","height":"100%"}}}',
parentGroup:'si7655',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'timeline-widget-graphic',
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"width":"6px","height":"100%","margin":"10px 0","gridRow":"1","gridColumn":"1","background":"#edeae2"},"tablet":{"width":"6px","height":"100%"},"mobile":{"width":"6px","height":"100%"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7655',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7663c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7663,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7663',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7671:{
name:'Button_69',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7671c',
tag:'timeline-node-button-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9rpnm","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9m52v","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{"all":{"width":"40px","height":"40px","opacity":"1","gridRow":"1","gridColumn":"1","borderRadius":"30px","zIndex":1},"tablet":{},"mobile":{}},"iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"b49fh","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8otsl","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bd8g9","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si7655',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7671]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7671c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7671,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7671',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si7687:{
name:'Node_content_10',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7687c',
tag:'container-node-content-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"imageHeight":200,"visibilityInfo":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"padding":"20px 0px","gridRowStart":"4","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"span 4"},"tablet":{"gridRowStart":"4","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"},"mobile":{"gridRowStart":"4","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"}}}',
parentGroup:'si7637',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7695',
t:1268
}
]
,
containerType:'timeline-node-content',
widgetProps:'{"canBeCard":false,"imageHeight":200,"visibilityInfo":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"padding":"20px 0px","gridRowStart":"4","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"span 4"},"tablet":{"gridRowStart":"4","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"},"mobile":{"gridRowStart":"4","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7637',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7687c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7687,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7687',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7695:{
name:'Image_Grid_Group_10',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7695c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true},"padding":{"top":24,"bottom":24,"left":24,"right":24},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"10px","alignItems":"center"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"}}}',
parentGroup:'si7687',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7703',
t:15
}
,{
n:'si7715',
t:1268
}
,{
n:'si7743',
t:29
}
]
,
containerType:'image-grid-card',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true},"padding":{"top":24,"bottom":24,"left":24,"right":24},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"10px","alignItems":"center"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7687',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si7695c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7695,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7695',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c2)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7703:{
name:'image4_1',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7703c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"50%","width":"210px","height":"200px"},"tablet":{"width":"200px"},"mobile":{"width":"200px"}}}',
parentGroup:'si7695',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
o:100,
irw:245,
irh:185,
w:245,
h:185,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7703]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7703c:{
b:[0,0,245,185],
fh:false,
fw:false,
uid:7703,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/03257.png',
dn:'si7703',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,246,186],
vb:[-1,-1,246,186]
},
si7715:{
name:'Image_Group_Text_13',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7715c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0}}',
parentGroup:'si7695',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7723',
t:1250
}
,{
n:'si7733',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7695',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7715c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7715,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7715',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7723:{
name:'Text_107',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7723c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"padding":"24px 0px  12px 0px","width":"350px"},"tablet":{"width":"100%"},"mobile":{"width":"100%"}}}',
parentGroup:'si7715',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"b4prp","text":"Title 04","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7723]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7723c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7723,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7723',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7733:{
name:'Text_108',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7733c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"width":"350px"},"tablet":{"width":"100%"},"mobile":{"width":"100%"}}}',
parentGroup:'si7715',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"3u3fm","text":"Lorem Ipsum is simply dummy text of the printing and typesetting industry.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":74,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":74,"style":"textHighlightEnable:false"},{"offset":0,"length":74,"style":"textShadowEnable:false"},{"offset":0,"length":74,"style":"overridden:false"},{"offset":0,"length":74,"style":"hlnk:"},{"offset":0,"length":74,"style":"hlnkt:wp"},{"offset":0,"length":74,"style":"textOutlineEnable:false"},{"offset":0,"length":74,"style":"opacity:1"},{"offset":0,"length":74,"style":"hlnke:true"},{"offset":0,"length":74,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7733]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7733c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7733,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7733',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7743:{
name:'Button_70',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7743c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01342.svg","size":"medium","position":0,"offset":0},"normal":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6iicb","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"selected":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1r3o8","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"disabled":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6j70a","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"hover":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cbsu1","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"visited":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ehu0l","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}}}',
parentGroup:'si7695',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7743]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7743c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7743,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7743',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si7759:{
name:'Node_11',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7759c',
tag:'container-timeline-node-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"timeline-widget-time":true,"isDerivedFromChild":true},"isVisible":false,"canBeCard":false,"imageHeight":200}',
parentGroup:'si7263',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7767',
t:1250
}
,{
n:'si7777',
t:1268
}
,{
n:'si7809',
t:1268
}
]
,
containerType:'timeline-widget-node',
widgetProps:'{"visibilityInfo":{"timeline-widget-time":true,"isDerivedFromChild":true},"isVisible":false,"canBeCard":false,"imageHeight":200}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7263',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7759c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7759,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7759',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7767:{
name:'Text_109',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7767c',
tag:'timeline-widget-time-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridColumn":"1","gridRow":"5","padding":"0px 0px 12px 0px"},"tablet":{"gridColumn":"1","gridRow":"5","marginRight":"20px"},"mobile":{"gridColumn":"1","gridRow":"5"}}}',
parentGroup:'si7759',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"4l8aa","text":"2004","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7767]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7767c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7767,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7767',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7777:{
name:'Graphic_Button_Container_11',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7777c',
tag:'container-graphic-button-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridTemplateRows":"1fr","gridTemplateColumns":"1fr","gridColumn":"2","gridRow":"5","paddingBottom":"0px","transform":"rotate(0deg)"},"tablet":{"gridColumn":"2","gridRow":"5","transform":"rotate(0deg)","paddingBottom":"0px"},"mobile":{"gridColumn":"2","gridRow":"5","transform":"rotate(0deg)","paddingBottom":"0px"}}}',
parentGroup:'si7759',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7785',
t:1268
}
,{
n:'si7793',
t:29
}
]
,
containerType:'timeline-widget-graphic-button',
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridTemplateRows":"1fr","gridTemplateColumns":"1fr","gridColumn":"2","gridRow":"5","paddingBottom":"0px","transform":"rotate(0deg)"},"tablet":{"gridColumn":"2","gridRow":"5","transform":"rotate(0deg)","paddingBottom":"0px"},"mobile":{"gridColumn":"2","gridRow":"5","transform":"rotate(0deg)","paddingBottom":"0px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7759',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7777c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7777,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7777',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7785:{
name:'Timeline_Graphic_11',
type:1268,
from:1,
to:0,
rp:0,
rpa:0,
mdi:'si7785c',
tag:'container-graphic-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"width":"6px","height":"100%","margin":"10px 0","gridRow":"1","gridColumn":"1","background":"#edeae2"},"tablet":{"width":"6px","height":"100%"},"mobile":{"width":"6px","height":"100%"}}}',
parentGroup:'si7777',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'timeline-widget-graphic',
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"width":"6px","height":"100%","margin":"10px 0","gridRow":"1","gridColumn":"1","background":"#edeae2"},"tablet":{"width":"6px","height":"100%"},"mobile":{"width":"6px","height":"100%"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7777',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7785c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7785,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7785',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7793:{
name:'Button_71',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7793c',
tag:'timeline-node-button-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4nlmd","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4r3an","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{"all":{"width":"40px","height":"40px","opacity":"1","gridRow":"1","gridColumn":"1","borderRadius":"30px","zIndex":1},"tablet":{},"mobile":{}},"iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"350bc","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"},{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"d7bkf","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"},{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6ubmm","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si7777',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7793]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7793c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7793,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7793',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si7809:{
name:'Node_content_11',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7809c',
tag:'container-node-content-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"imageHeight":200,"visibilityInfo":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"padding":"20px 0px","gridRowStart":"5","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"span 4"},"tablet":{"gridRowStart":"5","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"},"mobile":{"gridRowStart":"5","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"}}}',
parentGroup:'si7759',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7817',
t:1268
}
]
,
containerType:'timeline-node-content',
widgetProps:'{"canBeCard":false,"imageHeight":200,"visibilityInfo":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"padding":"20px 0px","gridRowStart":"5","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"span 4"},"tablet":{"gridRowStart":"5","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"},"mobile":{"gridRowStart":"5","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"auto"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7759',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7809c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7809,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7809',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7817:{
name:'Image_Grid_Group_11',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7817c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true},"padding":{"top":24,"bottom":24,"left":24,"right":24},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"10px","alignItems":"center"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"}}}',
parentGroup:'si7809',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7825',
t:15
}
,{
n:'si7837',
t:1268
}
,{
n:'si7865',
t:29
}
]
,
containerType:'image-grid-card',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true},"padding":{"top":24,"bottom":24,"left":24,"right":24},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"10px","alignItems":"center"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7809',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si7817c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7817,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7817',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c2)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7825:{
name:'image5_1',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7825c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"50%","width":"210px","height":"200px"},"tablet":{"width":"200px"},"mobile":{"width":"200px"}}}',
parentGroup:'si7817',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
o:100,
irw:245,
irh:185,
w:245,
h:185,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7825]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7825c:{
b:[0,0,245,185],
fh:false,
fw:false,
uid:7825,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/03381.png',
dn:'si7825',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,246,186],
vb:[-1,-1,246,186]
},
si7837:{
name:'Image_Group_Text_14',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7837c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0}}',
parentGroup:'si7817',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7845',
t:1250
}
,{
n:'si7855',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7817',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7837c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7837,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7837',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7845:{
name:'Text_110',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7845c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"padding":"24px 0px  12px 0px","width":"350px"},"tablet":{"width":"100%"},"mobile":{"width":"100%"}}}',
parentGroup:'si7837',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"7u2m4","text":"Title 05","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7845]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7845c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7845,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7845',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7855:{
name:'Text_111',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7855c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"width":"350px"},"tablet":{"width":"100%"},"mobile":{"width":"100%"}}}',
parentGroup:'si7837',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"e66m6","text":"Lorem Ipsum is simply dummy text of the printing and typesetting industry.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":74,"style":"hlnk:"},{"offset":0,"length":74,"style":"hlnkt:wp"},{"offset":0,"length":74,"style":"textOutlineEnable:false"},{"offset":0,"length":74,"style":"opacity:1"},{"offset":0,"length":74,"style":"hlnke:true"},{"offset":0,"length":74,"style":"backgroundColor:unset"},{"offset":0,"length":74,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":74,"style":"textHighlightEnable:false"},{"offset":0,"length":74,"style":"textShadowEnable:false"},{"offset":0,"length":74,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7855]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7855c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7855,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7855',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7865:{
name:'Button_72',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7865c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01342.svg","size":"medium","position":0,"offset":0},"normal":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7q2qh","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"selected":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bnhhs","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"disabled":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bm4g0","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"hover":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cld7b","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"visited":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7bsrk","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}}}',
parentGroup:'si7817',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7865]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7865c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7865,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7865',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si7881:{
name:'Node_12',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7881c',
tag:'container-timeline-node-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"timeline-widget-time":true,"isDerivedFromChild":true},"isVisible":false,"canBeCard":false,"imageHeight":200}',
parentGroup:'si7263',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7889',
t:1250
}
,{
n:'si7899',
t:1268
}
,{
n:'si7931',
t:1268
}
]
,
containerType:'timeline-widget-node',
widgetProps:'{"visibilityInfo":{"timeline-widget-time":true,"isDerivedFromChild":true},"isVisible":false,"canBeCard":false,"imageHeight":200}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7263',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7881c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7881,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7881',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7889:{
name:'Text_112',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7889c',
tag:'timeline-widget-time-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridColumn":"1","gridRow":"6","padding":"0px 0px 12px 0px"},"tablet":{"gridColumn":"1","gridRow":"6","marginRight":"20px"},"mobile":{"gridColumn":"1","gridRow":"6"}}}',
parentGroup:'si7881',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"1dkm9","text":"2005","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7889]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7889c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7889,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7889',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7899:{
name:'Graphic_Button_Container_12',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7899c',
tag:'container-graphic-button-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridTemplateRows":"1fr","gridTemplateColumns":"1fr","gridColumn":"2","gridRow":"6","paddingBottom":"0px","transform":"rotate(0deg)"},"tablet":{"gridColumn":"2","gridRow":"6","transform":"rotate(0deg)","paddingBottom":"0px"},"mobile":{"gridColumn":"2","gridRow":"6","transform":"rotate(0deg)","paddingBottom":"0px"}}}',
parentGroup:'si7881',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7907',
t:1268
}
,{
n:'si7915',
t:29
}
]
,
containerType:'timeline-widget-graphic-button',
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"display":"grid","justifyItems":"center","alignItems":"center","gridTemplateRows":"1fr","gridTemplateColumns":"1fr","gridColumn":"2","gridRow":"6","paddingBottom":"0px","transform":"rotate(0deg)"},"tablet":{"gridColumn":"2","gridRow":"6","transform":"rotate(0deg)","paddingBottom":"0px"},"mobile":{"gridColumn":"2","gridRow":"6","transform":"rotate(0deg)","paddingBottom":"0px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7881',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7899c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7899,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7899',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7907:{
name:'Timeline_Graphic_12',
type:1268,
from:1,
to:0,
rp:0,
rpa:0,
mdi:'si7907c',
tag:'container-graphic-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"width":"6px","height":"100%","margin":"10px 0","gridRow":"1","gridColumn":"1","background":"#edeae2"},"tablet":{"width":"6px","height":"100%"},"mobile":{"width":"6px","height":"100%"}}}',
parentGroup:'si7899',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'timeline-widget-graphic',
widgetProps:'{"canBeCard":false,"designOptionStyles":{"all":{"width":"6px","height":"100%","margin":"10px 0","gridRow":"1","gridColumn":"1","background":"#edeae2"},"tablet":{"width":"6px","height":"100%"},"mobile":{"width":"6px","height":"100%"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7899',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7907c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7907,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7907',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7915:{
name:'Button_73',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7915c',
tag:'timeline-node-button-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"730pi","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"},{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cv8gm","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"},{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{"all":{"width":"40px","height":"40px","opacity":"1","gridRow":"1","gridColumn":"1","borderRadius":"30px","zIndex":1},"tablet":{},"mobile":{}},"iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"d2eud","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2ldv2","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"},{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bglg6","text":" ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":1,"style":"textShadowColor:ffffff00"},{"offset":0,"length":1,"style":"hlnke:true"},{"offset":0,"length":1,"style":"backgroundColor:unset"},{"offset":0,"length":1,"style":"textShadowX:0px"},{"offset":0,"length":1,"style":"textShadowY:0px"},{"offset":0,"length":1,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":1,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":1,"style":"textShadowBlur:0px"},{"offset":0,"length":1,"style":"textHighlightEnable:false"},{"offset":0,"length":1,"style":"textShadowEnable:false"},{"offset":0,"length":1,"style":"hlnk:"},{"offset":0,"length":1,"style":"overridden:false"},{"offset":0,"length":1,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":1,"style":"hlnkt:wp"},{"offset":0,"length":1,"style":"textOutlineEnable:false"},{"offset":0,"length":1,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si7899',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7915]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7915c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7915,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7915',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si7931:{
name:'Node_content_12',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7931c',
tag:'container-node-content-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"imageHeight":200,"visibilityInfo":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"gridRowStart":"6","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"span 4"},"tablet":{"gridColumn":"3","gridRow":"6"},"mobile":{"gridColumn":"3","gridRow":"6"}}}',
parentGroup:'si7881',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7939',
t:1268
}
]
,
containerType:'timeline-node-content',
widgetProps:'{"canBeCard":false,"imageHeight":200,"visibilityInfo":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"gridRowStart":"6","gridColumnStart":"3","gridRowEnd":"auto","gridColumnEnd":"span 4"},"tablet":{"gridColumn":"3","gridRow":"6"},"mobile":{"gridColumn":"3","gridRow":"6"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7881',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7931c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7931,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7931',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7939:{
name:'Image_Grid_Group_12',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7939c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true},"padding":{"top":24,"bottom":24,"left":24,"right":24},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"10px","alignItems":"center"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"}}}',
parentGroup:'si7931',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7947',
t:15
}
,{
n:'si7959',
t:1268
}
,{
n:'si7987',
t:29
}
]
,
containerType:'image-grid-card',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true},"padding":{"top":24,"bottom":24,"left":24,"right":24},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"10px","alignItems":"center"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7931',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si7939c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7939,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7939',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c2)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7947:{
name:'image6_1',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7947c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"50%","width":"210px","height":"200px"},"tablet":{"width":"200px"},"mobile":{"width":"200px"}}}',
parentGroup:'si7939',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
o:100,
irw:245,
irh:185,
w:245,
h:185,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7947]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7947c:{
b:[0,0,245,185],
fh:false,
fw:false,
uid:7947,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'25.206%',
h:'30.428%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/03505.png',
dn:'si7947',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,246,186],
vb:[-1,-1,246,186]
},
si7959:{
name:'Image_Group_Text_15',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7959c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0}}',
parentGroup:'si7939',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7967',
t:1250
}
,{
n:'si7977',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7939',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7959c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7959,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7959',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7967:{
name:'Text_113',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7967c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"padding":"24px 0px  12px 0px","width":"350px"},"tablet":{"width":"100%"},"mobile":{"width":"100%"}}}',
parentGroup:'si7959',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"c6vkm","text":"Title 06","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7967]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7967c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7967,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7967',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7977:{
name:'Text_114',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7977c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"width":"350px"},"tablet":{"width":"100%"},"mobile":{"width":"100%"}}}',
parentGroup:'si7959',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"6uv9r","text":"Lorem Ipsum is simply dummy text of the printing and typesetting industry.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":74,"style":"hlnk:"},{"offset":0,"length":74,"style":"hlnkt:wp"},{"offset":0,"length":74,"style":"textOutlineEnable:false"},{"offset":0,"length":74,"style":"opacity:1"},{"offset":0,"length":74,"style":"hlnke:true"},{"offset":0,"length":74,"style":"backgroundColor:unset"},{"offset":0,"length":74,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":74,"style":"textHighlightEnable:false"},{"offset":0,"length":74,"style":"textShadowEnable:false"},{"offset":0,"length":74,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7977]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7977c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7977,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7977',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7987:{
name:'Button_74',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7987c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"01342.svg","size":"medium","position":0,"offset":0},"normal":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"fs4os","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"selected":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9le2e","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"disabled":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cig0v","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"hover":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"aon25","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}},"visited":{"padding":10,"opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7t2b2","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}}}',
parentGroup:'si7939',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7987]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7987c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7987,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7987',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si8003:{
name:'Slide_Buttons_Widget_5',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8003c',
tag:'slide-buttons-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","justifyContent":"space-between","padding":"25px 0px 44px 0px"}}}',
parentGroup:'si7245',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si8011',
t:29
}
,{
n:'si8030',
t:29
}
]
,
containerType:'slide-buttons',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","justifyContent":"space-between","padding":"25px 0px 44px 0px"}}}',
option:'SLIDE_BUTTONS_DEFAULT_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7245',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si8003c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:8003,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8003',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ff0000',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si8011:{
name:'Button_75',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8011c',
tag:'slide-buttons-previous-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ac7fq","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_default","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5cms7","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"30"}},"designOption":"SLIDE_PREVIOUS_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0649.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"b2lcq","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"d3r9a","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"30cfe","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si8003',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToPreviousSlide(8029);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8011]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8011c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:8011,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8011',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si8030:{
name:'Button_76',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8030c',
tag:'slide-buttons-next-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":true,"hover":true,"visited":false},"normal":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5kjj","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_default","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"f2rfq","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"30"}},"designOption":"SLIDE_NEXT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0671.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6u33m","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8vput","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"46p9a","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si8003',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToNextSlide(8048);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8030]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8030c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:8030,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8030',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si6738:{
name:'Flip_Cards_2',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6738c',
tag:'container-cards-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":false,"slide-item-prev-button":false,"slide-item-next-button":false,"card":true},"autoFit":true,"numberOfCards":3,"alignment":{"slide-item-heading":"LEFT"},"canBeCard":false,"isForcedNavigationEnabled":true,"contentSpacing":2,"padding":{"left":4,"right":4,"top":27,"bottom":27},"designOptionStyles":{"all":{"flexDirection":"column","padding":"25px"},"tablet":{"padding":"15px"},"mobile":{"padding":"15px"}},"appearanceProperties":{},"isFlipped":true}',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6746',
t:1250
}
,{
n:'si6756',
t:1268
}
,{
n:'si7199',
t:1268
}
]
,
containerType:'cards-widget',
widgetProps:'{"visibilityInfo":{"slide-item-heading":false,"slide-item-prev-button":false,"slide-item-next-button":false,"card":true},"autoFit":true,"numberOfCards":3,"alignment":{"slide-item-heading":"LEFT"},"canBeCard":false,"isForcedNavigationEnabled":true,"contentSpacing":2,"padding":{"left":4,"right":4,"top":27,"bottom":27},"designOptionStyles":{"all":{"flexDirection":"column","padding":"25px"},"tablet":{"padding":"15px"},"mobile":{"padding":"15px"}},"appearanceProperties":{},"isFlipped":true}',
option:'DEFAULT_CARDS_WIDGET_OPTION_3',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si6738c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6738,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6738',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#ffffff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6746:{
name:'Text_75',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6746c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"40px","marginTop":"40px"},"tablet":{"marginBottom":"20px","marginTop":"20px"},"mobile":{"marginBottom":"20px","marginTop":"20px"}}}',
parentGroup:'si6738',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"1b2g6","text":"Heading for flipcard widget","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":27,"style":"hlnk:"},{"offset":0,"length":27,"style":"hlnkt:wp"},{"offset":0,"length":27,"style":"textOutlineEnable:false"},{"offset":0,"length":27,"style":"opacity:1"},{"offset":0,"length":27,"style":"hlnke:true"},{"offset":0,"length":27,"style":"backgroundColor:unset"},{"offset":0,"length":27,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":27,"style":"textHighlightEnable:false"},{"offset":0,"length":27,"style":"textShadowEnable:false"},{"offset":0,"length":27,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6746]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6746c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:6746,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6746',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si6756:{
name:'Flip_Card_Group_2',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6756c',
tag:'container-cards-group',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"flexDirection":"row","marginBottom":"6px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6738',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6764',
t:1268
}
,{
n:'si6875',
t:1268
}
,{
n:'si6983',
t:1268
}
,{
n:'si7091',
t:1268
}
]
,
containerType:'cards-group',
widgetProps:'{"designOptionStyles":{"all":{"flexDirection":"row","marginBottom":"6px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6738',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si6756c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6756,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6756',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6764:{
name:'FLIP_CARD_CONTAINER_5',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6764c',
tag:'container-flip-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"card":true},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si6756',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6772',
t:1268
}
,{
n:'si6825',
t:1268
}
]
,
containerType:'flip-card',
widgetProps:'{"visibilityInfo":{"card":true},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6756',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si6764c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6764,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6764',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#333333',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6772:{
name:'FLIP_CARD_FRONT_5',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6772c',
tag:'container-flip-card-front',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":false,"slide-item-svg":true},"alignment":{"slide-item-title":"CENTER","slide-item-subtitle":"CENTER","slide-item-svg":"CENTER"},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"flipcard-front-text-container":{"all":{"background":"transparent linear-gradient(0deg, #EAEAEACC 100%,  #A5A5A500 100%)","padding":"25px"},"tablet":{"padding":"15px"},"mobile":{"padding":"15px"}}}}',
parentGroup:'si6764',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6780',
t:15
}
,{
n:'si6792',
t:1250
}
,{
n:'si6802',
t:1250
}
,{
n:'si6815',
t:652
}
]
,
containerType:'flip-card-front',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":false,"slide-item-svg":true},"alignment":{"slide-item-title":"CENTER","slide-item-subtitle":"CENTER","slide-item-svg":"CENTER"},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"flipcard-front-text-container":{"all":{"background":"transparent linear-gradient(0deg, #EAEAEACC 100%,  #A5A5A500 100%)","padding":"25px"},"tablet":{"padding":"15px"},"mobile":{"padding":"15px"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6764',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si6772c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6772,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6772',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6780:{
name:'Asset_2_2',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6780c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si6772',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
o:100,
irw:791,
irh:1472,
w:791,
h:1472,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6780]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6780c:{
b:[0,0,791,1472],
fh:false,
fw:false,
uid:6780,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'60.288%',
h:'167.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'60.288%',
h:'167.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'60.288%',
h:'167.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/04381.png',
dn:'si6780',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,792,1473],
vb:[-1,-1,792,1473]
},
si6792:{
name:'Text_76',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6792c',
tag:'slide-item-title',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6772',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"1hev1","text":"Skills","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-heading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6792]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6792c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:6792,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6792',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si6802:{
name:'Text_77',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6802c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6772',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"e1hi4","text":"Lorem ipsum dolor sit amet, consectetur adipiscing elit.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":56,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":56,"style":"textHighlightEnable:false"},{"offset":0,"length":56,"style":"textShadowEnable:false"},{"offset":0,"length":56,"style":"overridden:false"},{"offset":0,"length":56,"style":"hlnk:"},{"offset":0,"length":56,"style":"hlnkt:wp"},{"offset":0,"length":56,"style":"textOutlineEnable:false"},{"offset":0,"length":56,"style":"opacity:1"},{"offset":0,"length":56,"style":"hlnke:true"},{"offset":0,"length":56,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6802]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6802c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:6802,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6802',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si6815:{
name:'default_svg_4',
type:652,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6815c',
tag:'slide-item-svg',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'',
parentGroup:'si6772',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6815]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6815c:{
b:[666,367,700,401],
fh:false,
fw:false,
uid:6815,
iso:false,
css:{
360:{
l:'68.519%',
t:'60.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.519%',
lhID:-1,
lvEID:0,
lvV:'60.362%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'68.519%',
t:'60.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.519%',
lhID:-1,
lvEID:0,
lvV:'60.362%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'68.519%',
t:'60.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.519%',
lhID:-1,
lvEID:0,
lvV:'60.362%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si6815',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/06812.svg',
wofh:34,
wofw:34,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[665,366,701,402],
vb:[665,366,701,402]
},
si6825:{
name:'FLIP_CARD_BACK_5',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6825c',
tag:'container-flip-card-back',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":true,"slide-item-body":false},"alignment":{"slide-item-image":"CENTER","slide-item-title":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"RIGHT"},"designOptionStyles":{"all":{"padding":"0 40px"},"tablet":{"padding":"0 15px"},"mobile":{"padding":"0 15px"}},"childNodesCustomStyles":{"flipcard-back-image-container":{"all":{"width":"100%","height":"200px","margin":"36px auto"},"tablet":{"width":"100%","margin":"15px 0"},"mobile":{"width":"100%","margin":"15px auto"}}}}',
parentGroup:'si6764',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6833',
t:15
}
,{
n:'si6845',
t:1250
}
,{
n:'si6855',
t:1250
}
,{
n:'si6865',
t:1250
}
]
,
containerType:'flip-card-back',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":true,"slide-item-body":false},"alignment":{"slide-item-image":"CENTER","slide-item-title":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"RIGHT"},"designOptionStyles":{"all":{"padding":"0 40px"},"tablet":{"padding":"0 15px"},"mobile":{"padding":"0 15px"}},"childNodesCustomStyles":{"flipcard-back-image-container":{"all":{"width":"100%","height":"200px","margin":"36px auto"},"tablet":{"width":"100%","margin":"15px 0"},"mobile":{"width":"100%","margin":"15px auto"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6764',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si6825c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6825,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6825',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6833:{
name:'Asset_2_3',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6833c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si6825',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:100,
iff:{
bc:'#000000'
}
,
o:100,
irw:791,
irh:1472,
w:791,
h:1472,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6833]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6833c:{
b:[0,0,791,1472],
fh:false,
fw:false,
uid:6833,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'42.181%',
h:'67.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'42.181%',
h:'67.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'42.181%',
h:'67.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/04381.png',
dn:'si6833',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,792,1473],
vb:[-1,-1,792,1473]
},
si6845:{
name:'Text_78',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6845c',
tag:'slide-item-title',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6825',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"7vcat","text":"Skills","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":6,"style":"letterSpacing:0%"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textTransform:none"},{"offset":0,"length":6,"style":"textShadowOpacity:none"},{"offset":0,"length":6,"style":"overridden:true"},{"offset":0,"length":6,"style":"desktop-fontSize:40"},{"offset":0,"length":6,"style":"lineHeight:120%"},{"offset":0,"length":6,"style":"textDecoration:none"},{"offset":0,"length":6,"style":"borderBottomStyle:none"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"fontWeight:normal"},{"offset":0,"length":6,"style":"textShadowBlur:8px"},{"offset":0,"length":6,"style":"fontFamily:Arial"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"fontStyle:normal"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":6,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"tablet-fontSize:32"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"defaultTextShadow:none"},{"offset":0,"length":6,"style":"mobile-fontSize:28"},{"offset":0,"length":6,"style":"textShadow:none"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"fontStretch:normal"},{"offset":0,"length":6,"style":"fontType:regular"},{"offset":0,"length":6,"style":"color:#FFFFFF"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"textShadowY:4px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-5","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6845]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6845c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:6845,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6845',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si6855:{
name:'Text_79',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6855c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6825',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"7icof","text":"• eLearning courses devolopment","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":31,"style":"desktop-fontSize:18"},{"offset":0,"length":31,"style":"fontStyle:normal"},{"offset":0,"length":31,"style":"hlnkt:wp"},{"offset":0,"length":31,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":31,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":31,"style":"textOutlineEnable:false"},{"offset":0,"length":31,"style":"opacity:1"},{"offset":0,"length":31,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":31,"style":"mobile-fontSize:16"},{"offset":0,"length":31,"style":"hlnke:true"},{"offset":0,"length":31,"style":"backgroundColor:unset"},{"offset":0,"length":31,"style":"textShadow:none"},{"offset":0,"length":31,"style":"tablet-fontSize:16"},{"offset":0,"length":31,"style":"textShadowX:0px"},{"offset":0,"length":31,"style":"fontStretch:normal"},{"offset":0,"length":31,"style":"fontType:regular"},{"offset":0,"length":31,"style":"color:#FFFFFF"},{"offset":0,"length":31,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":31,"style":"textShadowY:4px"},{"offset":0,"length":31,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":31,"style":"lineHeight:135%"},{"offset":0,"length":31,"style":"letterSpacing:0%"},{"offset":0,"length":31,"style":"textHighlightEnable:false"},{"offset":0,"length":31,"style":"textTransform:none"},{"offset":0,"length":31,"style":"textShadowOpacity:none"},{"offset":0,"length":31,"style":"overridden:true"},{"offset":0,"length":31,"style":"textDecoration:none"},{"offset":0,"length":31,"style":"borderBottomStyle:none"},{"offset":0,"length":31,"style":"fontWeight:bold"},{"offset":0,"length":31,"style":"textShadowEnable:false"},{"offset":0,"length":31,"style":"hlnk:"},{"offset":0,"length":31,"style":"textShadowBlur:8px"},{"offset":0,"length":31,"style":"fontFamily:Arial"},{"offset":0,"length":31,"style":"defaultTextShadow:none"},{"offset":0,"length":31,"style":"WebkitTextStrokeWidth:1px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"i1qs","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"2qr30","text":"• Illustration","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"textShadowBlur:8px"},{"offset":0,"length":14,"style":"fontFamily:Arial"},{"offset":0,"length":14,"style":"defaultTextShadow:none"},{"offset":0,"length":14,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":14,"style":"desktop-fontSize:18"},{"offset":0,"length":14,"style":"fontStyle:normal"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":14,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":14,"style":"mobile-fontSize:16"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"textShadow:none"},{"offset":0,"length":14,"style":"tablet-fontSize:16"},{"offset":0,"length":14,"style":"textShadowX:0px"},{"offset":0,"length":14,"style":"fontStretch:normal"},{"offset":0,"length":14,"style":"fontType:regular"},{"offset":0,"length":14,"style":"color:#FFFFFF"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textShadowY:4px"},{"offset":0,"length":14,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":14,"style":"lineHeight:135%"},{"offset":0,"length":14,"style":"letterSpacing:0%"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textTransform:none"},{"offset":0,"length":14,"style":"textShadowOpacity:none"},{"offset":0,"length":14,"style":"overridden:true"},{"offset":0,"length":14,"style":"textDecoration:none"},{"offset":0,"length":14,"style":"borderBottomStyle:none"},{"offset":0,"length":14,"style":"fontWeight:bold"},{"offset":0,"length":14,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"hlnk:"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"8dccv","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"50jvp","text":"• Photo Editing","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"fontWeight:bold"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"textShadowBlur:8px"},{"offset":0,"length":15,"style":"fontFamily:Arial"},{"offset":0,"length":15,"style":"defaultTextShadow:none"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":15,"style":"desktop-fontSize:18"},{"offset":0,"length":15,"style":"fontStyle:normal"},{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":15,"style":"mobile-fontSize:16"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadow:none"},{"offset":0,"length":15,"style":"tablet-fontSize:16"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"fontStretch:normal"},{"offset":0,"length":15,"style":"fontType:regular"},{"offset":0,"length":15,"style":"color:#FFFFFF"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"textShadowY:4px"},{"offset":0,"length":15,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":15,"style":"lineHeight:135%"},{"offset":0,"length":15,"style":"letterSpacing:0%"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textTransform:none"},{"offset":0,"length":15,"style":"textShadowOpacity:none"},{"offset":0,"length":15,"style":"overridden:true"},{"offset":0,"length":15,"style":"textDecoration:none"},{"offset":0,"length":15,"style":"borderBottomStyle:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"esfl6","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"3r1gd","text":"• Photo Manipulation","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":20,"style":"overridden:true"},{"offset":0,"length":20,"style":"textDecoration:none"},{"offset":0,"length":20,"style":"borderBottomStyle:none"},{"offset":0,"length":20,"style":"fontWeight:bold"},{"offset":0,"length":20,"style":"textShadowEnable:false"},{"offset":0,"length":20,"style":"hlnk:"},{"offset":0,"length":20,"style":"textShadowBlur:8px"},{"offset":0,"length":20,"style":"fontFamily:Arial"},{"offset":0,"length":20,"style":"defaultTextShadow:none"},{"offset":0,"length":20,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":20,"style":"desktop-fontSize:18"},{"offset":0,"length":20,"style":"fontStyle:normal"},{"offset":0,"length":20,"style":"hlnkt:wp"},{"offset":0,"length":20,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":20,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":20,"style":"textOutlineEnable:false"},{"offset":0,"length":20,"style":"opacity:1"},{"offset":0,"length":20,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":20,"style":"mobile-fontSize:16"},{"offset":0,"length":20,"style":"hlnke:true"},{"offset":0,"length":20,"style":"backgroundColor:unset"},{"offset":0,"length":20,"style":"textShadow:none"},{"offset":0,"length":20,"style":"tablet-fontSize:16"},{"offset":0,"length":20,"style":"textShadowX:0px"},{"offset":0,"length":20,"style":"fontStretch:normal"},{"offset":0,"length":20,"style":"fontType:regular"},{"offset":0,"length":20,"style":"color:#FFFFFF"},{"offset":0,"length":20,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":20,"style":"textShadowY:4px"},{"offset":0,"length":20,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":20,"style":"lineHeight:135%"},{"offset":0,"length":20,"style":"letterSpacing:0%"},{"offset":0,"length":20,"style":"textHighlightEnable:false"},{"offset":0,"length":20,"style":"textTransform:none"},{"offset":0,"length":20,"style":"textShadowOpacity:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"ej8kc","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"6vunf","text":"• Video Editing","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textTransform:none"},{"offset":0,"length":15,"style":"textShadowOpacity:none"},{"offset":0,"length":15,"style":"overridden:true"},{"offset":0,"length":15,"style":"textDecoration:none"},{"offset":0,"length":15,"style":"borderBottomStyle:none"},{"offset":0,"length":15,"style":"fontWeight:bold"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"textShadowBlur:8px"},{"offset":0,"length":15,"style":"fontFamily:Arial"},{"offset":0,"length":15,"style":"defaultTextShadow:none"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":15,"style":"desktop-fontSize:18"},{"offset":0,"length":15,"style":"fontStyle:normal"},{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":15,"style":"mobile-fontSize:16"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadow:none"},{"offset":0,"length":15,"style":"tablet-fontSize:16"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"fontStretch:normal"},{"offset":0,"length":15,"style":"fontType:regular"},{"offset":0,"length":15,"style":"color:#FFFFFF"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"textShadowY:4px"},{"offset":0,"length":15,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":15,"style":"lineHeight:135%"},{"offset":0,"length":15,"style":"letterSpacing:0%"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"9ihhq","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"bk13s","text":"• Motion Graphics","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":17,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":17,"style":"lineHeight:135%"},{"offset":0,"length":17,"style":"letterSpacing:0%"},{"offset":0,"length":17,"style":"textHighlightEnable:false"},{"offset":0,"length":17,"style":"textTransform:none"},{"offset":0,"length":17,"style":"textShadowOpacity:none"},{"offset":0,"length":17,"style":"overridden:true"},{"offset":0,"length":17,"style":"textDecoration:none"},{"offset":0,"length":17,"style":"borderBottomStyle:none"},{"offset":0,"length":17,"style":"fontWeight:bold"},{"offset":0,"length":17,"style":"textShadowEnable:false"},{"offset":0,"length":17,"style":"hlnk:"},{"offset":0,"length":17,"style":"textShadowBlur:8px"},{"offset":0,"length":17,"style":"fontFamily:Arial"},{"offset":0,"length":17,"style":"defaultTextShadow:none"},{"offset":0,"length":17,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"desktop-fontSize:18"},{"offset":0,"length":17,"style":"fontStyle:normal"},{"offset":0,"length":17,"style":"hlnkt:wp"},{"offset":0,"length":17,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":17,"style":"textOutlineEnable:false"},{"offset":0,"length":17,"style":"opacity:1"},{"offset":0,"length":17,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":17,"style":"mobile-fontSize:16"},{"offset":0,"length":17,"style":"hlnke:true"},{"offset":0,"length":17,"style":"backgroundColor:unset"},{"offset":0,"length":17,"style":"textShadow:none"},{"offset":0,"length":17,"style":"tablet-fontSize:16"},{"offset":0,"length":17,"style":"textShadowX:0px"},{"offset":0,"length":17,"style":"fontStretch:normal"},{"offset":0,"length":17,"style":"fontType:regular"},{"offset":0,"length":17,"style":"color:#FFFFFF"},{"offset":0,"length":17,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":17,"style":"textShadowY:4px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"42nn0","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"955s6","text":"• Interactive PPT","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":17,"style":"color:#FFFFFF"},{"offset":0,"length":17,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":17,"style":"textShadowY:4px"},{"offset":0,"length":17,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":17,"style":"lineHeight:135%"},{"offset":0,"length":17,"style":"letterSpacing:0%"},{"offset":0,"length":17,"style":"textHighlightEnable:false"},{"offset":0,"length":17,"style":"textTransform:none"},{"offset":0,"length":17,"style":"textShadowOpacity:none"},{"offset":0,"length":17,"style":"overridden:true"},{"offset":0,"length":17,"style":"textDecoration:none"},{"offset":0,"length":17,"style":"borderBottomStyle:none"},{"offset":0,"length":17,"style":"fontWeight:bold"},{"offset":0,"length":17,"style":"textShadowEnable:false"},{"offset":0,"length":17,"style":"hlnk:"},{"offset":0,"length":17,"style":"textShadowBlur:8px"},{"offset":0,"length":17,"style":"fontFamily:Arial"},{"offset":0,"length":17,"style":"defaultTextShadow:none"},{"offset":0,"length":17,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"desktop-fontSize:18"},{"offset":0,"length":17,"style":"fontStyle:normal"},{"offset":0,"length":17,"style":"hlnkt:wp"},{"offset":0,"length":17,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":17,"style":"textOutlineEnable:false"},{"offset":0,"length":17,"style":"opacity:1"},{"offset":0,"length":17,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":17,"style":"mobile-fontSize:16"},{"offset":0,"length":17,"style":"hlnke:true"},{"offset":0,"length":17,"style":"backgroundColor:unset"},{"offset":0,"length":17,"style":"textShadow:none"},{"offset":0,"length":17,"style":"tablet-fontSize:16"},{"offset":0,"length":17,"style":"textShadowX:0px"},{"offset":0,"length":17,"style":"fontStretch:normal"},{"offset":0,"length":17,"style":"fontType:regular"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6855]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6855c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:6855,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6855',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si6865:{
name:'Text_80',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6865c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"20px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6825',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"46bma","text":"Sed ut perspiciatis und omnis iste natus error sit voluptatem accusantium.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":74,"style":"textShadowEnable:false"},{"offset":0,"length":74,"style":"overridden:false"},{"offset":0,"length":74,"style":"hlnk:"},{"offset":0,"length":74,"style":"hlnkt:wp"},{"offset":0,"length":74,"style":"textOutlineEnable:false"},{"offset":0,"length":74,"style":"opacity:1"},{"offset":0,"length":74,"style":"hlnke:true"},{"offset":0,"length":74,"style":"backgroundColor:unset"},{"offset":0,"length":74,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":74,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6865]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6865c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:6865,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6865',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si6875:{
name:'FLIP_CARD_CONTAINER_6',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6875c',
tag:'container-flip-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"card":true},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si6756',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6883',
t:1268
}
,{
n:'si6933',
t:1268
}
]
,
containerType:'flip-card',
widgetProps:'{"visibilityInfo":{"card":true},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6756',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si6875c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6875,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6875',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#333333',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6883:{
name:'FLIP_CARD_FRONT_6',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6883c',
tag:'container-flip-card-front',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":false,"slide-item-svg":true},"alignment":{"slide-item-title":"CENTER","slide-item-subtitle":"CENTER","slide-item-svg":"CENTER"},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"flipcard-front-text-container":{"all":{"background":"transparent linear-gradient(0deg, #EAEAEACC 100%,  #A5A5A500 100%)","padding":"25px"},"tablet":{"padding":"15px"},"mobile":{"padding":"15px"}}}}',
parentGroup:'si6875',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6891',
t:15
}
,{
n:'si6903',
t:1250
}
,{
n:'si6913',
t:1250
}
,{
n:'si6923',
t:652
}
]
,
containerType:'flip-card-front',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":false,"slide-item-svg":true},"alignment":{"slide-item-title":"CENTER","slide-item-subtitle":"CENTER","slide-item-svg":"CENTER"},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"flipcard-front-text-container":{"all":{"background":"transparent linear-gradient(0deg, #EAEAEACC 100%,  #A5A5A500 100%)","padding":"25px"},"tablet":{"padding":"15px"},"mobile":{"padding":"15px"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6875',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si6883c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6883,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6883',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6891:{
name:'Asset_1_2',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6891c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si6883',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
o:100,
irw:1526,
irh:1962,
w:1526,
h:1962,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6891]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6891c:{
b:[0,0,1526,1962],
fh:false,
fw:false,
uid:6891,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'60.288%',
h:'167.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'60.288%',
h:'167.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'60.288%',
h:'167.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/04383.png',
dn:'si6891',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1527,1963],
vb:[-1,-1,1527,1963]
},
si6903:{
name:'Text_81',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6903c',
tag:'slide-item-title',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6883',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"ea5ml","text":"Expertise","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":9,"style":"hlnk:"},{"offset":0,"length":9,"style":"hlnkt:wp"},{"offset":0,"length":9,"style":"textOutlineEnable:false"},{"offset":0,"length":9,"style":"opacity:1"},{"offset":0,"length":9,"style":"hlnke:true"},{"offset":0,"length":9,"style":"backgroundColor:unset"},{"offset":0,"length":9,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":9,"style":"textHighlightEnable:false"},{"offset":0,"length":9,"style":"textShadowEnable:false"},{"offset":0,"length":9,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6903]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6903c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:6903,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6903',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si6913:{
name:'Text_82',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6913c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6883',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"8geo4","text":"Lorem ipsum dolor sit amet, consectetur adipiscing elit.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":56,"style":"hlnk:"},{"offset":0,"length":56,"style":"hlnkt:wp"},{"offset":0,"length":56,"style":"textOutlineEnable:false"},{"offset":0,"length":56,"style":"opacity:1"},{"offset":0,"length":56,"style":"hlnke:true"},{"offset":0,"length":56,"style":"backgroundColor:unset"},{"offset":0,"length":56,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":56,"style":"textHighlightEnable:false"},{"offset":0,"length":56,"style":"textShadowEnable:false"},{"offset":0,"length":56,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6913]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6913c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:6913,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6913',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si6923:{
name:'default_svg_5',
type:652,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6923c',
tag:'slide-item-svg',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'',
parentGroup:'si6883',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6923]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6923c:{
b:[666,367,700,401],
fh:false,
fw:false,
uid:6923,
iso:false,
css:{
360:{
l:'68.519%',
t:'60.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.519%',
lhID:-1,
lvEID:0,
lvV:'60.362%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'68.519%',
t:'60.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.519%',
lhID:-1,
lvEID:0,
lvV:'60.362%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'68.519%',
t:'60.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.519%',
lhID:-1,
lvEID:0,
lvV:'60.362%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si6923',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/06812.svg',
wofh:34,
wofw:34,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[665,366,701,402],
vb:[665,366,701,402]
},
si6933:{
name:'FLIP_CARD_BACK_6',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6933c',
tag:'container-flip-card-back',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":true,"slide-item-body":false},"alignment":{"slide-item-image":"CENTER","slide-item-title":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"RIGHT"},"designOptionStyles":{"all":{"padding":"0 40px"},"tablet":{"padding":"0 15px"},"mobile":{"padding":"0 15px"}},"childNodesCustomStyles":{"flipcard-back-image-container":{"all":{"width":"100%","height":"200px","margin":"36px auto"},"tablet":{"width":"100%","margin":"15px 0"},"mobile":{"width":"100%","margin":"15px auto"}}}}',
parentGroup:'si6875',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6941',
t:15
}
,{
n:'si6953',
t:1250
}
,{
n:'si6963',
t:1250
}
,{
n:'si6973',
t:1250
}
]
,
containerType:'flip-card-back',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":true,"slide-item-body":false},"alignment":{"slide-item-image":"CENTER","slide-item-title":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"RIGHT"},"designOptionStyles":{"all":{"padding":"0 40px"},"tablet":{"padding":"0 15px"},"mobile":{"padding":"0 15px"}},"childNodesCustomStyles":{"flipcard-back-image-container":{"all":{"width":"100%","height":"200px","margin":"36px auto"},"tablet":{"width":"100%","margin":"15px 0"},"mobile":{"width":"100%","margin":"15px auto"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6875',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si6933c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6933,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6933',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6941:{
name:'Asset_1_3',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6941c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si6933',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:100,
iff:{
bc:'#000000'
}
,
o:100,
irw:1526,
irh:1962,
w:1526,
h:1962,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6941]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6941c:{
b:[0,0,1526,1962],
fh:false,
fw:false,
uid:6941,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'42.181%',
h:'67.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'42.181%',
h:'67.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'42.181%',
h:'67.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/04383.png',
dn:'si6941',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1527,1963],
vb:[-1,-1,1527,1963]
},
si6953:{
name:'Text_83',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6953c',
tag:'slide-item-title',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6933',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"8ngin","text":"Expertise","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":9,"style":"opacity:1"},{"offset":0,"length":9,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":9,"style":"hlnke:true"},{"offset":0,"length":9,"style":"defaultTextShadow:none"},{"offset":0,"length":9,"style":"mobile-fontSize:28"},{"offset":0,"length":9,"style":"textShadow:none"},{"offset":0,"length":9,"style":"textShadowX:0px"},{"offset":0,"length":9,"style":"fontStretch:normal"},{"offset":0,"length":9,"style":"fontType:regular"},{"offset":0,"length":9,"style":"color:#FFFFFF"},{"offset":0,"length":9,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":9,"style":"textShadowY:4px"},{"offset":0,"length":9,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":9,"style":"letterSpacing:0%"},{"offset":0,"length":9,"style":"textHighlightEnable:false"},{"offset":0,"length":9,"style":"textTransform:none"},{"offset":0,"length":9,"style":"textShadowOpacity:none"},{"offset":0,"length":9,"style":"overridden:true"},{"offset":0,"length":9,"style":"desktop-fontSize:40"},{"offset":0,"length":9,"style":"lineHeight:120%"},{"offset":0,"length":9,"style":"textDecoration:none"},{"offset":0,"length":9,"style":"borderBottomStyle:none"},{"offset":0,"length":9,"style":"textShadowEnable:false"},{"offset":0,"length":9,"style":"hlnk:"},{"offset":0,"length":9,"style":"fontWeight:normal"},{"offset":0,"length":9,"style":"textShadowBlur:8px"},{"offset":0,"length":9,"style":"fontFamily:Arial"},{"offset":0,"length":9,"style":"backgroundColor:unset"},{"offset":0,"length":9,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":9,"style":"hlnkt:wp"},{"offset":0,"length":9,"style":"fontStyle:normal"},{"offset":0,"length":9,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":9,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":9,"style":"textOutlineEnable:false"},{"offset":0,"length":9,"style":"tablet-fontSize:32"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-5","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6953]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6953c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:6953,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6953',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si6963:{
name:'Text_84',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6963c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6933',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"c6o5j","text":"• Expertise in creating complex eLearning modules while ensuring user-friendly navigation and intuitive user experience","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":119,"style":"textTransform:none"},{"offset":0,"length":119,"style":"textShadowOpacity:none"},{"offset":0,"length":119,"style":"overridden:true"},{"offset":0,"length":119,"style":"textDecoration:none"},{"offset":0,"length":119,"style":"borderBottomStyle:none"},{"offset":0,"length":119,"style":"fontWeight:bold"},{"offset":0,"length":119,"style":"textShadowEnable:false"},{"offset":0,"length":119,"style":"hlnk:"},{"offset":0,"length":119,"style":"textShadowBlur:8px"},{"offset":0,"length":119,"style":"fontFamily:Arial"},{"offset":0,"length":119,"style":"desktop-fontSize:16"},{"offset":0,"length":119,"style":"backgroundColor:unset"},{"offset":0,"length":119,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":119,"style":"hlnkt:wp"},{"offset":0,"length":119,"style":"fontStyle:normal"},{"offset":0,"length":119,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":119,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":119,"style":"textOutlineEnable:false"},{"offset":0,"length":119,"style":"opacity:1"},{"offset":0,"length":119,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":119,"style":"mobile-fontSize:16"},{"offset":0,"length":119,"style":"hlnke:true"},{"offset":0,"length":119,"style":"defaultTextShadow:none"},{"offset":0,"length":119,"style":"textShadow:none"},{"offset":0,"length":119,"style":"tablet-fontSize:16"},{"offset":0,"length":119,"style":"textShadowX:0px"},{"offset":0,"length":119,"style":"fontStretch:normal"},{"offset":0,"length":119,"style":"fontType:regular"},{"offset":0,"length":119,"style":"color:#FFFFFF"},{"offset":0,"length":119,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":119,"style":"textShadowY:4px"},{"offset":0,"length":119,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":119,"style":"lineHeight:135%"},{"offset":0,"length":119,"style":"letterSpacing:0%"},{"offset":0,"length":119,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"2n4lv","text":"• Designed courses that adhere to WCAG guidelines, ensuring accessibility for all learners, including those with disabilities","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":125,"style":"lineHeight:135%"},{"offset":0,"length":125,"style":"letterSpacing:0%"},{"offset":0,"length":125,"style":"textHighlightEnable:false"},{"offset":0,"length":125,"style":"textTransform:none"},{"offset":0,"length":125,"style":"textShadowOpacity:none"},{"offset":0,"length":125,"style":"overridden:true"},{"offset":0,"length":125,"style":"textDecoration:none"},{"offset":0,"length":125,"style":"borderBottomStyle:none"},{"offset":0,"length":125,"style":"fontWeight:bold"},{"offset":0,"length":125,"style":"textShadowEnable:false"},{"offset":0,"length":125,"style":"hlnk:"},{"offset":0,"length":125,"style":"textShadowBlur:8px"},{"offset":0,"length":125,"style":"fontFamily:Arial"},{"offset":0,"length":125,"style":"desktop-fontSize:16"},{"offset":0,"length":125,"style":"backgroundColor:unset"},{"offset":0,"length":125,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":125,"style":"hlnkt:wp"},{"offset":0,"length":125,"style":"fontStyle:normal"},{"offset":0,"length":125,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":125,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":125,"style":"textOutlineEnable:false"},{"offset":0,"length":125,"style":"opacity:1"},{"offset":0,"length":125,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":125,"style":"mobile-fontSize:16"},{"offset":0,"length":125,"style":"hlnke:true"},{"offset":0,"length":125,"style":"defaultTextShadow:none"},{"offset":0,"length":125,"style":"textShadow:none"},{"offset":0,"length":125,"style":"tablet-fontSize:16"},{"offset":0,"length":125,"style":"textShadowX:0px"},{"offset":0,"length":125,"style":"fontStretch:normal"},{"offset":0,"length":125,"style":"fontType:regular"},{"offset":0,"length":125,"style":"color:#FFFFFF"},{"offset":0,"length":125,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":125,"style":"textShadowY:4px"},{"offset":0,"length":125,"style":"textShadowColor:#F1EEE61F"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"2rm2p","text":"• Strong understanding of graphic design and layout principles","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":62,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":62,"style":"textShadowY:4px"},{"offset":0,"length":62,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":62,"style":"lineHeight:135%"},{"offset":0,"length":62,"style":"letterSpacing:0%"},{"offset":0,"length":62,"style":"textHighlightEnable:false"},{"offset":0,"length":62,"style":"textTransform:none"},{"offset":0,"length":62,"style":"textShadowOpacity:none"},{"offset":0,"length":62,"style":"overridden:true"},{"offset":0,"length":62,"style":"textDecoration:none"},{"offset":0,"length":62,"style":"borderBottomStyle:none"},{"offset":0,"length":62,"style":"fontWeight:bold"},{"offset":0,"length":62,"style":"textShadowEnable:false"},{"offset":0,"length":62,"style":"hlnk:"},{"offset":0,"length":62,"style":"textShadowBlur:8px"},{"offset":0,"length":62,"style":"fontFamily:Arial"},{"offset":0,"length":62,"style":"desktop-fontSize:16"},{"offset":0,"length":62,"style":"backgroundColor:unset"},{"offset":0,"length":62,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":62,"style":"hlnkt:wp"},{"offset":0,"length":62,"style":"fontStyle:normal"},{"offset":0,"length":62,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":62,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":62,"style":"textOutlineEnable:false"},{"offset":0,"length":62,"style":"opacity:1"},{"offset":0,"length":62,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":62,"style":"mobile-fontSize:16"},{"offset":0,"length":62,"style":"hlnke:true"},{"offset":0,"length":62,"style":"defaultTextShadow:none"},{"offset":0,"length":62,"style":"textShadow:none"},{"offset":0,"length":62,"style":"tablet-fontSize:16"},{"offset":0,"length":62,"style":"textShadowX:0px"},{"offset":0,"length":62,"style":"fontStretch:normal"},{"offset":0,"length":62,"style":"fontType:regular"},{"offset":0,"length":62,"style":"color:#FFFFFF"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"dkh2e","text":"•Accessible document creation as per WCAG guidelines","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":52,"style":"fontStretch:normal"},{"offset":0,"length":52,"style":"fontType:regular"},{"offset":0,"length":52,"style":"color:#FFFFFF"},{"offset":0,"length":52,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":52,"style":"textShadowY:4px"},{"offset":0,"length":52,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":52,"style":"lineHeight:135%"},{"offset":0,"length":52,"style":"letterSpacing:0%"},{"offset":0,"length":52,"style":"textHighlightEnable:false"},{"offset":0,"length":52,"style":"textTransform:none"},{"offset":0,"length":52,"style":"textShadowOpacity:none"},{"offset":0,"length":52,"style":"overridden:true"},{"offset":0,"length":52,"style":"textDecoration:none"},{"offset":0,"length":52,"style":"borderBottomStyle:none"},{"offset":0,"length":52,"style":"fontWeight:bold"},{"offset":0,"length":52,"style":"textShadowEnable:false"},{"offset":0,"length":52,"style":"hlnk:"},{"offset":0,"length":52,"style":"textShadowBlur:8px"},{"offset":0,"length":52,"style":"fontFamily:Arial"},{"offset":0,"length":52,"style":"desktop-fontSize:16"},{"offset":0,"length":52,"style":"backgroundColor:unset"},{"offset":0,"length":52,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":52,"style":"hlnkt:wp"},{"offset":0,"length":52,"style":"fontStyle:normal"},{"offset":0,"length":52,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":52,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":52,"style":"textOutlineEnable:false"},{"offset":0,"length":52,"style":"opacity:1"},{"offset":0,"length":52,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":52,"style":"mobile-fontSize:16"},{"offset":0,"length":52,"style":"hlnke:true"},{"offset":0,"length":52,"style":"defaultTextShadow:none"},{"offset":0,"length":52,"style":"textShadow:none"},{"offset":0,"length":52,"style":"tablet-fontSize:16"},{"offset":0,"length":52,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"9h247","text":"• Skilled in interpreting requirements and converting them in quality ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":70,"style":"textShadow:none"},{"offset":0,"length":70,"style":"tablet-fontSize:16"},{"offset":0,"length":70,"style":"textShadowX:0px"},{"offset":0,"length":70,"style":"fontStretch:normal"},{"offset":0,"length":70,"style":"fontType:regular"},{"offset":0,"length":70,"style":"color:#FFFFFF"},{"offset":0,"length":70,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":70,"style":"textShadowY:4px"},{"offset":0,"length":70,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":70,"style":"lineHeight:135%"},{"offset":0,"length":70,"style":"letterSpacing:0%"},{"offset":0,"length":70,"style":"textHighlightEnable:false"},{"offset":0,"length":70,"style":"textTransform:none"},{"offset":0,"length":70,"style":"textShadowOpacity:none"},{"offset":0,"length":70,"style":"overridden:true"},{"offset":0,"length":70,"style":"textDecoration:none"},{"offset":0,"length":70,"style":"borderBottomStyle:none"},{"offset":0,"length":70,"style":"fontWeight:bold"},{"offset":0,"length":70,"style":"textShadowEnable:false"},{"offset":0,"length":70,"style":"hlnk:"},{"offset":0,"length":70,"style":"textShadowBlur:8px"},{"offset":0,"length":70,"style":"fontFamily:Arial"},{"offset":0,"length":70,"style":"desktop-fontSize:16"},{"offset":0,"length":70,"style":"backgroundColor:unset"},{"offset":0,"length":70,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":70,"style":"hlnkt:wp"},{"offset":0,"length":70,"style":"fontStyle:normal"},{"offset":0,"length":70,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":70,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":70,"style":"textOutlineEnable:false"},{"offset":0,"length":70,"style":"opacity:1"},{"offset":0,"length":70,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":70,"style":"mobile-fontSize:16"},{"offset":0,"length":70,"style":"hlnke:true"},{"offset":0,"length":70,"style":"defaultTextShadow:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"4bkhk","text":"deliverables","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":12,"style":"mobile-fontSize:16"},{"offset":0,"length":12,"style":"hlnke:true"},{"offset":0,"length":12,"style":"defaultTextShadow:none"},{"offset":0,"length":12,"style":"textShadow:none"},{"offset":0,"length":12,"style":"tablet-fontSize:16"},{"offset":0,"length":12,"style":"textShadowX:0px"},{"offset":0,"length":12,"style":"fontStretch:normal"},{"offset":0,"length":12,"style":"fontType:regular"},{"offset":0,"length":12,"style":"color:#FFFFFF"},{"offset":0,"length":12,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":12,"style":"textShadowY:4px"},{"offset":0,"length":12,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":12,"style":"lineHeight:135%"},{"offset":0,"length":12,"style":"letterSpacing:0%"},{"offset":0,"length":12,"style":"textHighlightEnable:false"},{"offset":0,"length":12,"style":"textTransform:none"},{"offset":0,"length":12,"style":"textShadowOpacity:none"},{"offset":0,"length":12,"style":"overridden:true"},{"offset":0,"length":12,"style":"textDecoration:none"},{"offset":0,"length":12,"style":"borderBottomStyle:none"},{"offset":0,"length":12,"style":"fontWeight:bold"},{"offset":0,"length":12,"style":"textShadowEnable:false"},{"offset":0,"length":12,"style":"hlnk:"},{"offset":0,"length":12,"style":"textShadowBlur:8px"},{"offset":0,"length":12,"style":"fontFamily:Arial"},{"offset":0,"length":12,"style":"desktop-fontSize:16"},{"offset":0,"length":12,"style":"backgroundColor:unset"},{"offset":0,"length":12,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":12,"style":"hlnkt:wp"},{"offset":0,"length":12,"style":"fontStyle:normal"},{"offset":0,"length":12,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":12,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":12,"style":"textOutlineEnable:false"},{"offset":0,"length":12,"style":"opacity:1"},{"offset":0,"length":12,"style":"defaultTextStrokeColor:#F1EEE6"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"dettg","text":"• Ability to design visualizations of content and complex experiences","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":69,"style":"textOutlineEnable:false"},{"offset":0,"length":69,"style":"opacity:1"},{"offset":0,"length":69,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":69,"style":"mobile-fontSize:16"},{"offset":0,"length":69,"style":"hlnke:true"},{"offset":0,"length":69,"style":"defaultTextShadow:none"},{"offset":0,"length":69,"style":"textShadow:none"},{"offset":0,"length":69,"style":"tablet-fontSize:16"},{"offset":0,"length":69,"style":"textShadowX:0px"},{"offset":0,"length":69,"style":"fontStretch:normal"},{"offset":0,"length":69,"style":"fontType:regular"},{"offset":0,"length":69,"style":"color:#FFFFFF"},{"offset":0,"length":69,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":69,"style":"textShadowY:4px"},{"offset":0,"length":69,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":69,"style":"lineHeight:135%"},{"offset":0,"length":69,"style":"letterSpacing:0%"},{"offset":0,"length":69,"style":"textHighlightEnable:false"},{"offset":0,"length":69,"style":"textTransform:none"},{"offset":0,"length":69,"style":"textShadowOpacity:none"},{"offset":0,"length":69,"style":"overridden:true"},{"offset":0,"length":69,"style":"textDecoration:none"},{"offset":0,"length":69,"style":"borderBottomStyle:none"},{"offset":0,"length":69,"style":"fontWeight:bold"},{"offset":0,"length":69,"style":"textShadowEnable:false"},{"offset":0,"length":69,"style":"hlnk:"},{"offset":0,"length":69,"style":"textShadowBlur:8px"},{"offset":0,"length":69,"style":"fontFamily:Arial"},{"offset":0,"length":69,"style":"desktop-fontSize:16"},{"offset":0,"length":69,"style":"backgroundColor:unset"},{"offset":0,"length":69,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":69,"style":"hlnkt:wp"},{"offset":0,"length":69,"style":"fontStyle:normal"},{"offset":0,"length":69,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":69,"style":"defaultTextStrokeWidth:1px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"12r3i","text":"such as flows, scenarios.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":25,"style":"backgroundColor:unset"},{"offset":0,"length":25,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":25,"style":"hlnkt:wp"},{"offset":0,"length":25,"style":"fontStyle:normal"},{"offset":0,"length":25,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":25,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":25,"style":"textOutlineEnable:false"},{"offset":0,"length":25,"style":"opacity:1"},{"offset":0,"length":25,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":25,"style":"mobile-fontSize:16"},{"offset":0,"length":25,"style":"hlnke:true"},{"offset":0,"length":25,"style":"defaultTextShadow:none"},{"offset":0,"length":25,"style":"textShadow:none"},{"offset":0,"length":25,"style":"tablet-fontSize:16"},{"offset":0,"length":25,"style":"textShadowX:0px"},{"offset":0,"length":25,"style":"fontStretch:normal"},{"offset":0,"length":25,"style":"fontType:regular"},{"offset":0,"length":25,"style":"color:#FFFFFF"},{"offset":0,"length":25,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":25,"style":"textShadowY:4px"},{"offset":0,"length":25,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":25,"style":"lineHeight:135%"},{"offset":0,"length":25,"style":"letterSpacing:0%"},{"offset":0,"length":25,"style":"textHighlightEnable:false"},{"offset":0,"length":25,"style":"textTransform:none"},{"offset":0,"length":25,"style":"textShadowOpacity:none"},{"offset":0,"length":25,"style":"overridden:true"},{"offset":0,"length":25,"style":"textDecoration:none"},{"offset":0,"length":25,"style":"borderBottomStyle:none"},{"offset":0,"length":25,"style":"fontWeight:bold"},{"offset":0,"length":25,"style":"textShadowEnable:false"},{"offset":0,"length":25,"style":"hlnk:"},{"offset":0,"length":25,"style":"textShadowBlur:8px"},{"offset":0,"length":25,"style":"fontFamily:Arial"},{"offset":0,"length":25,"style":"desktop-fontSize:16"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6963]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6963c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:6963,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6963',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si6973:{
name:'Text_85',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6973c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"20px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6933',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"6ci0c","text":"Sed ut perspiciatis und omnis iste natus error sit voluptatem accusantium.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":74,"style":"hlnk:"},{"offset":0,"length":74,"style":"hlnkt:wp"},{"offset":0,"length":74,"style":"textOutlineEnable:false"},{"offset":0,"length":74,"style":"opacity:1"},{"offset":0,"length":74,"style":"hlnke:true"},{"offset":0,"length":74,"style":"backgroundColor:unset"},{"offset":0,"length":74,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":74,"style":"textHighlightEnable:false"},{"offset":0,"length":74,"style":"textShadowEnable:false"},{"offset":0,"length":74,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6973]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6973c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:6973,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6973',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si6983:{
name:'FLIP_CARD_CONTAINER_7',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6983c',
tag:'container-flip-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"card":true},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si6756',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6991',
t:1268
}
,{
n:'si7041',
t:1268
}
]
,
containerType:'flip-card',
widgetProps:'{"visibilityInfo":{"card":true},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6756',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si6983c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6983,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6983',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#333333',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6991:{
name:'FLIP_CARD_FRONT_7',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6991c',
tag:'container-flip-card-front',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":false,"slide-item-svg":true},"alignment":{"slide-item-title":"CENTER","slide-item-subtitle":"CENTER","slide-item-svg":"CENTER"},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"flipcard-front-text-container":{"all":{"background":"transparent linear-gradient(0deg, #EAEAEACC 100%,  #A5A5A500 100%)","padding":"25px"},"tablet":{"padding":"15px"},"mobile":{"padding":"15px"}}}}',
parentGroup:'si6983',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6999',
t:15
}
,{
n:'si7011',
t:1250
}
,{
n:'si7021',
t:1250
}
,{
n:'si7031',
t:652
}
]
,
containerType:'flip-card-front',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":false,"slide-item-svg":true},"alignment":{"slide-item-title":"CENTER","slide-item-subtitle":"CENTER","slide-item-svg":"CENTER"},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"flipcard-front-text-container":{"all":{"background":"transparent linear-gradient(0deg, #EAEAEACC 100%,  #A5A5A500 100%)","padding":"25px"},"tablet":{"padding":"15px"},"mobile":{"padding":"15px"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6983',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si6991c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6991,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6991',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6999:{
name:'Asset_3_2',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si6999c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si6991',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
o:100,
irw:2003,
irh:2003,
w:2003,
h:2003,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6999]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6999c:{
b:[0,0,2003,2003],
fh:false,
fw:false,
uid:6999,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'60.288%',
h:'167.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'60.288%',
h:'167.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'60.288%',
h:'167.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/04386.png',
dn:'si6999',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,2004,2004],
vb:[-1,-1,2004,2004]
},
si7011:{
name:'Text_86',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7011c',
tag:'slide-item-title',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6991',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"3ecsl","text":"Tools","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7011]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7011c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:7011,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7011',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si7021:{
name:'Text_87',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7021c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6991',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"dnt65","text":"Lorem ipsum dolor sit amet, consectetur adipiscing elit.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":56,"style":"textOutlineEnable:false"},{"offset":0,"length":56,"style":"opacity:1"},{"offset":0,"length":56,"style":"hlnke:true"},{"offset":0,"length":56,"style":"backgroundColor:unset"},{"offset":0,"length":56,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":56,"style":"textHighlightEnable:false"},{"offset":0,"length":56,"style":"textShadowEnable:false"},{"offset":0,"length":56,"style":"overridden:false"},{"offset":0,"length":56,"style":"hlnk:"},{"offset":0,"length":56,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7021]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7021c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7021,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7021',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7031:{
name:'default_svg_6',
type:652,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7031c',
tag:'slide-item-svg',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'',
parentGroup:'si6991',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7031]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7031c:{
b:[666,367,700,401],
fh:false,
fw:false,
uid:7031,
iso:false,
css:{
360:{
l:'68.519%',
t:'60.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.519%',
lhID:-1,
lvEID:0,
lvV:'60.362%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'68.519%',
t:'60.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.519%',
lhID:-1,
lvEID:0,
lvV:'60.362%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'68.519%',
t:'60.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.519%',
lhID:-1,
lvEID:0,
lvV:'60.362%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si7031',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/06812.svg',
wofh:34,
wofw:34,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[665,366,701,402],
vb:[665,366,701,402]
},
si7041:{
name:'FLIP_CARD_BACK_7',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7041c',
tag:'container-flip-card-back',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":true,"slide-item-body":false},"alignment":{"slide-item-image":"CENTER","slide-item-title":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"RIGHT"},"designOptionStyles":{"all":{"padding":"0 40px"},"tablet":{"padding":"0 15px"},"mobile":{"padding":"0 15px"}},"childNodesCustomStyles":{"flipcard-back-image-container":{"all":{"width":"100%","height":"200px","margin":"36px auto"},"tablet":{"width":"100%","margin":"15px 0"},"mobile":{"width":"100%","margin":"15px auto"}}}}',
parentGroup:'si6983',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7049',
t:15
}
,{
n:'si7061',
t:1250
}
,{
n:'si7071',
t:1250
}
,{
n:'si7081',
t:1250
}
]
,
containerType:'flip-card-back',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":true,"slide-item-body":false},"alignment":{"slide-item-image":"CENTER","slide-item-title":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"RIGHT"},"designOptionStyles":{"all":{"padding":"0 40px"},"tablet":{"padding":"0 15px"},"mobile":{"padding":"0 15px"}},"childNodesCustomStyles":{"flipcard-back-image-container":{"all":{"width":"100%","height":"200px","margin":"36px auto"},"tablet":{"width":"100%","margin":"15px 0"},"mobile":{"width":"100%","margin":"15px auto"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6983',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7041c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7041,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7041',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7049:{
name:'Asset_3_3',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7049c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si7041',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:100,
iff:{
bc:'#000000'
}
,
o:100,
irw:2003,
irh:2003,
w:2003,
h:2003,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7049]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7049c:{
b:[0,0,2003,2003],
fh:false,
fw:false,
uid:7049,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'42.181%',
h:'67.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'42.181%',
h:'67.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'42.181%',
h:'67.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/04386.png',
dn:'si7049',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,2004,2004],
vb:[-1,-1,2004,2004]
},
si7061:{
name:'Text_88',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7061c',
tag:'slide-item-title',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si7041',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"5763b","text":"Tools","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"textDecoration:none"},{"offset":0,"length":5,"style":"borderBottomStyle:none"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"fontWeight:normal"},{"offset":0,"length":5,"style":"textShadowBlur:8px"},{"offset":0,"length":5,"style":"fontFamily:Arial"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"fontStyle:normal"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"tablet-fontSize:32"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"defaultTextShadow:none"},{"offset":0,"length":5,"style":"mobile-fontSize:28"},{"offset":0,"length":5,"style":"textShadow:none"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"fontStretch:normal"},{"offset":0,"length":5,"style":"fontType:regular"},{"offset":0,"length":5,"style":"color:#FFFFFF"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"textShadowY:4px"},{"offset":0,"length":5,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":5,"style":"letterSpacing:0%"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textTransform:none"},{"offset":0,"length":5,"style":"textShadowOpacity:none"},{"offset":0,"length":5,"style":"overridden:true"},{"offset":0,"length":5,"style":"desktop-fontSize:40"},{"offset":0,"length":5,"style":"lineHeight:120%"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-5","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7061]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7061c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:7061,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7061',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si7071:{
name:'Text_89',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7071c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si7041',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"dsvsc","text":"• Adobe captivate","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":17,"style":"lineHeight:135%"},{"offset":0,"length":17,"style":"letterSpacing:0%"},{"offset":0,"length":17,"style":"textHighlightEnable:false"},{"offset":0,"length":17,"style":"textTransform:none"},{"offset":0,"length":17,"style":"textShadowOpacity:none"},{"offset":0,"length":17,"style":"overridden:true"},{"offset":0,"length":17,"style":"textDecoration:none"},{"offset":0,"length":17,"style":"borderBottomStyle:none"},{"offset":0,"length":17,"style":"fontWeight:bold"},{"offset":0,"length":17,"style":"textShadowEnable:false"},{"offset":0,"length":17,"style":"hlnk:"},{"offset":0,"length":17,"style":"textShadowBlur:8px"},{"offset":0,"length":17,"style":"fontFamily:Arial"},{"offset":0,"length":17,"style":"defaultTextShadow:none"},{"offset":0,"length":17,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"desktop-fontSize:18"},{"offset":0,"length":17,"style":"fontStyle:normal"},{"offset":0,"length":17,"style":"hlnkt:wp"},{"offset":0,"length":17,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":17,"style":"textOutlineEnable:false"},{"offset":0,"length":17,"style":"opacity:1"},{"offset":0,"length":17,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":17,"style":"mobile-fontSize:16"},{"offset":0,"length":17,"style":"hlnke:true"},{"offset":0,"length":17,"style":"backgroundColor:unset"},{"offset":0,"length":17,"style":"textShadow:none"},{"offset":0,"length":17,"style":"tablet-fontSize:16"},{"offset":0,"length":17,"style":"textShadowX:0px"},{"offset":0,"length":17,"style":"fontStretch:normal"},{"offset":0,"length":17,"style":"fontType:regular"},{"offset":0,"length":17,"style":"color:#FFFFFF"},{"offset":0,"length":17,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":17,"style":"textShadowY:4px"},{"offset":0,"length":17,"style":"textShadowColor:#F1EEE61F"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"5idpj","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"bgvfs","text":"• Articulate 360","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":16,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":16,"style":"textShadowY:4px"},{"offset":0,"length":16,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":16,"style":"lineHeight:135%"},{"offset":0,"length":16,"style":"letterSpacing:0%"},{"offset":0,"length":16,"style":"textHighlightEnable:false"},{"offset":0,"length":16,"style":"textTransform:none"},{"offset":0,"length":16,"style":"textShadowOpacity:none"},{"offset":0,"length":16,"style":"overridden:true"},{"offset":0,"length":16,"style":"textDecoration:none"},{"offset":0,"length":16,"style":"borderBottomStyle:none"},{"offset":0,"length":16,"style":"fontWeight:bold"},{"offset":0,"length":16,"style":"textShadowEnable:false"},{"offset":0,"length":16,"style":"hlnk:"},{"offset":0,"length":16,"style":"textShadowBlur:8px"},{"offset":0,"length":16,"style":"fontFamily:Arial"},{"offset":0,"length":16,"style":"defaultTextShadow:none"},{"offset":0,"length":16,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":16,"style":"desktop-fontSize:18"},{"offset":0,"length":16,"style":"fontStyle:normal"},{"offset":0,"length":16,"style":"hlnkt:wp"},{"offset":0,"length":16,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":16,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":16,"style":"textOutlineEnable:false"},{"offset":0,"length":16,"style":"opacity:1"},{"offset":0,"length":16,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":16,"style":"mobile-fontSize:16"},{"offset":0,"length":16,"style":"hlnke:true"},{"offset":0,"length":16,"style":"backgroundColor:unset"},{"offset":0,"length":16,"style":"textShadow:none"},{"offset":0,"length":16,"style":"tablet-fontSize:16"},{"offset":0,"length":16,"style":"textShadowX:0px"},{"offset":0,"length":16,"style":"fontStretch:normal"},{"offset":0,"length":16,"style":"fontType:regular"},{"offset":0,"length":16,"style":"color:#FFFFFF"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"1daah","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"6hpt5","text":"• Adobe Illustrator","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"fontStretch:normal"},{"offset":0,"length":19,"style":"fontType:regular"},{"offset":0,"length":19,"style":"color:#FFFFFF"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textShadowY:4px"},{"offset":0,"length":19,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":19,"style":"lineHeight:135%"},{"offset":0,"length":19,"style":"letterSpacing:0%"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textTransform:none"},{"offset":0,"length":19,"style":"textShadowOpacity:none"},{"offset":0,"length":19,"style":"overridden:true"},{"offset":0,"length":19,"style":"textDecoration:none"},{"offset":0,"length":19,"style":"borderBottomStyle:none"},{"offset":0,"length":19,"style":"fontWeight:bold"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"textShadowBlur:8px"},{"offset":0,"length":19,"style":"fontFamily:Arial"},{"offset":0,"length":19,"style":"defaultTextShadow:none"},{"offset":0,"length":19,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":19,"style":"desktop-fontSize:18"},{"offset":0,"length":19,"style":"fontStyle:normal"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":19,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"opacity:1"},{"offset":0,"length":19,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":19,"style":"mobile-fontSize:16"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"textShadow:none"},{"offset":0,"length":19,"style":"tablet-fontSize:16"},{"offset":0,"length":19,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"4njgg","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"6mg7e","text":"• Adobe Photoshop","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":17,"style":"textShadow:none"},{"offset":0,"length":17,"style":"tablet-fontSize:16"},{"offset":0,"length":17,"style":"textShadowX:0px"},{"offset":0,"length":17,"style":"fontStretch:normal"},{"offset":0,"length":17,"style":"fontType:regular"},{"offset":0,"length":17,"style":"color:#FFFFFF"},{"offset":0,"length":17,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":17,"style":"textShadowY:4px"},{"offset":0,"length":17,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":17,"style":"lineHeight:135%"},{"offset":0,"length":17,"style":"letterSpacing:0%"},{"offset":0,"length":17,"style":"textHighlightEnable:false"},{"offset":0,"length":17,"style":"textTransform:none"},{"offset":0,"length":17,"style":"textShadowOpacity:none"},{"offset":0,"length":17,"style":"overridden:true"},{"offset":0,"length":17,"style":"textDecoration:none"},{"offset":0,"length":17,"style":"borderBottomStyle:none"},{"offset":0,"length":17,"style":"fontWeight:bold"},{"offset":0,"length":17,"style":"textShadowEnable:false"},{"offset":0,"length":17,"style":"hlnk:"},{"offset":0,"length":17,"style":"textShadowBlur:8px"},{"offset":0,"length":17,"style":"fontFamily:Arial"},{"offset":0,"length":17,"style":"defaultTextShadow:none"},{"offset":0,"length":17,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"desktop-fontSize:18"},{"offset":0,"length":17,"style":"fontStyle:normal"},{"offset":0,"length":17,"style":"hlnkt:wp"},{"offset":0,"length":17,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":17,"style":"textOutlineEnable:false"},{"offset":0,"length":17,"style":"opacity:1"},{"offset":0,"length":17,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":17,"style":"mobile-fontSize:16"},{"offset":0,"length":17,"style":"hlnke:true"},{"offset":0,"length":17,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"6ikka","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"8r1l5","text":"• Microsoft PowerPoint","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":22,"style":"mobile-fontSize:16"},{"offset":0,"length":22,"style":"hlnke:true"},{"offset":0,"length":22,"style":"backgroundColor:unset"},{"offset":0,"length":22,"style":"textShadow:none"},{"offset":0,"length":22,"style":"tablet-fontSize:16"},{"offset":0,"length":22,"style":"textShadowX:0px"},{"offset":0,"length":22,"style":"fontStretch:normal"},{"offset":0,"length":22,"style":"fontType:regular"},{"offset":0,"length":22,"style":"color:#FFFFFF"},{"offset":0,"length":22,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":22,"style":"textShadowY:4px"},{"offset":0,"length":22,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":22,"style":"lineHeight:135%"},{"offset":0,"length":22,"style":"letterSpacing:0%"},{"offset":0,"length":22,"style":"textHighlightEnable:false"},{"offset":0,"length":22,"style":"textTransform:none"},{"offset":0,"length":22,"style":"textShadowOpacity:none"},{"offset":0,"length":22,"style":"overridden:true"},{"offset":0,"length":22,"style":"textDecoration:none"},{"offset":0,"length":22,"style":"borderBottomStyle:none"},{"offset":0,"length":22,"style":"fontWeight:bold"},{"offset":0,"length":22,"style":"textShadowEnable:false"},{"offset":0,"length":22,"style":"hlnk:"},{"offset":0,"length":22,"style":"textShadowBlur:8px"},{"offset":0,"length":22,"style":"fontFamily:Arial"},{"offset":0,"length":22,"style":"defaultTextShadow:none"},{"offset":0,"length":22,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":22,"style":"desktop-fontSize:18"},{"offset":0,"length":22,"style":"fontStyle:normal"},{"offset":0,"length":22,"style":"hlnkt:wp"},{"offset":0,"length":22,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":22,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":22,"style":"textOutlineEnable:false"},{"offset":0,"length":22,"style":"opacity:1"},{"offset":0,"length":22,"style":"defaultTextStrokeColor:#F1EEE6"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"fo56s","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}},{"key":"avvld","text":"• Davinci Resolve","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":17,"style":"textOutlineEnable:false"},{"offset":0,"length":17,"style":"opacity:1"},{"offset":0,"length":17,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":17,"style":"mobile-fontSize:16"},{"offset":0,"length":17,"style":"hlnke:true"},{"offset":0,"length":17,"style":"backgroundColor:unset"},{"offset":0,"length":17,"style":"textShadow:none"},{"offset":0,"length":17,"style":"tablet-fontSize:16"},{"offset":0,"length":17,"style":"textShadowX:0px"},{"offset":0,"length":17,"style":"fontStretch:normal"},{"offset":0,"length":17,"style":"fontType:regular"},{"offset":0,"length":17,"style":"color:#FFFFFF"},{"offset":0,"length":17,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":17,"style":"textShadowY:4px"},{"offset":0,"length":17,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":17,"style":"lineHeight:135%"},{"offset":0,"length":17,"style":"letterSpacing:0%"},{"offset":0,"length":17,"style":"textHighlightEnable:false"},{"offset":0,"length":17,"style":"textTransform:none"},{"offset":0,"length":17,"style":"textShadowOpacity:none"},{"offset":0,"length":17,"style":"overridden:true"},{"offset":0,"length":17,"style":"textDecoration:none"},{"offset":0,"length":17,"style":"borderBottomStyle:none"},{"offset":0,"length":17,"style":"fontWeight:bold"},{"offset":0,"length":17,"style":"textShadowEnable:false"},{"offset":0,"length":17,"style":"hlnk:"},{"offset":0,"length":17,"style":"textShadowBlur:8px"},{"offset":0,"length":17,"style":"fontFamily:Arial"},{"offset":0,"length":17,"style":"defaultTextShadow:none"},{"offset":0,"length":17,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"desktop-fontSize:18"},{"offset":0,"length":17,"style":"fontStyle:normal"},{"offset":0,"length":17,"style":"hlnkt:wp"},{"offset":0,"length":17,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"WebkitTextStrokeColor:#F1EEE6"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-3","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7071]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7071c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:7071,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7071',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si7081:{
name:'Text_90',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7081c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"20px"},"tablet":{},"mobile":{}}}',
parentGroup:'si7041',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"einpu","text":"Sed ut perspiciatis und omnis iste natus error sit voluptatem accusantium.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":74,"style":"hlnke:true"},{"offset":0,"length":74,"style":"backgroundColor:unset"},{"offset":0,"length":74,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":74,"style":"textHighlightEnable:false"},{"offset":0,"length":74,"style":"textShadowEnable:false"},{"offset":0,"length":74,"style":"overridden:false"},{"offset":0,"length":74,"style":"hlnk:"},{"offset":0,"length":74,"style":"hlnkt:wp"},{"offset":0,"length":74,"style":"textOutlineEnable:false"},{"offset":0,"length":74,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7081]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7081c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7081,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7081',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7091:{
name:'FLIP_CARD_CONTAINER_8',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7091c',
tag:'container-flip-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"card":true},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si6756',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7099',
t:1268
}
,{
n:'si7149',
t:1268
}
]
,
containerType:'flip-card',
widgetProps:'{"visibilityInfo":{"card":true},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6756',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si7091c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7091,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7091',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7099:{
name:'FLIP_CARD_FRONT_8',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7099c',
tag:'container-flip-card-front',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":false,"slide-item-svg":true},"alignment":{"slide-item-title":"CENTER","slide-item-subtitle":"CENTER","slide-item-svg":"CENTER"},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"flipcard-front-text-container":{"all":{"background":"transparent linear-gradient(0deg, #EAEAEACC 100%,  #A5A5A500 100%)","padding":"25px"},"tablet":{"padding":"15px"},"mobile":{"padding":"15px"}}}}',
parentGroup:'si7091',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7107',
t:15
}
,{
n:'si7119',
t:1250
}
,{
n:'si7129',
t:1250
}
,{
n:'si7139',
t:652
}
]
,
containerType:'flip-card-front',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":false,"slide-item-svg":true},"alignment":{"slide-item-title":"CENTER","slide-item-subtitle":"CENTER","slide-item-svg":"CENTER"},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"flipcard-front-text-container":{"all":{"background":"transparent linear-gradient(0deg, #EAEAEACC 100%,  #A5A5A500 100%)","padding":"25px"},"tablet":{"padding":"15px"},"mobile":{"padding":"15px"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7091',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7099c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7099,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7099',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7107:{
name:'default_image4_2',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7107c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si7099',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
o:100,
irw:586,
irh:1018,
w:586,
h:1018,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7107]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7107c:{
b:[0,0,586,1018],
fh:false,
fw:false,
uid:7107,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'60.288%',
h:'167.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'60.288%',
h:'167.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'60.288%',
h:'167.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/04028.png',
dn:'si7107',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,587,1019],
vb:[-1,-1,587,1019]
},
si7119:{
name:'Text_91',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7119c',
tag:'slide-item-title',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si7099',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"4nnq4","text":"Title 04","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7119]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7119c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7119,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7119',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7129:{
name:'Text_92',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7129c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si7099',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"6aft9","text":"Lorem ipsum dolor sit amet, consectetur adipiscing elit.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":56,"style":"hlnk:"},{"offset":0,"length":56,"style":"hlnkt:wp"},{"offset":0,"length":56,"style":"textOutlineEnable:false"},{"offset":0,"length":56,"style":"opacity:1"},{"offset":0,"length":56,"style":"hlnke:true"},{"offset":0,"length":56,"style":"backgroundColor:unset"},{"offset":0,"length":56,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":56,"style":"textHighlightEnable:false"},{"offset":0,"length":56,"style":"textShadowEnable:false"},{"offset":0,"length":56,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7129]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7129c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7129,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7129',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7139:{
name:'default_svg_7',
type:652,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7139c',
tag:'slide-item-svg',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'',
parentGroup:'si7099',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7139]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7139c:{
b:[666,367,700,401],
fh:false,
fw:false,
uid:7139,
iso:false,
css:{
360:{
l:'68.519%',
t:'60.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.519%',
lhID:-1,
lvEID:0,
lvV:'60.362%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'68.519%',
t:'60.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.519%',
lhID:-1,
lvEID:0,
lvV:'60.362%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'68.519%',
t:'60.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.519%',
lhID:-1,
lvEID:0,
lvV:'60.362%',
lvID:-1,
w:'3.498%',
h:'5.592%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si7139',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/06812.svg',
wofh:34,
wofw:34,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[665,366,701,402],
vb:[665,366,701,402]
},
si7149:{
name:'FLIP_CARD_BACK_8',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7149c',
tag:'container-flip-card-back',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":true,"slide-item-body":true},"alignment":{"slide-item-image":"CENTER","slide-item-title":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"RIGHT"},"designOptionStyles":{"all":{"padding":"0 40px"},"tablet":{"padding":"0 15px"},"mobile":{"padding":"0 15px"}},"childNodesCustomStyles":{"flipcard-back-image-container":{"all":{"width":"100%","height":"200px","margin":"36px auto"},"tablet":{"width":"100%","margin":"15px 0"},"mobile":{"width":"100%","margin":"15px auto"}}}}',
parentGroup:'si7091',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7157',
t:15
}
,{
n:'si7169',
t:1250
}
,{
n:'si7179',
t:1250
}
,{
n:'si7189',
t:1250
}
]
,
containerType:'flip-card-back',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-title":true,"slide-item-subtitle":true,"slide-item-body":true},"alignment":{"slide-item-image":"CENTER","slide-item-title":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"RIGHT"},"designOptionStyles":{"all":{"padding":"0 40px"},"tablet":{"padding":"0 15px"},"mobile":{"padding":"0 15px"}},"childNodesCustomStyles":{"flipcard-back-image-container":{"all":{"width":"100%","height":"200px","margin":"36px auto"},"tablet":{"width":"100%","margin":"15px 0"},"mobile":{"width":"100%","margin":"15px auto"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si7091',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7149c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7149,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7149',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si7157:{
name:'default_image4_3',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7157c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si7149',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
o:100,
irw:410,
irh:410,
w:410,
h:410,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7157]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7157c:{
b:[0,0,410,410],
fh:false,
fw:false,
uid:7157,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'42.181%',
h:'67.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'42.181%',
h:'67.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'42.181%',
h:'67.434%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/04081.png',
dn:'si7157',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,411,411],
vb:[-1,-1,411,411]
},
si7169:{
name:'Text_93',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7169c',
tag:'slide-item-title',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si7149',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"a4l97","text":"Title 04","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-heading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7169]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7169c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7169,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7169',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7179:{
name:'Text_94',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7179c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"5px"},"tablet":{},"mobile":{}}}',
parentGroup:'si7149',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"bg34k","text":"Sed ut perspiciatis und omnis iste natus error.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":47,"style":"hlnk:"},{"offset":0,"length":47,"style":"hlnkt:wp"},{"offset":0,"length":47,"style":"textOutlineEnable:false"},{"offset":0,"length":47,"style":"opacity:1"},{"offset":0,"length":47,"style":"hlnke:true"},{"offset":0,"length":47,"style":"backgroundColor:unset"},{"offset":0,"length":47,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":47,"style":"textHighlightEnable:false"},{"offset":0,"length":47,"style":"textShadowEnable:false"},{"offset":0,"length":47,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7179]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7179c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7179,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7179',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7189:{
name:'Text_95',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7189c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"20px"},"tablet":{},"mobile":{}}}',
parentGroup:'si7149',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"f36hh","text":"Sed ut perspiciatis und omnis iste natus error sit voluptatem accusantium.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":74,"style":"hlnk:"},{"offset":0,"length":74,"style":"hlnkt:wp"},{"offset":0,"length":74,"style":"textOutlineEnable:false"},{"offset":0,"length":74,"style":"opacity:1"},{"offset":0,"length":74,"style":"hlnke:true"},{"offset":0,"length":74,"style":"backgroundColor:unset"},{"offset":0,"length":74,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":74,"style":"textHighlightEnable:false"},{"offset":0,"length":74,"style":"textShadowEnable:false"},{"offset":0,"length":74,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7189]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7189c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:7189,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7189',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si7199:{
name:'Slide_Buttons_Widget_4',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7199c',
tag:'slide-buttons-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","justifyContent":"space-between","padding":"25px 0px 44px 0px"}}}',
parentGroup:'si6738',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si7207',
t:29
}
,{
n:'si7226',
t:29
}
]
,
containerType:'slide-buttons',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","justifyContent":"space-between","padding":"25px 0px 44px 0px"}}}',
option:'SLIDE_BUTTONS_DEFAULT_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6738',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si7199c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:7199,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7199',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ff0000',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si7207:{
name:'Button_61',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7207c',
tag:'slide-buttons-previous-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"e654a","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_default","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8sq79","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"30"}},"designOption":"SLIDE_PREVIOUS_BUTTON_ITEM_OPTION","iconProps":{"srcPath":"0649.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"62t6n","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1h5ua","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"780u9","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si7199',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToPreviousSlide(7225);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7207]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7207c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7207,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7207',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si7226:{
name:'Button_62',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si7226c',
tag:'slide-buttons-next-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":true,"hover":true,"visited":false},"normal":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"125mn","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_default","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"abhg9","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"30"}},"designOption":"SLIDE_NEXT_BUTTON_ITEM_OPTION","iconProps":{"srcPath":"0671.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"88kok","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7777l","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2anav","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si7199',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToNextSlide(7244);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[7226]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si7226c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:7226,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si7226',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si8407:{
name:'Multi_Column_Text_1',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8407c',
tag:'container-multicolumn',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"left":10,"right":10,"top":66,"bottom":66},"visibilityInfo":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"numberOfChildren":2,"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"25px"},"tablet":{},"mobile":{"display":"flex","flexDirection":"column"}}}',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si8415',
t:1268
}
,{
n:'si8469',
t:1268
}
,{
n:'si8523',
t:1268
}
]
,
containerType:'multi-column-content',
widgetProps:'{"padding":{"left":10,"right":10,"top":66,"bottom":66},"visibilityInfo":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"numberOfChildren":2,"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"25px"},"tablet":{},"mobile":{"display":"flex","flexDirection":"column"}}}',
option:'DEFAULT_MULTIPLE_COLUMN_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si8407c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:8407,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8407',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--widget-container--fillcolor)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si8415:{
name:'Text_Column_Group_1',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8415c',
tag:'container-multicolumn-Card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":true,"slide-item-body":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si8407',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si8423',
t:1250
}
,{
n:'si8433',
t:1250
}
,{
n:'si8443',
t:1250
}
,{
n:'si8453',
t:29
}
]
,
containerType:'text-column-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":true,"slide-item-body":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si8407',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si8415c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:8415,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8415',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si8423:{
name:'Text_115',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8423c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si8415',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"ea924","text":"Bachelor of Engineering","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":23,"style":"hlnk:"},{"offset":0,"length":23,"style":"hlnkt:wp"},{"offset":0,"length":23,"style":"textOutlineEnable:false"},{"offset":0,"length":23,"style":"opacity:1"},{"offset":0,"length":23,"style":"hlnke:true"},{"offset":0,"length":23,"style":"backgroundColor:unset"},{"offset":0,"length":23,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":23,"style":"textHighlightEnable:false"},{"offset":0,"length":23,"style":"textShadowEnable:false"},{"offset":0,"length":23,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-heading-5"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8423]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8423c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:8423,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8423',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si8433:{
name:'Text_116',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8433c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si8415',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"c9sgp","text":"EIPS","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-3"}},{"key":"9lv9m","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-3"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8433]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8433c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:8433,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8433',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si8443:{
name:'Text_117',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8443c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si8415',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"cfuc6","text":"Electronics and communication","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":29,"style":"hlnk:"},{"offset":0,"length":29,"style":"hlnkt:wp"},{"offset":0,"length":29,"style":"textOutlineEnable:false"},{"offset":0,"length":29,"style":"opacity:1"},{"offset":0,"length":29,"style":"hlnke:true"},{"offset":0,"length":29,"style":"backgroundColor:unset"},{"offset":0,"length":29,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":29,"style":"textHighlightEnable:false"},{"offset":0,"length":29,"style":"textShadowEnable:false"},{"offset":0,"length":29,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"fn594","text":"2018","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-body-2"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8443]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8443c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:8443,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8443',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si8453:{
name:'Button_77',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8453c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9g5kh","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dsbbj","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"68gpc","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7ehir","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"efd0h","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si8415',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8453]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8453c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:8453,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8453',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si8469:{
name:'Text_Column_Group_2',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8469c',
tag:'container-multicolumn-Card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":true,"slide-item-body":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si8407',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si8477',
t:1250
}
,{
n:'si8487',
t:1250
}
,{
n:'si8497',
t:1250
}
,{
n:'si8507',
t:29
}
]
,
containerType:'text-column-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":true,"slide-item-body":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si8407',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si8469c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:8469,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8469',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si8477:{
name:'Text_118',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8477c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si8469',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"c32dq","text":"Polytechnic","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8477]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8477c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:8477,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8477',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si8487:{
name:'Text_119',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8487c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si8469',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"8eeq1","text":"Dr.B. R. Ambedkar Govt. Poytechnic Ambota Una HP","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":48,"style":"fontStretch:normal"},{"offset":0,"length":48,"style":"fontType:regular"},{"offset":0,"length":48,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":48,"style":"textShadowY:4px"},{"offset":0,"length":48,"style":"lineHeight:115%"},{"offset":0,"length":48,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":48,"style":"letterSpacing:0%"},{"offset":0,"length":48,"style":"textHighlightEnable:false"},{"offset":0,"length":48,"style":"textTransform:none"},{"offset":0,"length":48,"style":"color:#020C1C"},{"offset":0,"length":48,"style":"textShadowOpacity:none"},{"offset":0,"length":48,"style":"overridden:true"},{"offset":0,"length":48,"style":"textDecoration:none"},{"offset":0,"length":48,"style":"borderBottomStyle:none"},{"offset":0,"length":48,"style":"textShadowEnable:false"},{"offset":0,"length":48,"style":"hlnk:"},{"offset":0,"length":48,"style":"fontWeight:normal"},{"offset":0,"length":48,"style":"textShadowBlur:8px"},{"offset":0,"length":48,"style":"fontFamily:Arial"},{"offset":0,"length":48,"style":"desktop-fontSize:26"},{"offset":0,"length":48,"style":"backgroundColor:unset"},{"offset":0,"length":48,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":48,"style":"hlnkt:wp"},{"offset":0,"length":48,"style":"fontStyle:normal"},{"offset":0,"length":48,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":48,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":48,"style":"textOutlineEnable:false"},{"offset":0,"length":48,"style":"opacity:1"},{"offset":0,"length":48,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":48,"style":"tablet-fontSize:22"},{"offset":0,"length":48,"style":"hlnke:true"},{"offset":0,"length":48,"style":"defaultTextShadow:none"},{"offset":0,"length":48,"style":"textShadow:none"},{"offset":0,"length":48,"style":"mobile-fontSize:18"},{"offset":0,"length":48,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-3","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8487]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8487c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:8487,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8487',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si8497:{
name:'Text_120',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8497c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si8469',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"ctein","text":"Electronics and communication","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":29,"style":"hlnkt:wp"},{"offset":0,"length":29,"style":"textOutlineEnable:false"},{"offset":0,"length":29,"style":"opacity:1"},{"offset":0,"length":29,"style":"hlnke:true"},{"offset":0,"length":29,"style":"backgroundColor:unset"},{"offset":0,"length":29,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":29,"style":"textHighlightEnable:false"},{"offset":0,"length":29,"style":"textShadowEnable:false"},{"offset":0,"length":29,"style":"overridden:false"},{"offset":0,"length":29,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"4980i","text":"2015","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-body-2"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8497]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8497c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:8497,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8497',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si8507:{
name:'Button_78',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8507c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1lhp6","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6l5a7","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"96a03","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ab1ne","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"abgp7","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si8469',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8507]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8507c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:8507,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8507',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si8523:{
name:'Text_Column_Group_3',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8523c',
tag:'container-multicolumn-Card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":true,"slide-item-body":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si8407',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si8531',
t:1250
}
,{
n:'si8541',
t:1250
}
,{
n:'si8551',
t:1250
}
,{
n:'si8561',
t:29
}
]
,
containerType:'text-column-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":true,"slide-item-body":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si8407',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si8523c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:8523,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8523',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si8531:{
name:'Text_121',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8531c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si8523',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"f05gf","text":"Title","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8531]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8531c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:8531,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8531',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si8541:{
name:'Text_122',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8541c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si8523',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"1amag","text":"At vero eos et accusamus et iusto.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":34,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":34,"style":"textHighlightEnable:false"},{"offset":0,"length":34,"style":"textShadowEnable:false"},{"offset":0,"length":34,"style":"overridden:false"},{"offset":0,"length":34,"style":"hlnk:"},{"offset":0,"length":34,"style":"hlnkt:wp"},{"offset":0,"length":34,"style":"textOutlineEnable:false"},{"offset":0,"length":34,"style":"opacity:1"},{"offset":0,"length":34,"style":"hlnke:true"},{"offset":0,"length":34,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-subheading-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8541]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8541c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:8541,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8541',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si8551:{
name:'Text_123',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8551c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si8523',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"12b93","text":"Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do eiusmod tempor incididunt.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":89,"style":"hlnk:"},{"offset":0,"length":89,"style":"hlnkt:wp"},{"offset":0,"length":89,"style":"textOutlineEnable:false"},{"offset":0,"length":89,"style":"opacity:1"},{"offset":0,"length":89,"style":"hlnke:true"},{"offset":0,"length":89,"style":"backgroundColor:unset"},{"offset":0,"length":89,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":89,"style":"textHighlightEnable:false"},{"offset":0,"length":89,"style":"textShadowEnable:false"},{"offset":0,"length":89,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8551]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8551c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:8551,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8551',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si8561:{
name:'Button_79',
type:29,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si8561c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"0481.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3jq8s","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"621uk","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"870hd","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dnb9a","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"320ks","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si8523',
retainState:false,
immo:false,
apsn:'Slide4392',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8561]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8561c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:8561,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8561',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
Slide4392:{
lb:'Shubham Thakur Resume',
id:4392,
from:1,
to:90,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide4392c',
st:'Normal Slide',
sk:'Introduction',
slideTag:'introduction-slide',
type:30,
accProps:{
a11yTabOrder:['si6764','si6875','si6983'],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si4414',
t:1268
}
,{
n:'si4520',
t:1268
}
,{
n:'si7245',
t:1268
}
,{
n:'si6738',
t:1268
}
,{
n:'si8407',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
7225:{
ts:''
}
,
7244:{
ts:''
}
,
8029:{
ts:''
}
,
8048:{
ts:''
}

}

},
Slide4392c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:4392,
dn:'Slide4392',
visible:'1'
},
quizzingData:{
allowBackwardMovement:true,
allowReviewMode:true,
reviewShowAnswers:true,
it:true,
firstSlideInQuiz:-1,
lastSlideInQuiz:-1,
quizScopeEndSlide:-1,
maxScore:0,
minScore:0,
maxPretestScore:0,
numQuestionsInQuiz:0,
numQuizAttemptsAllowed:1,
passingScore:0,
quizInfoCurrentAttempt:0,
quizInfoPercentScored:0,
quizMandateLevel:0,
quizID:203,
questionPoolsInitialized:true,
quizInfoAttempts:1,
quizInfoLastSlidePointScored:0,
quizInfoMaxAttemptsOnCurrentQuestion:1,
quizInfoPassFail:0,
quizInfoPointsPerQuestionSlide:0,
quizInfoPointsScored:0,
quizInfoQuizPassPercent:80,
quizInfoQuizPassPoints:0,
quizInfoTotalCorrectAnswers:0,
quizInfoTotalProjectPoints:0,
quizInfoTotalQuestionsPerProject:0,
quizInfoTotalQuizPoints:0,
quizInfoTotalUnansweredQuestions:0,
reportingEnabled:true,
submitAll:false,
hidePlaybarInQuiz:false,
quizBranchAware:false,
passFailPassingScoreTypeInPrecent:true,
passFailPassingScoreValue:80,
showRetake:false,
showReviewButtons:true,
oid:'Quiz_2023819191226',
quizVariableVsIdMap:{
learnerId:'var353',
learnerName:'var354',
isInQuizScope:'var375',
isInReviewMode:'var376',
quizInfoPercentScored:'var377',
quizInfoAttempts:'var378',
quizInfoPassFail:'var379',
score:'var380',
quizInfoQuizPassPercent:'var381',
passingScore:'var382',
quizInfoTotalCorrectAnswers:'var383',
maxScore:'var384',
quizInfoTotalQuestionsPerProject:'var385',
quizInfoTotalUnansweredQuestions:'var386',
quizInfoAnswerChoice:'var387',
quizInfoPreviousQuestionScore:'var388',
questionInfoMaxAttempts:'var389',
questionInfoNegativePoints:'var390',
questionInfoPointsAssigned:'var391'
}

},
quizReportingData:{
lWriteDebugInfo:false,
lmsType:1,
sendScoreAsPercent:false,
trackingLevel:0,
slideViewPercentage:100,
reportingOption:0,
slideViewsForSuccess:0,
slideViewsTypeForSuccess:0,
slideViewsForCompletion:100,
slideViewsTypeForCompletion:0,
quizCriteriaForCompletion:0,
quizCriteriaForSuccess:0,
completionCriteria:3,
successCriteria:1,
companyName:'',
departmentName:'',
courseName:'',
courseNode:'',
isTrackedFlag:true,
trackingUrlEncodeVersionAndSession:0,
commitDataOnEverySlide:false,
trackingSendResumeData:true,
cmiExitNormalAfterCompletion:false,
lmsInitializationString:'cp.movie.playbackController.SetLMSType();cp.movie.playbackController.SetSendScoreAsPercent();cp.movie.playbackController.SetTrackingLevel();cp.movie.playbackController.SetSlideViewPercentage();cp.movie.playbackController.SetReportingOption();cp.movie.playbackController.SetSlideViewsForSuccess();cp.movie.playbackController.SetSlideViewsForCompletion();cp.movie.playbackController.SetQuizCriteriaForCompletion();cp.movie.playbackController.SetQuizCriteriaForSuccess();cp.movie.playbackController.SetCompletionCriteria();cp.movie.playbackController.SetSuccessCriteria();cp.movie.playbackController.SetDirectory();cp.movie.playbackController.SetCourseNode();cp.movie.playbackController.SetIsTrackedFlag();cp.movie.playbackController.SetTrackingUrlEncodeVersionAndSession();cp.movie.playbackController.SetCommitDataOnEverySlide();cp.movie.playbackController.SetTrackingSendResumeData();cp.movie.playbackController.SetCmiExitNormalAfterCompletion();'
},
var353var353:{
vid:353,
name:'LMS.LearnerID',
vv:'',
vvt:2,
vt:0
},
var354var354:{
vid:354,
name:'LMS.LearnerName',
vv:'',
vvt:2,
vt:0
},
var355var355:{
vid:355,
name:'LMS.CourseName',
vv:'Captivate E-Learning Course',
vvt:2,
vt:0
},
var356var356:{
vid:356,
name:'Project.ClosedCaptions',
vv:1,
vvt:0,
vt:9
},
var357var357:{
vid:357,
name:'Project.MuteAudio',
vv:0,
vvt:0,
vt:9
},
var358var358:{
vid:358,
name:'Project.ShowPlaybar',
vv:1,
vvt:0,
vt:9
},
var359var359:{
vid:359,
name:'Project.ShowTOC',
vv:0,
vvt:0,
vt:9
},
var360var360:{
vid:360,
name:'Project.AudioLevel',
vv:100,
vvt:1,
vt:9
},
var361var361:{
vid:361,
name:'Project.LockTOC',
vv:0,
vvt:0,
vt:9
},
var362var362:{
vid:362,
name:'Project.CurrentSlideNumber',
vv:1,
vvt:1,
vt:9
},
var363var363:{
vid:363,
name:'Project.CurrentSlideName',
vv:'slide',
vvt:2,
vt:9
},
var364var364:{
vid:364,
name:'Project.SlideCount',
vv:1,
vvt:1,
vt:9
},
var365var365:{
vid:365,
name:'Date.Today',
vv:'dd',
vvt:3,
vt:5
},
var366var366:{
vid:366,
name:'Date.DateMMDDYY',
vv:'mm/dd/yyyy',
vvt:3,
vt:5
},
var367var367:{
vid:367,
name:'Date.DateDDMMYY',
vv:'dd/mm/yyyy',
vvt:3,
vt:5
},
var368var368:{
vid:368,
name:'Date.Day',
vv:'1',
vvt:3,
vt:5
},
var369var369:{
vid:369,
name:'Date.Hours',
vv:'hh',
vvt:3,
vt:5
},
var370var370:{
vid:370,
name:'Date.LocaleString',
vv:'',
vvt:3,
vt:5
},
var371var371:{
vid:371,
name:'Date.Minutes',
vv:'mm',
vvt:3,
vt:5
},
var372var372:{
vid:372,
name:'Date.Month',
vv:'mm',
vvt:3,
vt:5
},
var373var373:{
vid:373,
name:'Date.Time',
vv:'hh:mm:ss',
vvt:3,
vt:5
},
var374var374:{
vid:374,
name:'Date.Year',
vv:'yyyy',
vvt:3,
vt:5
},
var375var375:{
vid:375,
name:'Quiz.InScope',
vv:0,
vvt:0,
vt:7
},
var376var376:{
vid:376,
name:'Quiz.InReview',
vv:0,
vvt:0,
vt:7
},
var377var377:{
vid:377,
name:'Quiz.PercentageScore',
vv:'0',
vvt:2,
vt:7
},
var378var378:{
vid:378,
name:'Quiz.AttemptCount',
vv:0,
vvt:1,
vt:7
},
var379var379:{
vid:379,
name:'Quiz.Pass',
vv:0,
vvt:0,
vt:7
},
var380var380:{
vid:380,
name:'Quiz.Score',
vv:0,
vvt:1,
vt:7
},
var381var381:{
vid:381,
name:'Quiz.PassPercentage',
vv:80,
vvt:1,
vt:7
},
var382var382:{
vid:382,
name:'Quiz.PassPoints',
vv:0,
vvt:1,
vt:7
},
var383var383:{
vid:383,
name:'Quiz.CorrectAnswerCount',
vv:0,
vvt:1,
vt:7
},
var384var384:{
vid:384,
name:'Quiz.MaxScore',
vv:0,
vvt:1,
vt:7
},
var385var385:{
vid:385,
name:'Quiz.QuestionCount',
vv:0,
vvt:1,
vt:7
},
var386var386:{
vid:386,
name:'Quiz.UnansweredQuestionCount',
vv:0,
vvt:1,
vt:7
},
var387var387:{
vid:387,
name:'Question.AnswerChoice',
vv:'',
vvt:2,
vt:7
},
var388var388:{
vid:388,
name:'Question.PreviousQuestionScore',
vv:0,
vvt:1,
vt:7
},
var389var389:{
vid:389,
name:'Question.MaxAttempts',
vv:0,
vvt:1,
vt:7
},
var390var390:{
vid:390,
name:'Question.NegativePoints',
vv:0,
vvt:1,
vt:7
},
var391var391:{
vid:391,
name:'Question.PointsAssigned',
vv:0,
vvt:1,
vt:7
},
variableIdVsNameMap:{
var353:'LMS.LearnerID',
var354:'LMS.LearnerName',
var355:'LMS.CourseName',
var356:'Project.ClosedCaptions',
var357:'Project.MuteAudio',
var358:'Project.ShowPlaybar',
var359:'Project.ShowTOC',
var360:'Project.AudioLevel',
var361:'Project.LockTOC',
var362:'Project.CurrentSlideNumber',
var363:'Project.CurrentSlideName',
var364:'Project.SlideCount',
var365:'Date.Today',
var366:'Date.DateMMDDYY',
var367:'Date.DateDDMMYY',
var368:'Date.Day',
var369:'Date.Hours',
var370:'Date.LocaleString',
var371:'Date.Minutes',
var372:'Date.Month',
var373:'Date.Time',
var374:'Date.Year',
var375:'Quiz.InScope',
var376:'Quiz.InReview',
var377:'Quiz.PercentageScore',
var378:'Quiz.AttemptCount',
var379:'Quiz.Pass',
var380:'Quiz.Score',
var381:'Quiz.PassPercentage',
var382:'Quiz.PassPoints',
var383:'Quiz.CorrectAnswerCount',
var384:'Quiz.MaxScore',
var385:'Quiz.QuestionCount',
var386:'Quiz.UnansweredQuestionCount',
var387:'Question.AnswerChoice',
var388:'Question.PreviousQuestionScore',
var389:'Question.MaxAttempts',
var390:'Question.NegativePoints',
var391:'Question.PointsAssigned'
},
project:{
fps:30,
hasTOC:1,
hasCC:false,
showClosedCaptions:true,
w:1366,
h:768,
iw:1366,
ih:768,
prm:[1,1,0,0],
stateNameToLocalizedStateNameMap:{
kCPNormalState:'Normal',
kCPDownState:'Click',
kCPRolloverState:'Hover',
kCPVisitedState:'Visited',
kCPDragoverState:'',
kCPDragstartState:'',
kCPDropCorrect:'',
kCPDropIncorrect:'',
kCPDropAccept:'',
kCPDropReject:''
}
,
prjBgColor:'#ffffff',
pkt:0,
htmlBgColor:'#f5f4f1',
shc:false,
pN:'Shubham Resume.cpt'
},
projectThemeData:{
image_presets:'{\\
  "theme_image_default": {\\
    "meta": {\\
      "name": "kCPImageStyleNormal",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_default--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_default--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Normal",\\
        "mixBlendMode": "normal"\\
      }\\
    }\\
  },\\
\\
  "theme_image_greyscale": {\\
    "meta": {\\
      "name": "kCPImageStyleGreyscale",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_greyscale--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_greyscale--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Greyscale",\\
        "mixBlendMode": "saturation",\\
        "intensity": "var(--theme_image_greyscale--intensity)",\\
        "filterColor": {\\
          "fill": "#000000",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_lighten": {\\
    "meta": {\\
      "name": "kCPImageStyleLighten",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_lighten--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_lighten--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Lighten",\\
        "mixBlendMode": "soft-light",\\
        "intensity": "var(--theme_image_lighten--intensity)",\\
        "filterColor": {\\
          "fill": "#FFFFFF",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_darken": {\\
    "meta": {\\
      "name": "kCPImageStyleDarken",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_darken--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_darken--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Darken",\\
        "mixBlendMode": "soft-light",\\
        "intensity": "var(--theme_image_darken--intensity)",\\
        "filterColor": {\\
          "fill": "var(--black)",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_overlay": {\\
    "meta": {\\
      "name": "kCPImageStyleOverlay",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_overlay--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_overlay--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Overlay",\\
        "mixBlendMode": "overlay",\\
        "intensity": "var(--theme_image_overlay--intensity)",\\
        "filterColor": {\\
          "fill": "var(--theme_image_overlay--primaryFillColor)",\\
          "fillOpacity": 1,\\
          "gradientProps": {\\
            "linearGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 0 },\\
                { "x": 50, "y": 100 }\\
              ]\\
            },\\
            "radialGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 50 },\\
                { "x": 100, "y": 50 }\\
              ],\\
              "radialHandlePoints": [\\
                { "x": 50, "y": 100 },\\
                { "x": 100, "y": 100 }\\
              ]\\
            }\\
          }\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_colorize": {\\
    "meta": {\\
      "name": "kCPImageStyleColorize",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_colorize--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_colorize--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Colorize",\\
        "mixBlendMode": "color",\\
        "intensity": "var(--theme_image_colorize--intensity)",\\
        "filterColor": {\\
          "fill": "var(--theme_image_colorize--primaryFillColor)",\\
          "fillOpacity": 1,\\
          "gradientProps": {\\
            "linearGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 0 },\\
                { "x": 50, "y": 100 }\\
              ]\\
            },\\
            "radialGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 50 },\\
                { "x": 100, "y": 50 }\\
              ],\\
              "radialHandlePoints": [\\
                { "x": 50, "y": 100 },\\
                { "x": 100, "y": 100 }\\
              ]\\
            }\\
          }\\
        }\\
      }\\
    }\\
  }\\
}\\
',
meta:'{\\
  "name": "kCPThemeLight",\\
  "description": "kCPThemeLightDescription",\\
  "version": 0.1,\\
  "guid": "Default-Light-Theme",\\
  "default_presets": {\\
    "0": "cp_default_shape_solid_style",\\
    "1": "text-body-1",\\
    "2": "theme_image_default",\\
    "3": "cp_default_slide_style",\\
    "4": "cp_textinshape_body_1",\\
    "5": "cp_default_line_shape_style",\\
    "6": "cp_default_complex_shape_solid_style",\\
    "7": "cp_button_style_1_textonly",\\
    "8": "cp_checkbox_style_1_textonly",\\
    "9": "cp_svg_style",\\
    "10": "cp_dropDown_style_1",\\
    "11": "cp_radiobutton_style_1_textonly",\\
    "12": "cp_inputField_style_1",\\
    "13": "cp_clickbox_style",\\
    "14": "cp_responsive_container_style",\\
    "15": "cp_default_shape_solid_style"\\
  },\\
  "color_palettes": [\\
    {\\
      "name": "Light Palette - 1",\\
      "colors": [\\
        "var(--color1)",\\
        "var(--color2)",\\
        "var(--color3)",\\
        "var(--color4)",\\
        "var(--color5)",\\
        "var(--color6)",\\
        "var(--color7)",\\
        "var(--color5_light)",\\
        "var(--color4_dark)"\\
      ]\\
    }\\
  ],\\
  "active_color_palette": 0\\
}',
other_presets:'{\\
  "cp_default_slide_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "type": 3,\\
      "category": 0\\
    },\\
    "backgroundColor": "var(--palette-color1)",\\
    "outlineColor": "var(--palette-color5)",\\
    "outlineWidth": 1,\\
    "outlineStyle": "solid",\\
    "outlineCap": "butt",\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color2)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 0,\\
            "y": 0\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color2)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_responsive_container_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 14,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color6)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": 1,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_correct": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--success)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_incorrect": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--error)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_incomplete": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--incomplete)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_hint": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--hint)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_retry": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--retry)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_timeout": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--timeout)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color6)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color1)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_linear_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_radial_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  }\\
}',
theme:'{\\
  "--primary": "#F1EEE6",\\
\\
  "--color1": "#FFFFFF",\\
  "--color2": "#F8F7F4",\\
  "--color3": "#F1EEE6",\\
  "--color4": "#D6D5D1",\\
  "--color5": "#666666",\\
  "--color6": "#333333",\\
  "--color7": "#020C1C",\\
  "--colorC7": "#F7F7F7",\\
  "--disabledC12": "#989898",\\
  "--color1_light": "#FFCD74",\\
  "--color1_dark": "#C76D12",\\
  "--color2_light": "#86FFFF",\\
  "--color2_dark": "#00ACCC",\\
  "--color3_light": "#9B5DFF",\\
  "--color3_dark": "#0000CA",\\
  "--color4_light": "#99FF99",\\
  "--color4_dark": "#112FA7",\\
  "--color5_light": "#163EE5",\\
  "--color5_dark": "#00CB92",\\
  "--color6_light": "#7697FF",\\
  "--color6_dark": "#0040CB",\\
  "--color7_light": "#FF8E64",\\
  "--color7_dark": "#C5230B",\\
\\
  "--success": "#558564",\\
  "--error": "#C83E4D",\\
  "--hint": "#CB6F10",\\
  "--incomplete":"#E8BD2B",\\
  "--timeout": "#C74545",\\
  "--retry": "#CB6F10",\\
  "--white": "#ffffff",\\
  "--black": "#000000",\\
\\
  "--greyscale1": "#FFFFFF",\\
  "--greyscale2": "#F1EEE61F",\\
  "--greyscale3": "#B3B3B3",\\
  "--greyscale4": "#4B4B4B",\\
  "--greyscale5": "#333333",\\
  "--disabled": "#818181",\\
\\
  "--palette-color0": "var(--color1)",\\
  "--palette-color1": "var(--color2)",\\
  "--palette-color2": "var(--color3)",\\
  "--palette-color3": "var(--color4)",\\
  "--palette-color4": "var(--color5)",\\
  "--palette-color5": "var(--color6)",\\
  "--palette-color6": "var(--color7)",\\
  "--palette-color7": "var(--color5_light)",\\
  "--palette-color8": "var(--color4_dark)",\\
\\
  "--design-option-color1": "255, 255, 255",\\
  "--design-option-color2": "248, 247, 244",\\
  "--design-option-color3": "241, 238, 230",\\
  "--design-option-color4": "214, 213, 209",\\
  "--design-option-color5": "102, 102, 102",\\
  "--design-option-color6": "51, 51, 51",\\
  "--design-option-color7": "2, 12, 28",\\
  "--design-option-color5_light": "22, 62, 229",\\
  "--design-option-color4_dark": "17, 47, 167",\\
\\
  "--c1": "var(--design-option-color1)",\\
  "--c2": "var(--design-option-color2)",\\
  "--c3": "var(--design-option-color3)",\\
  "--c4": "var(--design-option-color4)",\\
  "--c5": "var(--design-option-color5)",\\
  "--c6": "var(--design-option-color6)",\\
  "--c7": "var(--design-option-color7)",\\
  "--c8": "var(--design-option-color5_light)",\\
  "--c9": "var(--design-option-color4_dark)",\\
  \\
  "--widget-container--fillcolor": "var(--palette-color1)",\\
\\
  "--font1": "Georgia",\\
  "--font2": "Arial",\\
  "--text-style-unset": "none",\\
\\
  "--text-heading-1--fontSize--desktop": "120px",\\
  "--text-heading-1--fontSize--tablet": "100px",\\
  "--text-heading-1--fontSize--mobile": "80px",\\
  "--text-heading-1--fontFamily": "var(--font1)",\\
  "--text-heading-1--fontWeight": "normal",\\
  "--text-heading-1--fontType": "regular",\\
  "--text-heading-1--fontStyle": "normal",\\
  "--text-heading-1--fontStretch": "normal",\\
  "--text-heading-1--lineHeight": "1.07",\\
  "--text-heading-1--marginLeft": "0px",\\
  "--text-heading-1--color": "var(--palette-color6)",\\
  "--text-heading-1--borderBottomStyle": "none",\\
  "--text-heading-1--textDecoration": "none",\\
  "--text-heading-1--letterSpacing": "-0.01",\\
  "--text-heading-1--textTransform": "none",\\
  "--text-heading-1--stroke": "var(--palette-color2)",\\
  "--text-heading-1--textAlign": "left",\\
  "--text-heading-1--justifyContent": "flex-start",\\
  "--text-heading-1--marginTop": "auto",\\
  "--text-heading-1--marginBottom": "0",\\
  "--text-heading-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-2--fontSize--desktop": "80px",\\
  "--text-heading-2--fontSize--tablet": "72px",\\
  "--text-heading-2--fontSize--mobile": "60px",\\
  "--text-heading-2--fontFamily": "var(--font1)",\\
  "--text-heading-2--fontWeight": "normal",\\
  "--text-heading-2--fontType": "regular",\\
  "--text-heading-2--fontStyle": "normal",\\
  "--text-heading-2--fontStretch": "normal",\\
  "--text-heading-2--lineHeight": "1.1",\\
  "--text-heading-2--marginLeft": "0px",\\
  "--text-heading-2--color": "var(--palette-color6)",\\
  "--text-heading-2--borderBottomStyle": "none",\\
  "--text-heading-2--textDecoration": "none",\\
  "--text-heading-2--letterSpacing": "-0.04",\\
  "--text-heading-2--textTransform": "none",\\
  "--text-heading-2--stroke": "var(--palette-color2)",\\
  "--text-heading-2--textAlign": "left",\\
  "--text-heading-2--justifyContent": "flex-start",\\
  "--text-heading-2--marginTop": "auto",\\
  "--text-heading-2--marginBottom": "0",\\
  "--text-heading-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-3--fontSize--desktop": "60px",\\
  "--text-heading-3--fontSize--tablet": "52px",\\
  "--text-heading-3--fontSize--mobile": "44px",\\
  "--text-heading-3--fontFamily": "var(--font1)",\\
  "--text-heading-3--fontWeight": "normal",\\
  "--text-heading-3--fontType": "regular",\\
  "--text-heading-3--fontStyle": "normal",\\
  "--text-heading-3--fontStretch": "normal",\\
  "--text-heading-3--lineHeight": "1.1",\\
  "--text-heading-3--marginLeft": "0px",\\
  "--text-heading-3--color": "var(--palette-color6)",\\
  "--text-heading-3--borderBottomStyle": "none",\\
  "--text-heading-3--textDecoration": "none",\\
  "--text-heading-3--letterSpacing": "0.03",\\
  "--text-heading-3--textTransform": "none",\\
  "--text-heading-3--stroke": "var(--palette-color2)",\\
  "--text-heading-3--textAlign": "left",\\
  "--text-heading-3--justifyContent": "flex-start",\\
  "--text-heading-3--marginTop": "auto",\\
  "--text-heading-3--marginBottom": "0",\\
  "--text-heading-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-4--fontSize--desktop": "52px",\\
  "--text-heading-4--fontSize--tablet": "40px",\\
  "--text-heading-4--fontSize--mobile": "32px",\\
  "--text-heading-4--fontFamily": "var(--font1)",\\
  "--text-heading-4--fontWeight": "normal",\\
  "--text-heading-4--fontType": "regular",\\
  "--text-heading-4--fontStyle": "normal",\\
  "--text-heading-4--fontStretch": "normal",\\
  "--text-heading-4--lineHeight": "1.15",\\
  "--text-heading-4--marginLeft": "0px",\\
  "--text-heading-4--color": "var(--palette-color6)",\\
  "--text-heading-4--borderBottomStyle": "none",\\
  "--text-heading-4--textDecoration": "none",\\
  "--text-heading-4--letterSpacing": "0.10",\\
  "--text-heading-4--textTransform": "uppercase",\\
  "--text-heading-4--stroke": "var(--palette-color2)",\\
  "--text-heading-4--textAlign": "left",\\
  "--text-heading-4--justifyContent": "flex-start",\\
  "--text-heading-4--marginTop": "auto",\\
  "--text-heading-4--marginBottom": "0",\\
  "--text-heading-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-5--fontSize--desktop": "40px",\\
  "--text-heading-5--fontSize--tablet": "32px",\\
  "--text-heading-5--fontSize--mobile": "28px",\\
  "--text-heading-5--fontFamily": "var(--font1)",\\
  "--text-heading-5--fontWeight": "normal",\\
  "--text-heading-5--fontType": "regular",\\
  "--text-heading-5--fontStyle": "normal",\\
  "--text-heading-5--fontStretch": "normal",\\
  "--text-heading-5--lineHeight": "1.2",\\
  "--text-heading-5--marginLeft": "0px",\\
  "--text-heading-5--color": "var(--palette-color6)",\\
  "--text-heading-5--borderBottomStyle": "none",\\
  "--text-heading-5--textDecoration": "none",\\
  "--text-heading-5--letterSpacing": "0",\\
  "--text-heading-5--textTransform": "none",\\
  "--text-heading-5--stroke": "var(--palette-color2)",\\
  "--text-heading-5--textAlign": "left",\\
  "--text-heading-5--justifyContent": "flex-start",\\
  "--text-heading-5--marginTop": "auto",\\
  "--text-heading-5--marginBottom": "0",\\
  "--text-heading-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-6--fontSize--desktop": "36px",\\
  "--text-heading-6--fontSize--tablet": "28px",\\
  "--text-heading-6--fontSize--mobile": "24px",\\
  "--text-heading-6--fontFamily": "var(--font2)",\\
  "--text-heading-6--fontWeight": "normal",\\
  "--text-heading-6--fontType": "regular",\\
  "--text-heading-6--fontStyle": "normal",\\
  "--text-heading-6--fontStretch": "normal",\\
  "--text-heading-6--lineHeight": "1.2",\\
  "--text-heading-6--marginLeft": "0px",\\
  "--text-heading-6--color": "var(--palette-color6)",\\
  "--text-heading-6--borderBottomStyle": "none",\\
  "--text-heading-6--textDecoration": "none",\\
  "--text-heading-6--letterSpacing": "0",\\
  "--text-heading-6--textTransform": "none",\\
  "--text-heading-6--stroke": "var(--palette-color2)",\\
  "--text-heading-6--textAlign": "left",\\
  "--text-heading-6--justifyContent": "flex-start",\\
  "--text-heading-6--marginTop": "auto",\\
  "--text-heading-6--marginBottom": "0",\\
  "--text-heading-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-7--fontSize--desktop": "20px",\\
  "--text-heading-7--fontSize--tablet": "20px",\\
  "--text-heading-7--fontSize--mobile": "20px",\\
  "--text-heading-7--fontFamily": "var(--font1)",\\
  "--text-heading-7--fontWeight": "normal",\\
  "--text-heading-7--fontType": "regular",\\
  "--text-heading-7--fontStyle": "normal",\\
  "--text-heading-7--fontStretch": "normal",\\
  "--text-heading-7--lineHeight": "1.35",\\
  "--text-heading-7--marginLeft": "0px",\\
  "--text-heading-7--color": "var(--palette-color5)",\\
  "--text-heading-7--borderBottomStyle": "none",\\
  "--text-heading-7--textDecoration": "none",\\
  "--text-heading-7--letterSpacing": "0",\\
  "--text-heading-7--textTransform": "none",\\
  "--text-heading-7--stroke": "var(--palette-color2)",\\
  "--text-heading-7--textAlign": "left",\\
  "--text-heading-7--justifyContent": "flex-start",\\
  "--text-heading-7--marginTop": "auto",\\
  "--text-heading-7--marginBottom": "0",\\
  "--text-heading-7--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-7--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-7--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-7--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-8--fontSize--desktop": "72px",\\
  "--text-heading-8--fontSize--tablet": "48px",\\
  "--text-heading-8--fontSize--mobile": "32px",\\
  "--text-heading-8--fontFamily": "var(--font1)",\\
  "--text-heading-8--fontWeight": "normal",\\
  "--text-heading-8--fontType": "regular",\\
  "--text-heading-8--fontStyle": "normal",\\
  "--text-heading-8--fontStretch": "normal",\\
  "--text-heading-8--lineHeight": "1.35",\\
  "--text-heading-8--marginLeft": "0px",\\
  "--text-heading-8--color": "var(--palette-color5)",\\
  "--text-heading-8--borderBottomStyle": "none",\\
  "--text-heading-8--textDecoration": "none",\\
  "--text-heading-8--letterSpacing": "0",\\
  "--text-heading-8--textTransform": "none",\\
  "--text-heading-8--stroke": "var(--palette-color2)",\\
  "--text-heading-8--textAlign": "center",\\
  "--text-heading-8--justifyContent": "flex-start",\\
  "--text-heading-8--marginTop": "auto",\\
  "--text-heading-8--marginBottom": "0",\\
  "--text-heading-8--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-8--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-8--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-8--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-9--fontSize--desktop": "32px",\\
  "--text-heading-9--fontSize--tablet": "32px",\\
  "--text-heading-9--fontSize--mobile": "32px",\\
  "--text-heading-9--fontFamily": "var(--font1)",\\
  "--text-heading-9--fontWeight": "normal",\\
  "--text-heading-9--fontType": "regular",\\
  "--text-heading-9--fontStyle": "normal",\\
  "--text-heading-9--fontStretch": "normal",\\
  "--text-heading-9--lineHeight": "1.35",\\
  "--text-heading-9--marginLeft": "0px",\\
  "--text-heading-9--color": "var(--palette-color5)",\\
  "--text-heading-9--borderBottomStyle": "none",\\
  "--text-heading-9--textDecoration": "none",\\
  "--text-heading-9--letterSpacing": "0",\\
  "--text-heading-9--textTransform": "none",\\
  "--text-heading-9--stroke": "var(--palette-color2)",\\
  "--text-heading-9--textAlign": "center",\\
  "--text-heading-9--justifyContent": "flex-start",\\
  "--text-heading-9--marginTop": "auto",\\
  "--text-heading-9--marginBottom": "0",\\
  "--text-heading-9--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-9--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-9--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-9--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-1--fontSize--desktop": "22px",\\
  "--text-body-1--fontSize--tablet": "20px",\\
  "--text-body-1--fontSize--mobile": "18px",\\
  "--text-body-1--fontFamily": "var(--font1)",\\
  "--text-body-1--fontWeight": "normal",\\
  "--text-body-1--fontType": "regular",\\
  "--text-body-1--fontStyle": "normal",\\
  "--text-body-1--fontStretch": "normal",\\
  "--text-body-1--lineHeight": "1.3",\\
  "--text-body-1--marginLeft": "0px",\\
  "--text-body-1--color": "var(--palette-color5)",\\
  "--text-body-1--borderBottomStyle": "none",\\
  "--text-body-1--textDecoration": "none",\\
  "--text-body-1--letterSpacing": "0",\\
  "--text-body-1--textTransform": "none",\\
  "--text-body-1--stroke": "var(--palette-color2)",\\
  "--text-body-1--textAlign": "left",\\
  "--text-body-1--justifyContent": "flex-start",\\
  "--text-body-1--marginTop": "auto",\\
  "--text-body-1--marginBottom": "0",\\
  "--text-body-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-2--fontSize--desktop": "22px",\\
  "--text-body-2--fontSize--tablet": "20px",\\
  "--text-body-2--fontSize--mobile": "18px",\\
  "--text-body-2--fontFamily": "var(--font2)",\\
  "--text-body-2--fontWeight": "normal",\\
  "--text-body-2--fontType": "regular",\\
  "--text-body-2--fontStyle": "normal",\\
  "--text-body-2--fontStretch": "normal",\\
  "--text-body-2--lineHeight": "1.3",\\
  "--text-body-2--marginLeft": "0px",\\
  "--text-body-2--color": "var(--palette-color4)",\\
  "--text-body-2--borderBottomStyle": "none",\\
  "--text-body-2--textDecoration": "none",\\
  "--text-body-2--letterSpacing": "0.03",\\
  "--text-body-2--textTransform": "none",\\
  "--text-body-2--Stroke": "var(--palette-color2)",\\
  "--text-body-2--textAlign": "left",\\
  "--text-body-2--justifyContent": "flex-start",\\
  "--text-body-2--marginTop": "auto",\\
  "--text-body-2--marginBottom": "0",\\
  "--text-body-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-3--fontSize--desktop": "18px",\\
  "--text-body-3--fontSize--tablet": "16px",\\
  "--text-body-3--fontSize--mobile": "16px",\\
  "--text-body-3--fontFamily": "var(--font1)",\\
  "--text-body-3--fontWeight": "normal",\\
  "--text-body-3--fontType": "regular",\\
  "--text-body-3--fontStyle": "normal",\\
  "--text-body-3--fontStretch": "normal",\\
  "--text-body-3--lineHeight": "1.35",\\
  "--text-body-3--marginLeft": "0px",\\
  "--text-body-3--color": "var(--palette-color4)",\\
  "--text-body-3--borderBottomStyle": "none",\\
  "--text-body-3--textDecoration": "none",\\
  "--text-body-3--letterSpacing": "0",\\
  "--text-body-3--textTransform": "none",\\
  "--text-body-3--Stroke": "var(--palette-color2)",\\
  "--text-body-3--textAlign": "left",\\
  "--text-body-3--justifyContent": "flex-start",\\
  "--text-body-3--marginTop": "auto",\\
  "--text-body-3--marginBottom": "0",\\
  "--text-body-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-4--fontSize--desktop": "18px",\\
  "--text-body-4--fontSize--tablet": "16px",\\
  "--text-body-4--fontSize--mobile": "16px",\\
  "--text-body-4--fontFamily": "var(--font2)",\\
  "--text-body-4--fontWeight": "normal",\\
  "--text-body-4--fontType": "regular",\\
  "--text-body-4--fontStyle": "normal",\\
  "--text-body-4--fontStretch": "normal",\\
  "--text-body-4--lineHeight": "1.35",\\
  "--text-body-4--marginLeft": "0px",\\
  "--text-body-4--color": "var(--palette-color4)",\\
  "--text-body-4--borderBottomStyle": "none",\\
  "--text-body-4--textDecoration": "none",\\
  "--text-body-4--letterSpacing": "0",\\
  "--text-body-4--textTransform": "none",\\
  "--text-body-4--Stroke": "var(--palette-color2)",\\
  "--text-body-4--textAlign": "left",\\
  "--text-body-4--justifyContent": "flex-start",\\
  "--text-body-4--marginTop": "auto",\\
  "--text-body-4--marginBottom": "0",\\
  "--text-body-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-5--fontSize--desktop": "18px",\\
  "--text-body-5--fontSize--tablet": "16px",\\
  "--text-body-5--fontSize--mobile": "16px",\\
  "--text-body-5--fontFamily": "var(--font1)",\\
  "--text-body-5--fontWeight": "normal",\\
  "--text-body-5--fontType": "italic",\\
  "--text-body-5--fontStyle": "normal",\\
  "--text-body-5--fontStretch": "normal",\\
  "--text-body-5--lineHeight": "1.35",\\
  "--text-body-5--marginLeft": "0px",\\
  "--text-body-5--color": "var(--palette-color4)",\\
  "--text-body-5--borderBottomStyle": "none",\\
  "--text-body-5--textDecoration": "none",\\
  "--text-body-5--letterSpacing": "0",\\
  "--text-body-5--textTransform": "none",\\
  "--text-body-5--Stroke": "var(--palette-color2)",\\
  "--text-body-5--textAlign": "center",\\
  "--text-body-5--justifyContent": "flex-start",\\
  "--text-body-5--marginTop": "auto",\\
  "--text-body-5--marginBottom": "0",\\
  "--text-body-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-6--fontSize--desktop": "16px",\\
  "--text-body-6--fontSize--tablet": "14px",\\
  "--text-body-6--fontSize--mobile": "14px",\\
  "--text-body-6--fontFamily": "var(--font2)",\\
  "--text-body-6--fontWeight": "normal",\\
  "--text-body-6--fontType": "regular",\\
  "--text-body-6--fontStyle": "normal",\\
  "--text-body-6--fontStretch": "normal",\\
  "--text-body-6--lineHeight": "1.35",\\
  "--text-body-6--marginLeft": "0px",\\
  "--text-body-6--color": "var(--palette-color4)",\\
  "--text-body-6--borderBottomStyle": "none",\\
  "--text-body-6--textDecoration": "none",\\
  "--text-body-6--letterSpacing": "0",\\
  "--text-body-6--textTransform": "none",\\
  "--text-body-6--Stroke": "var(--palette-color2)",\\
  "--text-body-6--textAlign": "left",\\
  "--text-body-6--justifyContent": "flex-start",\\
  "--text-body-6--marginTop": "auto",\\
  "--text-body-6--marginBottom": "0",\\
  "--text-body-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-1--fontSize--desktop": "22px",\\
  "--text-component-1--fontSize--tablet": "20px",\\
  "--text-component-1--fontSize--mobile": "20px",\\
  "--text-component-1--fontFamily": "var(--font1)",\\
  "--text-component-1--fontWeight": "normal",\\
  "--text-component-1--fontType": "regular",\\
  "--text-component-1--fontStyle": "normal",\\
  "--text-component-1--fontStretch": "normal",\\
  "--text-component-1--lineHeight": "1.35",\\
  "--text-component-1--marginLeft": "0px",\\
  "--text-component-1--color": "var(--color6)",\\
  "--text-component-1--borderBottomStyle": "none",\\
  "--text-component-1--textDecoration": "none",\\
  "--text-component-1--letterSpacing": "0",\\
  "--text-component-1--textTransform": "none",\\
  "--text-component-1--stroke": "var(--palette-color2)",\\
  "--text-component-1--textAlign": "left",\\
  "--text-component-1--justifyContent": "flex-start",\\
  "--text-component-1--marginTop": "auto",\\
  "--text-component-1--marginBottom": "0",\\
  "--text-component-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-2--fontSize--desktop": "24px",\\
  "--text-component-2--fontSize--tablet": "20px",\\
  "--text-component-2--fontSize--mobile": "20px",\\
  "--text-component-2--fontFamily": "var(--font1)",\\
  "--text-component-2--fontWeight": "normal",\\
  "--text-component-2--fontType": "regular",\\
  "--text-component-2--fontStyle": "normal",\\
  "--text-component-2--fontStretch": "normal",\\
  "--text-component-2--lineHeight": "1.35",\\
  "--text-component-2--marginLeft": "0px",\\
  "--text-component-2--color": "var(--palette-color1)",\\
  "--text-component-2--borderBottomStyle": "none",\\
  "--text-component-2--textDecoration": "none",\\
  "--text-component-2--letterSpacing": "0.16",\\
  "--text-component-2--textTransform": "none",\\
  "--text-component-2--stroke": "var(--palette-color2)",\\
  "--text-component-2--textAlign": "left",\\
  "--text-component-2--justifyContent": "flex-start",\\
  "--text-component-2--marginTop": "auto",\\
  "--text-component-2--marginBottom": "0",\\
  "--text-component-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-3--fontSize--desktop": "14px",\\
  "--text-component-3--fontSize--tablet": "14px",\\
  "--text-component-3--fontSize--mobile": "14px",\\
  "--text-component-3--fontFamily": "var(--font1)",\\
  "--text-component-3--fontWeight": "normal",\\
  "--text-component-3--fontType": "regular",\\
  "--text-component-3--fontStyle": "normal",\\
  "--text-component-3--fontStretch": "normal",\\
  "--text-component-3--lineHeight": "1.35",\\
  "--text-component-3--marginLeft": "0px",\\
  "--text-component-3--color": "var(--palette-color6)",\\
  "--text-component-3--borderBottomStyle": "none",\\
  "--text-component-3--textDecoration": "none",\\
  "--text-component-3--letterSpacing": "0.2",\\
  "--text-component-3--textTransform": "uppercase",\\
  "--text-component-3--stroke": "var(--palette-color2)",\\
  "--text-component-3--textAlign": "center",\\
  "--text-component-3--justifyContent": "flex-start",\\
  "--text-component-3--marginTop": "auto",\\
  "--text-component-3--marginBottom": "0",\\
  "--text-component-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-4--fontSize--desktop": "22px",\\
  "--text-component-4--fontSize--tablet": "20px",\\
  "--text-component-4--fontSize--mobile": "20px",\\
  "--text-component-4--fontFamily": "var(--font1)",\\
  "--text-component-4--fontWeight": "normal",\\
  "--text-component-4--fontType": "regular",\\
  "--text-component-4--fontStyle": "normal",\\
  "--text-component-4--fontStretch": "normal",\\
  "--text-component-4--lineHeight": "1.35",\\
  "--text-component-4--marginLeft": "0px",\\
  "--text-component-4--color": "var(--color6)",\\
  "--text-component-4--borderBottomStyle": "none",\\
  "--text-component-4--textDecoration": "none",\\
  "--text-component-4--letterSpacing": "0.02",\\
  "--text-component-4--textTransform": "none",\\
  "--text-component-4--stroke": "var(--palette-color2)",\\
  "--text-component-4--textAlign": "left",\\
  "--text-component-4--justifyContent": "flex-start",\\
  "--text-component-4--marginTop": "auto",\\
  "--text-component-4--marginBottom": "0",\\
  "--text-component-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-1--fontSize--desktop": "36px",\\
  "--text-subheading-1--fontSize--tablet": "32px",\\
  "--text-subheading-1--fontSize--mobile": "28px",\\
  "--text-subheading-1--fontFamily": "var(--font2)",\\
  "--text-subheading-1--fontWeight": "normal",\\
  "--text-subheading-1--fontType": "regular",\\
  "--text-subheading-1--fontStyle": "normal",\\
  "--text-subheading-1--fontStretch": "normal",\\
  "--text-subheading-1--lineHeight": "1.1",\\
  "--text-subheading-1--marginLeft": "0px",\\
  "--text-subheading-1--color": "var(--palette-color6)",\\
  "--text-subheading-1--borderBottomStyle": "none",\\
  "--text-subheading-1--textDecoration": "none",\\
  "--text-subheading-1--letterSpacing": "0.05",\\
  "--text-subheading-1--textTransform": "uppercase",\\
  "--text-subheading-1--stroke": "var(--palette-color2)",\\
  "--text-subheading-1--textAlign": "left",\\
  "--text-subheading-1--justifyContent": "flex-start",\\
  "--text-subheading-1--marginTop": "auto",\\
  "--text-subheading-1--marginBottom": "0",\\
  "--text-subheading-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-2--fontSize--desktop": "28px",\\
  "--text-subheading-2--fontSize--tablet": "24px",\\
  "--text-subheading-2--fontSize--mobile": "20px",\\
  "--text-subheading-2--fontFamily": "var(--font2)",\\
  "--text-subheading-2--fontWeight": "normal",\\
  "--text-subheading-2--fontType": "bold",\\
  "--text-subheading-2--fontStyle": "normal",\\
  "--text-subheading-2--fontStretch": "normal",\\
  "--text-subheading-2--lineHeight": "1.15",\\
  "--text-subheading-2--marginLeft": "0px",\\
  "--text-subheading-2--color": "var(--palette-color6)",\\
  "--text-subheading-2--borderBottomStyle": "none",\\
  "--text-subheading-2--textDecoration": "none",\\
  "--text-subheading-2--letterSpacing": "0.05",\\
  "--text-subheading-2--textTransform": "none",\\
  "--text-subheading-2--stroke": "var(--palette-color2)",\\
  "--text-subheading-2--textAlign": "left",\\
  "--text-subheading-2--justifyContent": "flex-start",\\
  "--text-subheading-2--marginTop": "auto",\\
  "--text-subheading-2--marginBottom": "0",\\
  "--text-subheading-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-3--fontSize--desktop": "26px",\\
  "--text-subheading-3--fontSize--tablet": "22px",\\
  "--text-subheading-3--fontSize--mobile": "18px",\\
  "--text-subheading-3--fontFamily": "var(--font2)",\\
  "--text-subheading-3--fontWeight": "normal",\\
  "--text-subheading-3--fontType": "regular",\\
  "--text-subheading-3--fontStyle": "normal",\\
  "--text-subheading-3--fontStretch": "normal",\\
  "--text-subheading-3--lineHeight": "1.15",\\
  "--text-subheading-3--marginLeft": "0px",\\
  "--text-subheading-3--color": "var(--palette-color6)",\\
  "--text-subheading-3--borderBottomStyle": "none",\\
  "--text-subheading-3--textDecoration": "none",\\
  "--text-subheading-3--letterSpacing": "0",\\
  "--text-subheading-3--textTransform": "none",\\
  "--text-subheading-3--stroke": "var(--palette-color2)",\\
  "--text-subheading-3--textAlign": "center",\\
  "--text-subheading-3--justifyContent": "flex-start",\\
  "--text-subheading-3--marginTop": "auto",\\
  "--text-subheading-3--marginBottom": "0",\\
  "--text-subheading-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-4--fontSize--desktop": "24px",\\
  "--text-subheading-4--fontSize--tablet": "20px",\\
  "--text-subheading-4--fontSize--mobile": "16px",\\
  "--text-subheading-4--fontFamily": "var(--font2)",\\
  "--text-subheading-4--fontWeight": "normal",\\
  "--text-subheading-4--fontType": "bold",\\
  "--text-subheading-4--fontStyle": "normal",\\
  "--text-subheading-4--fontStretch": "normal",\\
  "--text-subheading-4--lineHeight": "1.15",\\
  "--text-subheading-4--marginLeft": "0px",\\
  "--text-subheading-4--color": "var(--palette-color0)",\\
  "--text-subheading-4--borderBottomStyle": "none",\\
  "--text-subheading-4--textDecoration": "none",\\
  "--text-subheading-4--letterSpacing": "0.05",\\
  "--text-subheading-4--textTransform": "none",\\
  "--text-subheading-4--stroke": "var(--palette-color2)",\\
  "--text-subheading-4--textAlign": "left",\\
  "--text-subheading-4--justifyContent": "flex-start",\\
  "--text-subheading-4--marginTop": "auto",\\
  "--text-subheading-4--marginBottom": "0",\\
  "--text-subheading-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-5--fontSize--desktop": "24px",\\
  "--text-subheading-5--fontSize--tablet": "20px",\\
  "--text-subheading-5--fontSize--mobile": "16px",\\
  "--text-subheading-5--fontFamily": "var(--font1)",\\
  "--text-subheading-5--fontWeight": "normal",\\
  "--text-subheading-5--fontType": "bold",\\
  "--text-subheading-5--fontStyle": "normal",\\
  "--text-subheading-5--fontStretch": "normal",\\
  "--text-subheading-5--lineHeight": "1.15",\\
  "--text-subheading-5--marginLeft": "0px",\\
  "--text-subheading-5--color": "var(--palette-color5)",\\
  "--text-subheading-5--borderBottomStyle": "none",\\
  "--text-subheading-5--textDecoration": "none",\\
  "--text-subheading-5--letterSpacing": "-0.05",\\
  "--text-subheading-5--textTransform": "none",\\
  "--text-subheading-5--stroke": "var(--palette-color2)",\\
  "--text-subheading-5--textAlign": "left",\\
  "--text-subheading-5--justifyContent": "flex-start",\\
  "--text-subheading-5--marginTop": "auto",\\
  "--text-subheading-5--marginBottom": "0",\\
  "--text-subheading-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-6--fontSize--desktop": "18px",\\
  "--text-subheading-6--fontSize--tablet": "16px",\\
  "--text-subheading-6--fontSize--mobile": "14px",\\
  "--text-subheading-6--fontFamily": "var(--font2)",\\
  "--text-subheading-6--fontWeight": "normal",\\
  "--text-subheading-6--fontType": "bold",\\
  "--text-subheading-6--fontStyle": "normal",\\
  "--text-subheading-6--fontStretch": "normal",\\
  "--text-subheading-6--lineHeight": "1.25",\\
  "--text-subheading-6--marginLeft": "0px",\\
  "--text-subheading-6--color": "var(--palette-color5)",\\
  "--text-subheading-6--borderBottomStyle": "none",\\
  "--text-subheading-6--textDecoration": "none",\\
  "--text-subheading-6--letterSpacing": "0",\\
  "--text-subheading-6--textTransform": "none",\\
  "--text-subheading-6--stroke": "var(--palette-color2)",\\
  "--text-subheading-6--textAlign": "left",\\
  "--text-subheading-6--justifyContent": "flex-start",\\
  "--text-subheading-6--marginTop": "auto",\\
  "--text-subheading-6--marginBottom": "0",\\
  "--text-subheading-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-1--fontSize--desktop": "20px",\\
  "--text-detail-1--fontSize--tablet": "18px",\\
  "--text-detail-1--fontSize--mobile": "16px",\\
  "--text-detail-1--fontFamily": "var(--font2)",\\
  "--text-detail-1--fontWeight": "normal",\\
  "--text-detail-1--fontType": "regular",\\
  "--text-detail-1--fontStyle": "normal",\\
  "--text-detail-1--fontStretch": "normal",\\
  "--text-detail-1--lineHeight": "1.2",\\
  "--text-detail-1--marginLeft": "0px",\\
  "--text-detail-1--color": "var(--palette-color6)",\\
  "--text-detail-1--borderBottomStyle": "none",\\
  "--text-detail-1--textDecoration": "none",\\
  "--text-detail-1--letterSpacing": "0",\\
  "--text-detail-1--textTransform": "uppercase",\\
  "--text-detail-1--stroke": "var(--palette-color5)",\\
  "--text-detail-1--textAlign": "left",\\
  "--text-detail-1--justifyContent": "flex-start",\\
  "--text-detail-1--marginTop": "auto",\\
  "--text-detail-1--marginBottom": "0",\\
  "--text-detail-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-2--fontSize--desktop": "16px",\\
  "--text-detail-2--fontSize--tablet": "14px",\\
  "--text-detail-2--fontSize--mobile": "12px",\\
  "--text-detail-2--fontFamily": "var(--font2)",\\
  "--text-detail-2--fontWeight": "normal",\\
  "--text-detail-2--fontType": "bold",\\
  "--text-detail-2--fontStyle": "normal",\\
  "--text-detail-2--fontStretch": "normal",\\
  "--text-detail-2--lineHeight": "1.3",\\
  "--text-detail-2--marginLeft": "0px",\\
  "--text-detail-2--color": "var(--palette-color6)",\\
  "--text-detail-2--borderBottomStyle": "none",\\
  "--text-detail-2--textDecoration": "none",\\
  "--text-detail-2--letterSpacing": "0",\\
  "--text-detail-2--textTransform": "uppercase",\\
  "--text-detail-2--stroke": "var(--palette-color2)",\\
  "--text-detail-2--textAlign": "left",\\
  "--text-detail-2--justifyContent": "flex-start",\\
  "--text-detail-2--marginTop": "auto",\\
  "--text-detail-2--marginBottom": "0",\\
  "--text-detail-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-3--fontSize--desktop": "16px",\\
  "--text-detail-3--fontSize--tablet": "14px",\\
  "--text-detail-3--fontSize--mobile": "12px",\\
  "--text-detail-3--fontFamily": "var(--font2)",\\
  "--text-detail-3--fontWeight": "normal",\\
  "--text-detail-3--fontType": "regular",\\
  "--text-detail-3--fontStyle": "normal",\\
  "--text-detail-3--fontStretch": "normal",\\
  "--text-detail-3--lineHeight": "1.35",\\
  "--text-detail-3--marginLeft": "0px",\\
  "--text-detail-3--color": "var(--palette-color4)",\\
  "--text-detail-3--borderBottomStyle": "none",\\
  "--text-detail-3--textDecoration": "none",\\
  "--text-detail-3--letterSpacing": "0.2",\\
  "--text-detail-3--textTransform": "uppercase",\\
  "--text-detail-3--stroke": "var(--palette-color2)",\\
  "--text-detail-3--textAlign": "left",\\
  "--text-detail-3--justifyContent": "flex-start",\\
  "--text-detail-3--marginTop": "auto",\\
  "--text-detail-3--marginBottom": "0",\\
  "--text-detail-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-4--fontSize--desktop": "22px",\\
  "--text-detail-4--fontSize--tablet": "20px",\\
  "--text-detail-4--fontSize--mobile": "20px",\\
  "--text-detail-4--fontFamily": "var(--font1)",\\
  "--text-detail-4--fontWeight": "normal",\\
  "--text-detail-4--fontType": "regular",\\
  "--text-detail-4--fontStyle": "normal",\\
  "--text-detail-4--fontStretch": "normal",\\
  "--text-detail-4--lineHeight": "1.35",\\
  "--text-detail-4--marginLeft": "0px",\\
  "--text-detail-4--color": "var(--palette-color5)",\\
  "--text-detail-4--borderBottomStyle": "none",\\
  "--text-detail-4--textDecoration": "none",\\
  "--text-detail-4--letterSpacing": "0",\\
  "--text-detail-4--textTransform": "none",\\
  "--text-detail-4--stroke": "var(--palette-color2)",\\
  "--text-detail-4--textAlign": "center",\\
  "--text-detail-4--justifyContent": "flex-start",\\
  "--text-detail-4--marginTop": "auto",\\
  "--text-detail-4--marginBottom": "0",\\
  "--text-detail-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-1--fontSize--desktop": "36px",\\
  "--text-variable-1--fontSize--tablet": "32px",\\
  "--text-variable-1--fontSize--mobile": "30px",\\
  "--text-variable-1--fontFamily": "var(--font2)",\\
  "--text-variable-1--fontWeight": "normal",\\
  "--text-variable-1--fontType": "bold",\\
  "--text-variable-1--fontStyle": "normal",\\
  "--text-variable-1--fontStretch": "normal",\\
  "--text-variable-1--lineHeight": "1.2",\\
  "--text-variable-1--marginLeft": "0px",\\
  "--text-variable-1--color": "var(--palette-color7)",\\
  "--text-variable-1--borderBottomStyle": "none",\\
  "--text-variable-1--textDecoration": "none",\\
  "--text-variable-1--letterSpacing": "0.02",\\
  "--text-variable-1--textTransform": "none",\\
  "--text-variable-1--stroke": "var(--palette-color2)",\\
  "--text-variable-1--textAlign": "left",\\
  "--text-variable-1--justifyContent": "flex-start",\\
  "--text-variable-1--marginTop": "auto",\\
  "--text-variable-1--marginBottom": "0",\\
  "--text-variable-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-2--fontSize--desktop": "24px",\\
  "--text-variable-2--fontSize--tablet": "22px",\\
  "--text-variable-2--fontSize--mobile": "20px",\\
  "--text-variable-2--fontFamily": "var(--font2)",\\
  "--text-variable-2--fontWeight": "normal",\\
  "--text-variable-2--fontType": "bold",\\
  "--text-variable-2--fontStyle": "normal",\\
  "--text-variable-2--fontStretch": "normal",\\
  "--text-variable-2--lineHeight": "1.15",\\
  "--text-variable-2--marginLeft": "0px",\\
  "--text-variable-2--color": "var(--palette-color6)",\\
  "--text-variable-2--borderBottomStyle": "none",\\
  "--text-variable-2--textDecoration": "none",\\
  "--text-variable-2--letterSpacing": "0",\\
  "--text-variable-2--textTransform": "none",\\
  "--text-variable-2--stroke": "var(--palette-color2)",\\
  "--text-variable-2--textAlign": "left",\\
  "--text-variable-2--justifyContent": "flex-start",\\
  "--text-variable-2--marginTop": "auto",\\
  "--text-variable-2--marginBottom": "0",\\
  "--text-variable-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-3--fontSize--desktop": "20px",\\
  "--text-variable-3--fontSize--tablet": "18px",\\
  "--text-variable-3--fontSize--mobile": "16px",\\
  "--text-variable-3--fontFamily": "var(--font1)",\\
  "--text-variable-3--fontWeight": "normal",\\
  "--text-variable-3--fontType": "bold",\\
  "--text-variable-3--fontStyle": "normal",\\
  "--text-variable-3--fontStretch": "normal",\\
  "--text-variable-3--lineHeight": "1.2",\\
  "--text-variable-3--marginLeft": "0px",\\
  "--text-variable-3--color": "var(--palette-color6)",\\
  "--text-variable-3--borderBottomStyle": "none",\\
  "--text-variable-3--textDecoration": "none",\\
  "--text-variable-3--letterSpacing": "0",\\
  "--text-variable-3--textTransform": "none",\\
  "--text-variable-3--stroke": "var(--palette-color2)",\\
  "--text-variable-3--textAlign": "left",\\
  "--text-variable-3--justifyContent": "flex-start",\\
  "--text-variable-3--marginTop": "auto",\\
  "--text-variable-3--marginBottom": "0",\\
  "--text-variable-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-4--fontSize--desktop": "16px",\\
  "--text-variable-4--fontSize--tablet": "14px",\\
  "--text-variable-4--fontSize--mobile": "12px",\\
  "--text-variable-4--fontFamily": "var(--font2)",\\
  "--text-variable-4--fontWeight": "normal",\\
  "--text-variable-4--fontType": "bold",\\
  "--text-variable-4--fontStyle": "normal",\\
  "--text-variable-4--fontStretch": "normal",\\
  "--text-variable-4--lineHeight": "1.3",\\
  "--text-variable-4--marginLeft": "0px",\\
  "--text-variable-4--color": "var(--palette-color6)",\\
  "--text-variable-4--borderBottomStyle": "none",\\
  "--text-variable-4--textDecoration": "none",\\
  "--text-variable-4--letterSpacing": "0.02",\\
  "--text-variable-4--textTransform": "none",\\
  "--text-variable-4--stroke": "var(--palette-color2)",\\
  "--text-variable-4--textAlign": "left",\\
  "--text-variable-4--justifyContent": "flex-start",\\
  "--text-variable-4--marginTop": "auto",\\
  "--text-variable-4--marginBottom": "0",\\
  "--text-variable-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-question-1--fontSize--desktop": "48px",\\
  "--text-question-1--fontSize--tablet": "20px",\\
  "--text-question-1--fontSize--mobile": "20px",\\
  "--text-question-1--fontFamily": "var(--font1)",\\
  "--text-question-1--fontWeight": "normal",\\
  "--text-question-1--fontType": "regular",\\
  "--text-question-1--fontStyle": "normal",\\
  "--text-question-1--fontStretch": "normal",\\
  "--text-question-1--lineHeight": "1.35",\\
  "--text-question-1--marginLeft": "0px",\\
  "--text-question-1--color": "var(--palette-color5)",\\
  "--text-question-1--borderBottomStyle": "none",\\
  "--text-question-1--textDecoration": "none",\\
  "--text-question-1--letterSpacing": "0",\\
  "--text-question-1--textTransform": "none",\\
  "--text-question-1--stroke": "var(--palette-color2)",\\
  "--text-question-1--textAlign": "left",\\
  "--text-question-1--justifyContent": "flex-start",\\
  "--text-question-1--marginTop": "auto",\\
  "--text-question-1--marginBottom": "0",\\
  "--text-question-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-question-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-question-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-question-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-question-2--fontSize--desktop": "24px",\\
  "--text-question-2--fontSize--tablet": "20px",\\
  "--text-question-2--fontSize--mobile": "20px",\\
  "--text-question-2--fontFamily": "var(--font1)",\\
  "--text-question-2--fontWeight": "normal",\\
  "--text-question-2--fontType": "bold",\\
  "--text-question-2--fontStyle": "normal",\\
  "--text-question-2--fontStretch": "normal",\\
  "--text-question-2--lineHeight": "1.35",\\
  "--text-question-2--marginLeft": "0px",\\
  "--text-question-2--color": "var(--palette-color5)",\\
  "--text-question-2--borderBottomStyle": "none",\\
  "--text-question-2--textDecoration": "none",\\
  "--text-question-2--letterSpacing": "0",\\
  "--text-question-2--textTransform": "none",\\
  "--text-question-2--stroke": "var(--palette-color2)",\\
  "--text-question-2--textAlign": "left",\\
  "--text-question-2--justifyContent": "flex-start",\\
  "--text-question-2--marginTop": "auto",\\
  "--text-question-2--marginBottom": "0",\\
  "--text-question-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-question-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-question-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-question-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-1--fontSize--desktop": "16px",\\
  "--text-button-1--fontSize--tablet": "16px",\\
  "--text-button-1--fontSize--mobile": "16px",\\
  "--text-button-1--fontFamily": "var(--font2)",\\
  "--text-button-1--fontWeight": "normal",\\
  "--text-button-1--fontType": "regular",\\
  "--text-button-1--fontStyle": "normal",\\
  "--text-button-1--fontStretch": "normal",\\
  "--text-button-1--lineHeight": "1.25",\\
  "--text-button-1--marginLeft": "0px",\\
  "--text-button-1--color": "var(--palette-color7)",\\
  "--text-button-1--borderBottomStyle": "none",\\
  "--text-button-1--textDecoration": "none",\\
  "--text-button-1--letterSpacing": "0.12",\\
  "--text-button-1--textTransform": "uppercase",\\
  "--text-button-1--stroke": "var(--palette-color2)",\\
  "--text-button-1--textAlign": "center",\\
  "--text-button-1--justifyContent": "flex-start",\\
  "--text-button-1--marginTop": "auto",\\
  "--text-button-1--marginBottom": "0",\\
  "--text-button-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-2--fontSize--desktop": "16px",\\
  "--text-button-2--fontSize--tablet": "16px",\\
  "--text-button-2--fontSize--mobile": "16px",\\
  "--text-button-2--fontFamily": "var(--font2)",\\
  "--text-button-2--fontWeight": "normal",\\
  "--text-button-2--fontType": "regular",\\
  "--text-button-2--fontStyle": "normal",\\
  "--text-button-2--fontStretch": "normal",\\
  "--text-button-2--lineHeight": "1.25",\\
  "--text-button-2--marginLeft": "0px",\\
  "--text-button-2--color": "var(--palette-color0)",\\
  "--text-button-2--borderBottomStyle": "none",\\
  "--text-button-2--textDecoration": "none",\\
  "--text-button-2--letterSpacing": "0.12",\\
  "--text-button-2--textTransform": "uppercase",\\
  "--text-button-2--stroke": "var(--palette-color2)",\\
  "--text-button-2--textAlign": "center",\\
  "--text-button-2--justifyContent": "flex-start",\\
  "--text-button-2--marginTop": "auto",\\
  "--text-button-2--marginBottom": "0",\\
  "--text-button-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-3--fontSize--desktop": "16px",\\
  "--text-button-3--fontSize--tablet": "16px",\\
  "--text-button-3--fontSize--mobile": "16px",\\
  "--text-button-3--fontFamily": "var(--font2)",\\
  "--text-button-3--fontWeight": "normal",\\
  "--text-button-3--fontType": "regular",\\
  "--text-button-3--fontStyle": "normal",\\
  "--text-button-3--fontStretch": "normal",\\
  "--text-button-3--lineHeight": "1.25",\\
  "--text-button-3--marginLeft": "0px",\\
  "--text-button-3--color": "var(--palette-color5)",\\
  "--text-button-3--borderBottomStyle": "none",\\
  "--text-button-3--textDecoration": "none",\\
  "--text-button-3--letterSpacing": "0.12",\\
  "--text-button-3--textTransform": "uppercase",\\
  "--text-button-3--stroke": "var(--palette-color2)",\\
  "--text-button-3--textAlign": "center",\\
  "--text-button-3--justifyContent": "flex-start",\\
  "--text-button-3--marginTop": "auto",\\
  "--text-button-3--marginBottom": "0",\\
  "--text-button-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-4--fontSize--desktop": "16px",\\
  "--text-button-4--fontSize--tablet": "16px",\\
  "--text-button-4--fontSize--mobile": "16px",\\
  "--text-button-4--fontFamily": "var(--font2)",\\
  "--text-button-4--fontWeight": "normal",\\
  "--text-button-4--fontType": "regular",\\
  "--text-button-4--fontStyle": "normal",\\
  "--text-button-4--fontStretch": "normal",\\
  "--text-button-4--lineHeight": "1.25",\\
  "--text-button-4--marginLeft": "0px",\\
  "--text-button-4--color": "var(--palette-color4)",\\
  "--text-button-4--borderBottomStyle": "none",\\
  "--text-button-4--textDecoration": "none",\\
  "--text-button-4--letterSpacing": "0.12",\\
  "--text-button-4--textTransform": "uppercase",\\
  "--text-button-4--stroke": "var(--palette-color2)",\\
  "--text-button-4--textAlign": "center",\\
  "--text-button-4--justifyContent": "flex-start",\\
  "--text-button-4--marginTop": "auto",\\
  "--text-button-4--marginBottom": "0",\\
  "--text-button-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-1--fontSize--desktop": "18px",\\
  "--text-uic-1--fontSize--tablet": "18px",\\
  "--text-uic-1--fontSize--mobile": "18px",\\
  "--text-uic-1--fontFamily": "var(--font1)",\\
  "--text-uic-1--fontWeight": "normal",\\
  "--text-uic-1--fontType": "italic",\\
  "--text-uic-1--fontStyle": "normal",\\
  "--text-uic-1--fontStretch": "normal",\\
  "--text-uic-1--lineHeight": "1.35",\\
  "--text-uic-1--marginLeft": "0px",\\
  "--text-uic-1--color": "var(--palette-color4)",\\
  "--text-uic-1--borderBottomStyle": "none",\\
  "--text-uic-1--textDecoration": "none",\\
  "--text-uic-1--letterSpacing": "0",\\
  "--text-uic-1--textTransform": "none",\\
  "--text-uic-1--stroke": "var(--palette-color2)",\\
  "--text-uic-1--textAlign": "left",\\
  "--text-uic-1--justifyContent": "flex-start",\\
  "--text-uic-1--marginTop": "auto",\\
  "--text-uic-1--marginBottom": "0",\\
  "--text-uic-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-2--fontSize--desktop": "18px",\\
  "--text-uic-2--fontSize--tablet": "18px",\\
  "--text-uic-2--fontSize--mobile": "18px",\\
  "--text-uic-2--fontFamily": "var(--font1)",\\
  "--text-uic-2--fontWeight": "normal",\\
  "--text-uic-2--fontType": "italic",\\
  "--text-uic-2--fontStyle": "normal",\\
  "--text-uic-2--fontStretch": "normal",\\
  "--text-uic-2--lineHeight": "1.35",\\
  "--text-uic-2--marginLeft": "0px",\\
  "--text-uic-2--color": "var(--palette-color1)",\\
  "--text-uic-2--borderBottomStyle": "none",\\
  "--text-uic-2--textDecoration": "none",\\
  "--text-uic-2--letterSpacing": "0",\\
  "--text-uic-2--textTransform": "none",\\
  "--text-uic-2--stroke": "var(--palette-color2)",\\
  "--text-uic-2--textAlign": "left",\\
  "--text-uic-2--justifyContent": "flex-start",\\
  "--text-uic-2--marginTop": "auto",\\
  "--text-uic-2--marginBottom": "0",\\
  "--text-uic-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-3--fontSize--desktop": "22px",\\
  "--text-uic-3--fontSize--tablet": "22px",\\
  "--text-uic-3--fontSize--mobile": "22px",\\
  "--text-uic-3--fontFamily": "var(--font1)",\\
  "--text-uic-3--fontWeight": "normal",\\
  "--text-uic-3--fontType": "regular",\\
  "--text-uic-3--fontStyle": "normal",\\
  "--text-uic-3--fontStretch": "normal",\\
  "--text-uic-3--lineHeight": "1.25",\\
  "--text-uic-3--marginLeft": "0px",\\
  "--text-uic-3--color": "var(--palette-color5)",\\
  "--text-uic-3--borderBottomStyle": "none",\\
  "--text-uic-3--textDecoration": "none",\\
  "--text-uic-3--letterSpacing": "0",\\
  "--text-uic-3--textTransform": "none",\\
  "--text-uic-3--stroke": "var(--palette-color2)",\\
  "--text-uic-3--textAlign": "left",\\
  "--text-uic-3--justifyContent": "flex-start",\\
  "--text-uic-3--marginTop": "auto",\\
  "--text-uic-3--marginBottom": "0",\\
  "--text-uic-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-4--fontSize--desktop": "22px",\\
  "--text-uic-4--fontSize--tablet": "22px",\\
  "--text-uic-4--fontSize--mobile": "22px",\\
  "--text-uic-4--fontFamily": "var(--font1)",\\
  "--text-uic-4--fontWeight": "normal",\\
  "--text-uic-4--fontType": "regular",\\
  "--text-uic-4--fontStyle": "normal",\\
  "--text-uic-4--fontStretch": "normal",\\
  "--text-uic-4--lineHeight": "1.25",\\
  "--text-uic-4--marginLeft": "0px",\\
  "--text-uic-4--color": "var(--palette-color4)",\\
  "--text-uic-4--borderBottomStyle": "none",\\
  "--text-uic-4--textDecoration": "none",\\
  "--text-uic-4--letterSpacing": "0",\\
  "--text-uic-4--textTransform": "none",\\
  "--text-uic-4--stroke": "var(--palette-color2)",\\
  "--text-uic-4--textAlign": "left",\\
  "--text-uic-4--justifyContent": "flex-start",\\
  "--text-uic-4--marginTop": "auto",\\
  "--text-uic-4--marginBottom": "0",\\
  "--text-uic-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-5--fontSize--desktop": "22px",\\
  "--text-uic-5--fontSize--tablet": "22px",\\
  "--text-uic-5--fontSize--mobile": "22px",\\
  "--text-uic-5--fontFamily": "var(--font1)",\\
  "--text-uic-5--fontWeight": "normal",\\
  "--text-uic-5--fontType": "regular",\\
  "--text-uic-5--fontStyle": "normal",\\
  "--text-uic-5--fontStretch": "normal",\\
  "--text-uic-5--lineHeight": "1.25",\\
  "--text-uic-5--marginLeft": "0px",\\
  "--text-uic-5--color": "var(--palette-color3)",\\
  "--text-uic-5--borderBottomStyle": "none",\\
  "--text-uic-5--textDecoration": "none",\\
  "--text-uic-5--letterSpacing": "0",\\
  "--text-uic-5--textTransform": "none",\\
  "--text-uic-5--stroke": "var(--palette-color2)",\\
  "--text-uic-5--textAlign": "left",\\
  "--text-uic-5--justifyContent": "flex-start",\\
  "--text-uic-5--marginTop": "auto",\\
  "--text-uic-5--marginBottom": "0",\\
  "--text-uic-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-6--fontSize--desktop": "16px",\\
  "--text-uic-6--fontSize--tablet": "16px",\\
  "--text-uic-6--fontSize--mobile": "16px",\\
  "--text-uic-6--fontFamily": "var(--font2)",\\
  "--text-uic-6--fontWeight": "normal",\\
  "--text-uic-6--fontType": "bold",\\
  "--text-uic-6--fontStyle": "normal",\\
  "--text-uic-6--fontStretch": "normal",\\
  "--text-uic-6--lineHeight": "1.5",\\
  "--text-uic-6--marginLeft": "0px",\\
  "--text-uic-6--color": "var(--palette-color7)",\\
  "--text-uic-6--borderBottomStyle": "none",\\
  "--text-uic-6--textDecoration": "none",\\
  "--text-uic-6--letterSpacing": "0.12",\\
  "--text-uic-6--textTransform": "none",\\
  "--text-uic-6--stroke": "var(--palette-color2)",\\
  "--text-uic-6--textAlign": "left",\\
  "--text-uic-6--justifyContent": "flex-start",\\
  "--text-uic-6--marginTop": "auto",\\
  "--text-uic-6--marginBottom": "0",\\
  "--text-uic-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-closedcaptions--fontSize--desktop": "24px",\\
  "--text-closedcaptions--fontSize--tablet": "24px",\\
  "--text-closedcaptions--fontSize--mobile": "24px",\\
  "--text-closedcaptions--fontFamily": "var(--font1)",\\
  "--text-closedcaptions--fontWeight": "normal",\\
  "--text-closedcaptions--fontType": "regular",\\
  "--text-closedcaptions--fontStyle": "normal",\\
  "--text-closedcaptions--fontStretch": "normal",\\
  "--text-closedcaptions--lineHeight": "1.35",\\
  "--text-closedcaptions--marginLeft": "0px",\\
  "--text-closedcaptions--color": "var(--white)",\\
  "--text-closedcaptions--borderBottomStyle": "none",\\
  "--text-closedcaptions--textDecoration": "none",\\
  "--text-closedcaptions--letterSpacing": "0",\\
  "--text-closedcaptions--textTransform": "none",\\
  "--text-closedcaptions--stroke": "var(--palette-color2)",\\
  "--text-closedcaptions--textAlign": "center",\\
  "--text-closedcaptions--justifyContent": "flex-start",\\
  "--text-closedcaptions--marginTop": "auto",\\
  "--text-closedcaptions--marginBottom": "0",\\
  "--text-closedcaptions--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-closedcaptions--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-closedcaptions--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-closedcaptions--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption--fontSize--desktop": "24px",\\
  "--text-caption--fontSize--tablet": "24px",\\
  "--text-caption--fontSize--mobile": "24px",\\
  "--text-caption--fontFamily": "var(--font1)",\\
  "--text-caption--fontWeight": "normal",\\
  "--text-caption--fontType": "regular",\\
  "--text-caption--fontStyle": "normal",\\
  "--text-caption--fontStretch": "normal",\\
  "--text-caption--lineHeight": "1.35",\\
  "--text-caption--marginLeft": "0px",\\
  "--text-caption--color": "var(--palette-color6)",\\
  "--text-caption--borderBottomStyle": "none",\\
  "--text-caption--textDecoration": "none",\\
  "--text-caption--letterSpacing": "0",\\
  "--text-caption--textTransform": "none",\\
  "--text-caption--stroke": "var(--palette-color2)",\\
  "--text-caption--textAlign": "center",\\
  "--text-caption--justifyContent": "flex-start",\\
  "--text-caption--marginTop": "auto",\\
  "--text-caption--marginBottom": "0",\\
  "--text-caption--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_correct--fontSize--desktop": "24px",\\
  "--text-caption_correct--fontSize--tablet": "24px",\\
  "--text-caption_correct--fontSize--mobile": "24px",\\
  "--text-caption_correct--fontFamily": "var(--font1)",\\
  "--text-caption_correct--fontWeight": "normal",\\
  "--text-caption_correct--fontType": "regular",\\
  "--text-caption_correct--fontStyle": "normal",\\
  "--text-caption_correct--fontStretch": "normal",\\
  "--text-caption_correct--lineHeight": "1.35",\\
  "--text-caption_correct--marginLeft": "0px",\\
  "--text-caption_correct--color": "var(--palette-color6)",\\
  "--text-caption_correct--borderBottomStyle": "none",\\
  "--text-caption_correct--textDecoration": "none",\\
  "--text-caption_correct--letterSpacing": "0",\\
  "--text-caption_correct--textTransform": "none",\\
  "--text-caption_correct--stroke": "var(--palette-color2)",\\
  "--text-caption_correct--textAlign": "center",\\
  "--text-caption_correct--justifyContent": "flex-start",\\
  "--text-caption_correct--marginTop": "auto",\\
  "--text-caption_correct--marginBottom": "0",\\
  "--text-caption_correct--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_correct--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_correct--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_correct--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_incorrect--fontSize--desktop": "24px",\\
  "--text-caption_incorrect--fontSize--tablet": "24px",\\
  "--text-caption_incorrect--fontSize--mobile": "24px",\\
  "--text-caption_incorrect--fontFamily": "var(--font1)",\\
  "--text-caption_incorrect--fontWeight": "normal",\\
  "--text-caption_incorrect--fontType": "regular",\\
  "--text-caption_incorrect--fontStyle": "normal",\\
  "--text-caption_incorrect--fontStretch": "normal",\\
  "--text-caption_incorrect--lineHeight": "1.35",\\
  "--text-caption_incorrect--marginLeft": "0px",\\
  "--text-caption_incorrect--color": "var(--palette-color6)",\\
  "--text-caption_incorrect--borderBottomStyle": "none",\\
  "--text-caption_incorrect--textDecoration": "none",\\
  "--text-caption_incorrect--letterSpacing": "0",\\
  "--text-caption_incorrect--textTransform": "none",\\
  "--text-caption_incorrect--stroke": "var(--palette-color2)",\\
  "--text-caption_incorrect--textAlign": "center",\\
  "--text-caption_incorrect--justifyContent": "flex-start",\\
  "--text-caption_incorrect--marginTop": "auto",\\
  "--text-caption_incorrect--marginBottom": "0",\\
  "--text-caption_incorrect--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_incorrect--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_incorrect--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_incorrect--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_incomplete--fontSize--desktop": "24px",\\
  "--text-caption_incomplete--fontSize--tablet": "24px",\\
  "--text-caption_incomplete--fontSize--mobile": "24px",\\
  "--text-caption_incomplete--fontFamily": "var(--font1)",\\
  "--text-caption_incomplete--fontWeight": "normal",\\
  "--text-caption_incomplete--fontType": "regular",\\
  "--text-caption_incomplete--fontStyle": "normal",\\
  "--text-caption_incomplete--fontStretch": "normal",\\
  "--text-caption_incomplete--lineHeight": "1.35",\\
  "--text-caption_incomplete--marginLeft": "0px",\\
  "--text-caption_incomplete--color": "var(--palette-color6)",\\
  "--text-caption_incomplete--borderBottomStyle": "none",\\
  "--text-caption_incomplete--textDecoration": "none",\\
  "--text-caption_incomplete--letterSpacing": "0",\\
  "--text-caption_incomplete--textTransform": "none",\\
  "--text-caption_incomplete--stroke": "var(--palette-color2)",\\
  "--text-caption_incomplete--textAlign": "center",\\
  "--text-caption_incomplete--justifyContent": "flex-start",\\
  "--text-caption_incomplete--marginTop": "auto",\\
  "--text-caption_incomplete--marginBottom": "0",\\
  "--text-caption_incomplete--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_incomplete--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_incomplete--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_incomplete--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_hint--fontSize--desktop": "24px",\\
  "--text-caption_hint--fontSize--tablet": "24px",\\
  "--text-caption_hint--fontSize--mobile": "24px",\\
  "--text-caption_hint--fontFamily": "var(--font1)",\\
  "--text-caption_hint--fontWeight": "normal",\\
  "--text-caption_hint--fontType": "regular",\\
  "--text-caption_hint--fontStyle": "normal",\\
  "--text-caption_hint--fontStretch": "normal",\\
  "--text-caption_hint--lineHeight": "1.35",\\
  "--text-caption_hint--marginLeft": "0px",\\
  "--text-caption_hint--color": "var(--palette-color6)",\\
  "--text-caption_hint--borderBottomStyle": "none",\\
  "--text-caption_hint--textDecoration": "none",\\
  "--text-caption_hint--letterSpacing": "0",\\
  "--text-caption_hint--textTransform": "none",\\
  "--text-caption_hint--stroke": "var(--palette-color2)",\\
  "--text-caption_hint--textAlign": "center",\\
  "--text-caption_hint--justifyContent": "flex-start",\\
  "--text-caption_hint--marginTop": "auto",\\
  "--text-caption_hint--marginBottom": "0",\\
  "--text-caption_hint--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_hint--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_hint--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_hint--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_retry--fontSize--desktop": "24px",\\
  "--text-caption_retry--fontSize--tablet": "24px",\\
  "--text-caption_retry--fontSize--mobile": "24px",\\
  "--text-caption_retry--fontFamily": "var(--font1)",\\
  "--text-caption_retry--fontWeight": "normal",\\
  "--text-caption_retry--fontType": "regular",\\
  "--text-caption_retry--fontStyle": "normal",\\
  "--text-caption_retry--fontStretch": "normal",\\
  "--text-caption_retry--lineHeight": "1.35",\\
  "--text-caption_retry--marginLeft": "0px",\\
  "--text-caption_retry--color": "var(--palette-color6)",\\
  "--text-caption_retry--borderBottomStyle": "none",\\
  "--text-caption_retry--textDecoration": "none",\\
  "--text-caption_retry--letterSpacing": "0",\\
  "--text-caption_retry--textTransform": "none",\\
  "--text-caption_retry--stroke": "var(--palette-color2)",\\
  "--text-caption_retry--textAlign": "center",\\
  "--text-caption_retry--justifyContent": "flex-start",\\
  "--text-caption_retry--marginTop": "auto",\\
  "--text-caption_retry--marginBottom": "0",\\
  "--text-caption_retry--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_retry--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_retry--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_retry--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_timeout--fontSize--desktop": "24px",\\
  "--text-caption_timeout--fontSize--tablet": "24px",\\
  "--text-caption_timeout--fontSize--mobile": "24px",\\
  "--text-caption_timeout--fontFamily": "var(--font1)",\\
  "--text-caption_timeout--fontWeight": "normal",\\
  "--text-caption_timeout--fontType": "regular",\\
  "--text-caption_timeout--fontStyle": "normal",\\
  "--text-caption_timeout--fontStretch": "normal",\\
  "--text-caption_timeout--lineHeight": "1.35",\\
  "--text-caption_timeout--marginLeft": "0px",\\
  "--text-caption_timeout--color": "var(--palette-color6)",\\
  "--text-caption_timeout--borderBottomStyle": "none",\\
  "--text-caption_timeout--textDecoration": "none",\\
  "--text-caption_timeout--letterSpacing": "0",\\
  "--text-caption_timeout--textTransform": "none",\\
  "--text-caption_timeout--stroke": "var(--palette-color2)",\\
  "--text-caption_timeout--textAlign": "center",\\
  "--text-caption_timeout--justifyContent": "flex-start",\\
  "--text-caption_timeout--marginTop": "auto",\\
  "--text-caption_timeout--marginBottom": "0",\\
  "--text-caption_timeout--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_timeout--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_timeout--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_timeout--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_1--fontSize--desktop": "18px",\\
  "--text-caption_1--fontSize--tablet": "18px",\\
  "--text-caption_1--fontSize--mobile": "16px",\\
  "--text-caption_1--fontFamily": "var(--font2)",\\
  "--text-caption_1--fontWeight": "normal",\\
  "--text-caption_1--fontType": "regular",\\
  "--text-caption_1--fontStyle": "normal",\\
  "--text-caption_1--fontStretch": "normal",\\
  "--text-caption_1--lineHeight": "1.2",\\
  "--text-caption_1--marginLeft": "0px",\\
  "--text-caption_1--color": "#FFFFFF",\\
  "--text-caption_1--borderBottomStyle": "none",\\
  "--text-caption_1--textDecoration": "none",\\
  "--text-caption_1--letterSpacing": "0",\\
  "--text-caption_1--textTransform": "none",\\
  "--text-caption_1--stroke": "#00000000",\\
  "--text-caption_1--textAlign": "left",\\
  "--text-caption_1--justifyContent": "flex-start",\\
  "--text-caption_1--marginTop": "auto",\\
  "--text-caption_1--marginBottom": "0",\\
  "--text-caption_1--defaultTextStroke": "1px #00000000",\\
  "--text-caption_1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_2--fontSize--desktop": "20px",\\
  "--text-caption_2--fontSize--tablet": "20px",\\
  "--text-caption_2--fontSize--mobile": "18px",\\
  "--text-caption_2--fontFamily": "var(--font2)",\\
  "--text-caption_2--fontWeight": "normal",\\
  "--text-caption_2--fontType": "bold",\\
  "--text-caption_2--fontStyle": "normal",\\
  "--text-caption_2--fontStretch": "normal",\\
  "--text-caption_2--lineHeight": "1.2",\\
  "--text-caption_2--marginLeft": "0px",\\
  "--text-caption_2--color": "#FFFFFF",\\
  "--text-caption_2--borderBottomStyle": "none",\\
  "--text-caption_2--textDecoration": "none",\\
  "--text-caption_2--letterSpacing": "0",\\
  "--text-caption_2--textTransform": "none",\\
  "--text-caption_2--stroke": "#00000000",\\
  "--text-caption_2--textAlign": "left",\\
  "--text-caption_2--justifyContent": "flex-start",\\
  "--text-caption_2--marginTop": "auto",\\
  "--text-caption_2--marginBottom": "0",\\
  "--text-caption_2--defaultTextStroke": "1px #00000000",\\
  "--text-caption_2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_3--fontSize--desktop": "24px",\\
  "--text-caption_3--fontSize--tablet": "24px",\\
  "--text-caption_3--fontSize--mobile": "22px",\\
  "--text-caption_3--fontFamily": "var(--font1)",\\
  "--text-caption_3--fontWeight": "normal",\\
  "--text-caption_3--fontType": "italic",\\
  "--text-caption_3--fontStyle": "normal",\\
  "--text-caption_3--fontStretch": "normal",\\
  "--text-caption_3--lineHeight": "1.2",\\
  "--text-caption_3--marginLeft": "0px",\\
  "--text-caption_3--color": "#FFFFFF",\\
  "--text-caption_3--borderBottomStyle": "none",\\
  "--text-caption_3--textDecoration": "none",\\
  "--text-caption_3--letterSpacing": "0",\\
  "--text-caption_3--textTransform": "none",\\
  "--text-caption_3--stroke": "#00000000",\\
  "--text-caption_3--textAlign": "left",\\
  "--text-caption_3--justifyContent": "flex-start",\\
  "--text-caption_3--marginTop": "auto",\\
  "--text-caption_3--marginBottom": "0",\\
  "--text-caption_3--defaultTextStroke": "1px #00000000",\\
  "--text-caption_3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_4--fontSize--desktop": "22px",\\
  "--text-caption_4--fontSize--tablet": "22px",\\
  "--text-caption_4--fontSize--mobile": "20px",\\
  "--text-caption_4--fontFamily": "var(--font2)",\\
  "--text-caption_4--fontWeight": "normal",\\
  "--text-caption_4--fontType": "italic",\\
  "--text-caption_4--fontStyle": "normal",\\
  "--text-caption_4--fontStretch": "normal",\\
  "--text-caption_4--lineHeight": "1.3",\\
  "--text-caption_4--marginLeft": "0px",\\
  "--text-caption_4--color": "#666666",\\
  "--text-caption_4--borderBottomStyle": "none",\\
  "--text-caption_4--textDecoration": "none",\\
  "--text-caption_4--letterSpacing": "0",\\
  "--text-caption_4--textTransform": "none",\\
  "--text-caption_4--stroke": "#00000000",\\
  "--text-caption_4--textAlign": "left",\\
  "--text-caption_4--justifyContent": "flex-start",\\
  "--text-caption_4--marginTop": "auto",\\
  "--text-caption_4--marginBottom": "0",\\
  "--text-caption_4--defaultTextStroke": "1px #00000000",\\
  "--text-caption_4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-comment-box--fontSize--desktop": "20px",\\
  "--text-comment-box--fontSize--tablet": "20px",\\
  "--text-comment-box--fontSize--mobile": "20px",\\
  "--text-comment-box--fontFamily": "var(--font1)",\\
  "--text-comment-box--fontWeight": "normal",\\
  "--text-comment-box--fontType": "regular",\\
  "--text-comment-box--fontStyle": "normal",\\
  "--text-comment-box--fontStretch": "normal",\\
  "--text-comment-box--lineHeight": "1.35",\\
  "--text-comment-box--marginLeft": "0px",\\
  "--text-comment-box--color": "var(--palette-color6)",\\
  "--text-comment-box--borderBottomStyle": "none",\\
  "--text-comment-box--textDecoration": "none",\\
  "--text-comment-box--letterSpacing": "0",\\
  "--text-comment-box--textTransform": "none",\\
  "--text-comment-box--stroke": "var(--palette-color2)",\\
  "--text-comment-box--textAlign": "center",\\
  "--text-comment-box--justifyContent": "flex-start",\\
  "--text-comment-box--marginTop": "auto",\\
  "--text-comment-box--marginBottom": "0",\\
  "--text-comment-box--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-comment-box--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-comment-box--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-comment-box--textShadow": "var(--text-style-unset)",\\
\\
  "--theme_image_default--strokeColor": "var(--palette-color1)",\\
  "--theme_image_default--boxShadowColor": "var(--greyscale3)",\\
\\
  "--theme_image_greyscale--strokeColor": "var(--palette-color1)",\\
  "--theme_image_greyscale--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_greyscale--intensity": 100,\\
\\
  "--theme_image_lighten--strokeColor": "var(--palette-color1)",\\
  "--theme_image_lighten--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_lighten--intensity": 80,\\
\\
  "--theme_image_darken--strokeColor": "var(--palette-color1)",\\
  "--theme_image_darken--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_darken--intensity": 80,\\
\\
  "--theme_image_overlay--strokeColor": "var(--palette-color1)",\\
  "--theme_image_overlay--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_overlay--intensity": 80,\\
  "--theme_image_overlay--primaryFillColor": "var(--palette-color2)",\\
  "--theme_image_overlay--secondaryFillColor": "var(--palette-color1)",\\
\\
  "--theme_image_colorize--strokeColor": "var(--palette-color1)",\\
  "--theme_image_colorize--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_colorize--intensity": 80,\\
  "--theme_image_colorize--primaryFillColor": "var(--palette-color4)",\\
  "--theme_image_colorize--secondaryFillColor": "var(--palette-color1)",\\
\\
\\
  "--button-normal--primaryColor": "var(--palette-color7)",\\
  "--button-normal--borderColor": "var(--palette-color7)",\\
  "--button-normal--shadowColor": "var(--greyscale3)",\\
  "--text-button-normal--color": "var(--palette-color0)",\\
  "--text-button-normal--fontFamily": "var(--font2)",\\
  "--text-button-normal--fontType": "regular",\\
  "--text-button-normal--fontSize--desktop": "16px",\\
  "--text-button-normal--fontSize--tablet": "16px",\\
  "--text-button-normal--fontSize--mobile": "16px",\\
\\
  "--button-selected--primaryColor": "var(--palette-color5)",\\
  "--button-selected--borderColor": "var(--palette-color5)",\\
  "--button-selected--shadowColor": "var(--greyscale3)",\\
  "--text-button-selected--color": "var(--palette-color0)",\\
  "--text-button-selected--fontFamily": "var(--font2)",\\
  "--text-button-selected--fontType": "regular",\\
  "--text-button-selected--fontSize--desktop": "16px",\\
  "--text-button-selected--fontSize--tablet": "16px",\\
  "--text-button-selected--fontSize--mobile": "16px",\\
\\
  "--button-disabled--primaryColor": "var(--palette-color3)",\\
  "--button-disabled--borderColor": "var(--palette-color3)",\\
  "--button-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-button-disabled--color": "var(--palette-color4)",\\
  "--text-button-disabled--fontFamily": "var(--font2)",\\
  "--text-button-disabled--fontType": "regular",\\
  "--text-button-disabled--fontSize--desktop": "16px",\\
  "--text-button-disabled--fontSize--tablet": "16px",\\
  "--text-button-disabled--fontSize--mobile": "16px",\\
\\
  "--button-hover--primaryColor": "#112FA7",\\
  "--button-hover--borderColor": "#112FA7",\\
  "--button-hover--shadowColor": "var(--greyscale3)",\\
  "--text-button-hover--color": "var(--palette-color0)",\\
  "--text-button-hover--fontFamily": "var(--font2)",\\
  "--text-button-hover--fontType": "regular",\\
  "--text-button-hover--fontSize--desktop": "16px",\\
  "--text-button-hover--fontSize--tablet": "16px",\\
  "--text-button-hover--fontSize--mobile": "16px",\\
\\
  "--button-visited--primaryColor": "#112FA780",\\
  "--button-visited--borderColor": "#112FA780",\\
  "--button-visited--shadowColor": "var(--greyscale3)",\\
  "--text-button-visited--color": "var(--palette-color0)",\\
  "--text-button-visited--fontFamily": "var(--font2)",\\
  "--text-button-visited--fontType": "regular",\\
  "--text-button-visited--fontSize--desktop": "16px",\\
  "--text-button-visited--fontSize--tablet": "16px",\\
  "--text-button-visited--fontSize--mobile": "16px",\\
\\
  "--checkbox-normal--primaryColor": "var(--palette-color0)",\\
  "--checkbox-normal--borderColor": "var(--palette-color3)",\\
  "--checkbox-normal--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-normal--color": "var(--palette-color4)",\\
  "--text-checkbox-normal--fontFamily": "var(--font1)",\\
  "--text-checkbox-normal--fontType": "regular",\\
  "--text-checkbox-normal--fontSize--desktop": "22px",\\
  "--text-checkbox-normal--fontSize--tablet": "20px",\\
  "--text-checkbox-normal--fontSize--mobile": "20px",\\
\\
  "--checkbox-selected--primaryColor": "var(--palette-color7)",\\
  "--checkbox-selected--borderColor": "var(--palette-color4)",\\
  "--checkbox-selected--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-selected--color": "var(--palette-color4)",\\
  "--text-checkbox-selected--fontFamily": "var(--font1)",\\
  "--text-checkbox-selected--fontType": "regular",\\
  "--text-checkbox-selected--fontSize--desktop": "22px",\\
  "--text-checkbox-selected--fontSize--tablet": "20px",\\
  "--text-checkbox-selected--fontSize--mobile": "20px",\\
\\
  "--checkbox-disabled-checked--primaryColor": "var(--palette-color3)",\\
  "--checkbox-disabled-checked--borderColor": "var(--palette-color3)",\\
  "--checkbox-disabled-checked--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-disabled-checked--color": "var(--palette-color3)",\\
  "--text-checkbox-disabled-checked--fontFamily": "var(--font1)",\\
  "--text-checkbox-disabled-checked--fontType": "regular",\\
  "--text-checkbox-disabled-checked--fontSize--desktop": "22px",\\
  "--text-checkbox-disabled-checked--fontSize--tablet": "20px",\\
  "--text-checkbox-disabled-checked--fontSize--mobile": "20px",\\
\\
  "--checkbox-hover--primaryColor": "var(--palette-color0)",\\
  "--checkbox-hover--borderColor": "var(--palette-color3)",\\
  "--checkbox-hover--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-hover--color": "var(--palette-color5)",\\
  "--text-checkbox-hover--fontFamily": "var(--font1)",\\
  "--text-checkbox-hover--fontType": "regular",\\
  "--text-checkbox-hover--fontSize--desktop": "22px",\\
  "--text-checkbox-hover--fontSize--tablet": "20px",\\
  "--text-checkbox-hover--fontSize--mobile": "20px",\\
\\
  "--checkbox-disabled-unchecked--primaryColor": "var(--palette-color3)",\\
  "--checkbox-disabled-unchecked--borderColor": "var(--palette-color3)",\\
  "--checkbox-disabled-unchecked--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-disabled-unchecked--color": "var(--palette-color3)",\\
  "--text-checkbox-disabled-unchecked--fontFamily": "var(--font1)",\\
  "--text-checkbox-disabled-unchecked--fontType": "regular",\\
  "--text-checkbox-disabled-unchecked--fontSize--desktop": "22px",\\
  "--text-checkbox-disabled-unchecked--fontSize--tablet": "20px",\\
  "--text-checkbox-disabled-unchecked--fontSize--mobile": "20px",\\
\\
  "--inputfield-normal--primaryColor": "var(--palette-color0)", \\
  "--inputfield-normal--borderColor": "var(--palette-color3)",\\
  "--inputfield-normal--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-normal--color": "var(--palette-color4)",\\
  "--text-inputfield-normal--fontFamily": "var(--font1)",\\
  "--text-inputfield-normal--fontType": "regular",\\
  "--text-inputfield-normal--fontSize--desktop": "18px",\\
  "--text-inputfield-normal--fontSize--tablet": "20px",\\
  "--text-inputfield-normal--fontSize--mobile": "20px",\\
\\
  "--inputfield-active--primaryColor": "var(--palette-color0)",\\
  "--inputfield-active--borderColor": "var(--palette-color7)",\\
  "--inputfield-active--shadowColor": "#var(--greyscale3)",\\
  "--text-inputfield-active--color": "var(--palette-color4)",\\
  "--text-inputfield-active--fontFamily": "var(--font1)",\\
  "--text-inputfield-active--fontType": "regular",\\
  "--text-inputfield-active--fontSize--desktop": "18px",\\
  "--text-inputfield-active--fontSize--tablet": "20px",\\
  "--text-inputfield-active--fontSize--mobile": "20px",\\
\\
  "--inputfield-disabled--primaryColor": "var(--palette-color3)",\\
  "--inputfield-disabled--borderColor": "var(--palette-color3)",\\
  "--inputfield-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-disabled--color": "var(--palette-color1)",\\
  "--text-inputfield-disabled--fontFamily": "var(--font1)",\\
  "--text-inputfield-disabled--fontType": "regular",\\
  "--text-inputfield-disabled--fontSize--desktop": "18px",\\
  "--text-inputfield-disabled--fontSize--tablet": "20px",\\
  "--text-inputfield-disabled--fontSize--mobile": "20px",\\
\\
  "--inputfield-focusLost--primaryColor": "var(--palette-color0)",\\
  "--inputfield-focusLost--borderColor": "var(--palette-color3)",\\
  "--inputfield-focusLost--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-focusLost--color": "var(--palette-color4)",\\
  "--text-inputfield-focusLost--fontFamily": "var(--font1)",\\
  "--text-inputfield-focusLost--fontType": "regular",\\
  "--text-inputfield-focusLost--fontSize--desktop": "18px",\\
  "--text-inputfield-focusLost--fontSize--tablet": "20px",\\
  "--text-inputfield-focusLost--fontSize--mobile": "20px",\\
\\
  "--inputfield-error--primaryColor": "var(--palette-color0)",\\
  "--inputfield-error--borderColor": "var(--error)",\\
  "--inputfield-error--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-error--color": "var(--palette-color4)",\\
  "--text-inputfield-error--fontFamily": "var(--font1)",\\
  "--text-inputfield-error--fontType": "regular",\\
  "--text-inputfield-error--fontSize--desktop": "18px",\\
  "--text-inputfield-error--fontSize--tablet": "20px",\\
  "--text-inputfield-error--fontSize--mobile": "20px",\\
\\
  "--dropdown-normal--primaryColor": "var(--palette-color0)",\\
  "--dropdown-normal--borderColor": "var(--palette-color3)",\\
  "--dropdown-normal--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-normal--color": "var(--palette-color4)",\\
  "--text-dropdown-normal--fontFamily": "var(--font1)",\\
  "--text-dropdown-normal--fontType": "italic",\\
  "--text-dropdown-normal--fontSize--desktop": "18px",\\
  "--text-dropdown-normal--fontSize--tablet": "18px",\\
  "--text-dropdown-normal--fontSize--mobile": "18px",\\
\\
  "--dropdown-selected--primaryColor": "var(--palette-color0)",\\
  "--dropdown-selected--borderColor": "var(--palette-color7)",\\
  "--dropdown-selected--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-selected--color": "var(--palette-color4)",\\
  "--text-dropdown-selected--fontFamily": "var(--font1)",\\
  "--text-dropdown-selected--fontType": "italic",\\
  "--text-dropdown-selected--fontSize--desktop": "18px",\\
  "--text-dropdown-selected--fontSize--tablet": "18px",\\
  "--text-dropdown-selected--fontSize--mobile": "18px",\\
\\
  "--dropdown-disabled--primaryColor": "var(--palette-color3)",\\
  "--dropdown-disabled--borderColor": "var(--palette-color3)",\\
  "--dropdown-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-disabled--color": "var(--palette-color1)",\\
  "--text-dropdown-disabled--fontFamily": "var(--font1)",\\
  "--text-dropdown-disabled--fontType": "italic",\\
  "--text-dropdown-disabled--fontSize--desktop": "18px",\\
  "--text-dropdown-disabled--fontSize--tablet": "18px",\\
  "--text-dropdown-disabled--fontSize--mobile": "18px",\\
\\
  "--dropdown-hover--primaryColor": "var(--palette-color0)",\\
  "--dropdown-hover--borderColor": "var(--palette-color3)",\\
  "--dropdown-hover--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-hover--color": "var(--palette-color4)",\\
  "--text-dropdown-hover--fontFamily": "var(--font1)",\\
  "--text-dropdown-hover--fontType": "italic",\\
  "--text-dropdown-hover--fontSize--desktop": "18px",\\
  "--text-dropdown-hover--fontSize--tablet": "18px",\\
  "--text-dropdown-hover--fontSize--mobile": "18px",\\
\\
  "--radio-normal--primaryColor": "var(--palette-color0)",\\
  "--radio-normal--borderColor": "var(--palette-color3)",\\
  "--radio-normal--shadowColor": "var(--greyscale3)",\\
  "--text-radio-normal--color": "var(--palette-color4)",\\
  "--text-radio-normal--fontFamily": "var(--font1)",\\
  "--text-radio-normal--fontType": "regular",\\
  "--text-radio-normal--fontSize--desktop": "22px",\\
  "--text-radio-normal--fontSize--tablet": "20px",\\
  "--text-radio-normal--fontSize--mobile": "20px",\\
\\
  "--radio-selected--primaryColor": "var(--palette-color7)",\\
  "--radio-selected--borderColor": "var(--palette-color4)",\\
  "--radio-selected--shadowColor": "var(--greyscale3)",\\
  "--text-radio-selected--color": "var(--palette-color4)",\\
  "--text-radio-selected--fontFamily": "var(--font1)",\\
  "--text-radio-selected--fontType": "regular",\\
  "--text-radio-selected--fontSize--desktop": "22px",\\
  "--text-radio-selected--fontSize--tablet": "20px",\\
  "--text-radio-selected--fontSize--mobile": "20px",\\
\\
  "--radio-disabled-checked--primaryColor": "var(--palette-color3)",\\
  "--radio-disabled-checked--borderColor": "var(--palette-color3)",\\
  "--radio-disabled-checked--shadowColor": "var(--greyscale3)",\\
  "--text-radio-disabled-checked--color": "var(--palette-color3)",\\
  "--text-radio-disabled-checked--fontFamily": "var(--font1)",\\
  "--text-radio-disabled-checked--fontType": "regular",\\
  "--text-radio-disabled-checked--fontSize--desktop": "22px",\\
  "--text-radio-disabled-checked--fontSize--tablet": "20px",\\
  "--text-radio-disabled-checked--fontSize--mobile": "20px",\\
\\
  "--radio-hover--primaryColor": "var(--palette-color0)",\\
  "--radio-hover--borderColor": "var(--palette-color3)",\\
  "--radio-hover--shadowColor": "var(--greyscale3)",\\
  "--text-radio-hover--color": "var(--palette-color5)",\\
  "--text-radio-hover--fontFamily": "var(--font1)",\\
  "--text-radio-hover--fontType": "regular",\\
  "--text-radio-hover--fontSize--desktop": "22px",\\
  "--text-radio-hover--fontSize--tablet": "20px",\\
  "--text-radio-hover--fontSize--mobile": "20px",\\
\\
  "--radio-disabled-unchecked--primaryColor": "var(--palette-color3)",\\
  "--radio-disabled-unchecked--borderColor": "var(--palette-color3)",\\
  "--radio-disabled-unchecked--shadowColor": "var(--greyscale3)",\\
  "--text-radio-disabled-unchecked--color": "var(--palette-color3)",\\
  "--text-radio-disabled-unchecked--fontFamily": "var(--font1)",\\
  "--text-radio-disabled-unchecked--fontType": "regular",\\
  "--text-radio-disabled-unchecked--fontSize--desktop": "22px",\\
  "--text-radio-disabled-unchecked--fontSize--tablet": "20px",\\
  "--text-radio-disabled-unchecked--fontSize--mobile": "20px",\\
\\
  "--video_preset-color": "#666666",\\
  "--video_preset-borderColor": "#666666",\\
  \\
  "--clickbox-preset-fill-color": "#3F80E4",\\
\\
  "--drag-object-default-state-fill-color": "255, 255, 255",\\
  "--drag-object-hover-state-fill-color": "250, 250, 250",\\
  "--drag-object-transition-state-fill-color": "250, 250, 250",\\
  "--drag-object-dragOver-state-fill-color": "250, 250, 250",\\
  "--drag-object-dropped-state-fill-color": "255, 255, 255",\\
\\
  "--drag-object-default-state-border-color": "214, 213, 209",\\
  "--drag-object-hover-state-border-color": "214, 213, 209",\\
  "--drag-object-transition-state-border-color": "214, 213, 209",\\
  "--drag-object-dragOver-state-border-color": "230, 132, 80",\\
  "--drag-object-dropped-state-border-color": "214, 213, 209",\\
\\
  "--drop-object-default-state-fill-color": "255, 255, 255",\\
  "--drop-object-hover-state-fill-color": "255, 255, 255",\\
  "--drop-object-dragOver-state-fill-color": "230, 132, 80",\\
  "--drop-object-dropped-state-fill-color": "255, 255, 255",\\
\\
  "--drop-object-default-state-border-color": "42, 49, 62",\\
  "--drop-object-hover-state-border-color": "230, 132, 80",\\
  "--drop-object-dragOver-state-border-color": "230, 132, 80",\\
  "--drop-object-dropped-state-border-color": "42, 49, 62"\\
}',
uic_presets:'{\\
  "cp_button_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-normal--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 1,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-hover--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 7,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 0.53\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-selected--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "--button-selected--shadowColor",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_visited": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-visited--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-visited--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-visited--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-disabled--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style": {\\
    "fill": "var(--palette-color0)",\\
    "fillOpacity": 1,\\
    "stroke": "#707070",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_hover": {\\
    "fill": "#9ec4f3",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 7,\\
      "spread": null,\\
      "color": "var(--black)",\\
      "inset": null,\\
      "opacity": 0.53\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_selected": {\\
    "fill": "var(--palette-color5)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_visited": {\\
    "fill": "#0A00FF",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_disabled": {\\
    "fill": "#0A00FF",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_disabled_checked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-disabled-checked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-disabled-checked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-disabled-checked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_disabled_unchecked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-disabled-unchecked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-disabled-unchecked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_active": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-active--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-active--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-active--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_focusLost": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-focusLost--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-focusLost--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-focusLost--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_error": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-error--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-error--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-error--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-normal--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-hover--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 14,\\
      "spread": null,\\
      "color": "var(--dropdown-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 0.78\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-selected--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-disabled--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "video_preset_style": {\\
    "fillEnable": 0,\\
    "strokeEnable": 0,\\
    "shadowEnable": 0,\\
    "fill": "var(--video_preset-color)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--video_preset-border)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_comment_box_shape_1_solid_style": {\\
    "fill": "#F2B807",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_clickbox_shape_solid_style": {\\
    "fill": "var(--clickbox-preset-fill-color)",\\
    "fillOpacity": 0.6,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "2, 3",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-hover--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_visited": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-visited--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-visited--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_default": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#333333",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#000000",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#D6D5D1",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_disabled_checked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-disabled-checked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-disabled-checked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-checked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_disabled_unchecked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-disabled-unchecked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-disabled-unchecked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_clicktoreveal_default": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#ffffff",\\
    "fillOpacity": 1,\\
    "stroke": "#ffffff",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_linear_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 3,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color0)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--black)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "#FF335E",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "#ECA8B6",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color7)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color8)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_blue": {\\
    "fill": "#ADD8E6",\\
    "fillOpacity": 1,\\
    "stroke": "var(--black)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "#FF335E",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "#ECA8B6",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  }\\
}'
},
project_main:{
from:1,
to:0,
currentFrame:1,
featureFlags:{
isNewWidgetArchitecture:'{"isEnabled":true,"featureData":{}}'
}
,
useResponsive:true,
responsiveType:512,
isResponsiveSim:0,
currentFrame:1,
useWidgetVersion7:false,
isPublishedFromLacuna:false,
vestr:0,
vim:0,
slides:'Slide4392',
questions:'',
autoplay:false,
preloader:true,
preloaderFileName:'dr/loading.gif',
preloaderPercentage:100,
pprtd:false,
peon:false,
fadeInAtStart:0,
fadeOutAtEnd:0
},
borderProperties:{
hasBorder:false
},
playBarProperties:{
hasPlayBar:true,
jsfile:'playbarScript.js',
cssfile:'playbarStyle.css',
position:3,
layout:3,
showOnHover:false,
overlay:true,
tworow:false,
hasRewind:true,
hasBackward:true,
hasPlay:true,
hasEnterVR:false,
hasSlider:true,
hasForward:true,
hasCC:false,
hasAudioOn:true,
hasExit:true,
hasFastForward:true,
applyColors:false,
alpha:100,
noToolTips:false,
locale:0
},
tocProperties:{
tocProperties:'{"tocConfig":{"labels":{"TITLE":"Table of Content","SLIDE_DETAILS":"SLIDE TITLE","DURATION":"DURATION","CLOSE_BUTTON_LABEL":"Close"},"slideDetails":[{"label":"Shubham Thakur Resume","type":"slide","parentId":null,"id":"Slide4392","isVisible":true,"slideVisited":false,"originalId":4392,"labelShouldBeInSync":true}],"tocGeneratedOnPreviewClick":false,"preserveSlidesOrder":true},"playbarConfig":{"isPlaybarControlsPlayEnabled":true,"isPlaybarControlsNextEnabled":true,"isPlaybarControlsTOCEnabled":true,"isShowPlaybarEnabled":true,"isShowTooltipsEnabled":true,"isPlaybarControlsBackEnabled":true,"isHidePlaybarInQuizEnabled":false,"isPlaybarControlsMuteEnabled":true,"isPlaybarControlsClosedCaptionsEnabled":false}}'
},
trecs:[{
link:4392,
text:[]
}
]

,
typekit:{
kit_id:''
},
};
cp.model.projectImages=[
'assets/htmlimages/ThreeD_Close.svg',
'assets/htmlimages/ThreeD_HotspotDefaultGlow.png',
'assets/htmlimages/ThreeD_HotspotGlow.png',
'assets/htmlimages/assessmenthotspotvisited.svg',
'assets/htmlimages/expand_icon.png',
'assets/htmlimages/img_trans.gif',
'assets/htmlimages/placeholder.png'
];
cp.model.data.images=[{
ip:'dr/01342.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03257.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03381.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03505.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03619.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03621.jpg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/04028.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/04081.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/04381.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/04383.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/04386.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/04518.jpeg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0481.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0649.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0671.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/06812.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
];
cp.model.videos=[
];
cp.model.slideVideos=[
];
cp.model.tocVideos=[
];
cp.model.audios=[
];

cp.initVariables = function(){
cp.cv('CaptivateVersion','12.1.0',1,1000,0);
cp.cv('Date.DateDDMMYY','dd/mm/yyyy',1,15,0);
cp.cv('Date.DateMMDDYY','mm/dd/yyyy',1,15,0);
cp.cv('Date.Day',1,1,15,0);
cp.cv('Date.Hours','hh',1,15,0);
cp.cv('Date.LocaleString','',1,15,0);
cp.cv('Date.Minutes','mm',1,15,0);
cp.cv('Date.Month','mm',1,15,0);
cp.cv('Date.Time','hh:mm:ss',1,15,0);
cp.cv('Date.Today','dd',1,15,0);
cp.cv('Date.Year','yyyy',1,15,0);
cp.cv('Project.AudioLevel',100,1,15,0);
cp.cv('Project.ClosedCaptions',1,1,15,0);
cp.cv('Project.CurrentSlideName','slide',1,15,0);
cp.cv('Project.CurrentSlideNumber',1,1,15,0);
cp.cv('Project.LockTOC',0,1,15,0);
cp.cv('Project.MuteAudio',0,1,15,0);
cp.cv('Project.ShowPlaybar',1,1,15,0);
cp.cv('Project.ShowTOC',0,1,15,0);
cp.cv('Project.SlideCount',1,1,15,0);
cp.cv('Question.AnswerChoice','',1,15,0);
cp.cv('Question.MaxAttempts',0,1,15,0);
cp.cv('Question.NegativePoints',0,1,15,0);
cp.cv('Question.PointsAssigned',0,1,15,0);
cp.cv('Question.PreviousQuestionScore',0,1,15,0);
cp.cv('Quiz.AttemptCount',0,1,15,0);
cp.cv('Quiz.CorrectAnswerCount',0,1,15,0);
cp.cv('Quiz.InReview',0,1,15,0);
cp.cv('Quiz.InScope',0,1,15,0);
cp.cv('Quiz.MaxScore',0,1,1000,0);
cp.cv('Quiz.Pass',0,1,15,0);
cp.cv('Quiz.PassPercentage',80,1,1000,0);
cp.cv('Quiz.PassPoints',0,1,1000,0);
cp.cv('Quiz.PercentageScore',0,1,15,0);
cp.cv('Quiz.QuestionCount',0,1,1000,0);
cp.cv('Quiz.Score',0,1,15,0);
cp.cv('Quiz.UnansweredQuestionCount',0,1,1000,0);
cp.cv('cpInfoHasPlaybar',1,1,1000,0);
cp.cv('cpInfoSlidesInProject',1,1,1000,0);
cp.cv('cpLockTOC',0,1,1000,0);
cp.cv('cpQuizInfoPreTestTotalQuestions',0,1,1000,0);
cp.cv('cpQuizInfoTotalQuizPoints',0,1,1000,0);
cp.cv('cpInfoPrevFrame',0,1,15,0);
cp.cv('LMS.CourseName','',0,15,0);
cp.cv('LMS.LearnerID','',0,15,0);
cp.cv('LMS.LearnerName','',0,15,0);
};cp.ReportingVariables="LMS.CourseName,LMS.LearnerID,LMS.LearnerName,";
};cp.sbw=0;cp.useg=0;cp.geo=0;cp.pg=0;cp.win8=0;cp.autoGrow=1;cp.fluidFont=1;
